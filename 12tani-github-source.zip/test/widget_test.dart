import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/constants/app_strings.dart';
import 'package:twelvetani/core/theme/app_theme.dart';
import 'package:twelvetani/models/difficulty.dart';
import 'package:twelvetani/models/game_mode.dart';
import 'package:twelvetani/views/screens/game_screen.dart';
import 'package:twelvetani/views/screens/home_screen.dart';
import 'package:twelvetani/views/screens/leaderboard_screen.dart';
import 'package:twelvetani/views/screens/shop_screen.dart';
import 'package:twelvetani/views/screens/splash_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('SplashScreen displays 12 GOTI and Guest Login', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.darkTheme,
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: SplashScreen(),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('12 GOTI'), findsOneWidget);
    expect(find.text(AppStrings.guestLogin), findsOneWidget);
  });

  testWidgets('HomeScreen displays 2x2 mode cards and PLAY NOW button', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.darkTheme,
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: HomeScreen(),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Online 1v1'), findsOneWidget);
    expect(find.text('Vs Computer'), findsOneWidget);
    expect(find.text('Pass & Play'), findsOneWidget);
    expect(find.text(AppStrings.playWithFriend), findsOneWidget);
    expect(find.text('PLAY NOW'), findsOneWidget);
  });

  testWidgets('ShopScreen displays Bead Skins and Board Themes', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.darkTheme,
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: ShopScreen(),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('SHOP & CUSTOMIZE'), findsOneWidget);
    expect(find.text('BEAD SKINS'), findsOneWidget);
    expect(find.text('BOARD THEMES'), findsOneWidget);
  });

  testWidgets('LeaderboardScreen displays Season 4 and top podium', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.darkTheme,
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: LeaderboardScreen(),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('LEADERBOARD - SEASON 4'), findsOneWidget);
    expect(find.text('Global'), findsOneWidget);
  });

  testWidgets('GameScreen displays game board and HUD', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: AppTheme.darkTheme,
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: GameScreen(
            mode: GameMode.vsAi,
            difficulty: Difficulty.medium,
          ),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Computer'), findsOneWidget);
  });
}
