import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/constants/app_strings.dart';
import 'package:twelvetani/core/settings/settings_service.dart';
import 'package:twelvetani/models/app_language.dart';
import 'package:twelvetani/views/widgets/language_picker_sheet.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Multi-Language Localization Tests', () {
    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      final settings = SettingsService();
      await settings.resetToDefaults();
    });

    test('All 6 languages are defined with correct RTL/LTR directions', () {
      expect(AppLanguage.values.length, equals(6));
      expect(AppLanguage.urdu.isRtl, isTrue);
      expect(AppLanguage.english.isRtl, isFalse);
      expect(AppLanguage.hindi.isRtl, isFalse);
      expect(AppLanguage.punjabi.isRtl, isTrue);
      expect(AppLanguage.arabic.isRtl, isTrue);
      expect(AppLanguage.bengali.isRtl, isFalse);
    });

    test('Language switching updates AppStrings translations', () async {
      final settings = SettingsService();

      // Urdu (Default)
      await settings.setLanguage(AppLanguage.urdu);
      expect(AppStrings.appName, equals('12 ٹہنی'));
      expect(AppStrings.singlePlayer, equals('سنگل پلیئر (بمقابلہ AI)'));

      // English
      await settings.setLanguage(AppLanguage.english);
      expect(AppStrings.appName, equals('12 Tani'));
      expect(AppStrings.singlePlayer, equals('Single Player (vs AI)'));
      expect(AppStrings.dailyBonus, equals('Daily Bonus'));
      expect(AppStrings.luckySpin, equals('Lucky Wheel'));

      // Hindi
      await settings.setLanguage(AppLanguage.hindi);
      expect(AppStrings.singlePlayer, equals('सिंगल प्लेयर (बनाम AI)'));
      expect(AppStrings.dailyBonus, equals('दैनिक बोनस'));

      // Punjabi
      await settings.setLanguage(AppLanguage.punjabi);
      expect(AppStrings.appName, equals('12 ٹہنی'));

      // Arabic
      await settings.setLanguage(AppLanguage.arabic);
      expect(AppStrings.singlePlayer, equals('لاعب فردي (ضد الذكاء الاصطناعي)'));

      // Bengali
      await settings.setLanguage(AppLanguage.bengali);
      expect(AppStrings.singlePlayer, equals('একক খেলোয়াড় (বনাম AI)'));
    });

    testWidgets('LanguagePickerSheet renders all 6 language options with flags', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: LanguagePickerSheet(),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('اردو'), findsOneWidget);
      expect(find.text('English'), findsWidgets);
      expect(find.text('हिन्दी'), findsOneWidget);
      expect(find.text('پنجابی'), findsOneWidget);
      expect(find.text('العربية'), findsOneWidget);
      expect(find.text('বাংলা'), findsOneWidget);
    });

    test('Settings options, piece colors, and styles translate across languages', () async {
      final settings = SettingsService();

      // Urdu
      await settings.setLanguage(AppLanguage.urdu);
      expect(AppStrings.playerNamesSection, equals('پلیئرز کے نام (Player Names)'));
      expect(AppStrings.beadColorsSection, equals('مہروں کے دلکش رنگ (Bead Colors)'));
      expect(AppStrings.pieceStylesSection, equals('مہروں کے مختلف ڈیزائن اور اشکال (Piece Styles)'));

      // English
      await settings.setLanguage(AppLanguage.english);
      expect(AppStrings.playerNamesSection, equals('Player Names'));
      expect(AppStrings.beadColorsSection, equals('Piece Colors'));
      expect(AppStrings.pieceStylesSection, equals('Piece Styles & Designs'));
      expect(AppStrings.boardThemeSection, equals('Board Theme & Style'));

      // Hindi
      await settings.setLanguage(AppLanguage.hindi);
      expect(AppStrings.playerNamesSection, equals('खिलाड़ियों के नाम'));
      expect(AppStrings.beadColorsSection, equals('मोहरों के आकर्षक रंग'));
      expect(AppStrings.pieceStylesSection, equals('मोहरों के विभिन्न डिजाइन'));
    });
  });
}
