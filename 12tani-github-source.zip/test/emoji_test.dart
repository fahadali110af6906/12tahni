import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/models/game_emoji.dart';
import 'package:twelvetani/models/player_type.dart';
import 'package:twelvetani/providers/game_controller.dart';
import 'package:twelvetani/views/widgets/emoji_picker_modal.dart';
import 'package:twelvetani/views/widgets/floating_emoji_bubble.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('GameEmoji & Reactions Tests', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });

    test('Send emoji updates controller and triggers listener', () {
      final controller = GameController();
      expect(controller.player2Emoji, isNull);

      final emoji = GameEmoji.availableEmojis.first; // 😂
      controller.sendEmoji(PlayerType.player2, emoji);

      expect(controller.player2Emoji, equals(emoji));
    });

    testWidgets('FloatingEmojiBubble renders emoji and Urdu text', (WidgetTester tester) async {
      const emoji = GameEmoji(id: 'fire', emoji: '🔥', labelUrdu: 'شاندار!');

      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: Center(
                child: FloatingEmojiBubble(
                  emoji: emoji,
                  isTopPlayer: false,
                ),
              ),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('🔥'), findsOneWidget);
      expect(find.text('شاندار!'), findsOneWidget);
    });

    testWidgets('EmojiPickerModal renders all 12 emojis and triggers callback', (WidgetTester tester) async {
      GameEmoji? selected;

      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: EmojiPickerModal(
                onEmojiSelected: (e) {
                  selected = e;
                },
              ),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('😂'), findsOneWidget);
      expect(find.text('😎'), findsOneWidget);
      expect(find.text('🔥'), findsOneWidget);

      await tester.tap(find.text('🔥'));
      expect(selected?.id, equals('fire'));
    });
  });
}
