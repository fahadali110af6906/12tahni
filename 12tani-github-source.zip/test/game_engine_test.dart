import 'package:flutter_test/flutter_test.dart';
import 'package:twelvetani/engine/board_topology.dart';
import 'package:twelvetani/engine/rule_engine.dart';
import 'package:twelvetani/engine/ai_engine.dart';
import 'package:twelvetani/models/board_point.dart';
import 'package:twelvetani/models/difficulty.dart';
import 'package:twelvetani/models/player_type.dart';

void main() {
  group('12 Tani Board Topology & Geometry Tests', () {
    test('Total points must be 25 (5x5)', () {
      expect(BoardTopology.getNeighbors(const BoardPoint(0, 0)).isNotEmpty, isTrue);
      expect(BoardPoint.fromIndex(12), equals(const BoardPoint(2, 2)));
      expect(const BoardPoint(2, 2).index, equals(12));
    });

    test('Center point (2,2) has 8 connections (4 orthogonal + 4 diagonal)', () {
      final center = const BoardPoint(2, 2);
      final neighbors = BoardTopology.getNeighbors(center);
      expect(neighbors.length, equals(8));
      expect(neighbors.contains(const BoardPoint(1, 1)), isTrue);
      expect(neighbors.contains(const BoardPoint(1, 2)), isTrue);
      expect(neighbors.contains(const BoardPoint(1, 3)), isTrue);
      expect(neighbors.contains(const BoardPoint(2, 1)), isTrue);
      expect(neighbors.contains(const BoardPoint(2, 3)), isTrue);
      expect(neighbors.contains(const BoardPoint(3, 1)), isTrue);
      expect(neighbors.contains(const BoardPoint(3, 2)), isTrue);
      expect(neighbors.contains(const BoardPoint(3, 3)), isTrue);
    });

    test('Point (0,1) with odd parity has 3 orthogonal connections and 0 diagonals', () {
      final p01 = const BoardPoint(0, 1);
      final neighbors = BoardTopology.getNeighbors(p01);
      expect(neighbors.length, equals(3)); // (0,0), (0,2), (1,1)
      expect(neighbors.contains(const BoardPoint(0, 0)), isTrue);
      expect(neighbors.contains(const BoardPoint(0, 2)), isTrue);
      expect(neighbors.contains(const BoardPoint(1, 1)), isTrue);
    });
  });

  group('Rule Engine Tests', () {
    test('Initial Board Setup has 12 pieces for P1, 12 pieces for P2, center empty', () {
      final board = RuleEngine.createInitialBoard();
      expect(board.length, equals(25));
      expect(RuleEngine.countPieces(board, PlayerType.player1), equals(12));
      expect(RuleEngine.countPieces(board, PlayerType.player2), equals(12));
      expect(board[12], isNull); // Center (2,2) is empty
    });

    test('Jump capture correctly removes jumped opponent piece', () {
      final board = List<PlayerType?>.filled(25, null);
      board[0] = PlayerType.player2; // (0,0) Green
      board[6] = PlayerType.player1; // (1,1) Red
      // (2,2) is empty

      final moves = RuleEngine.getLegalMovesForPoint(
        board,
        const BoardPoint(0, 0),
        PlayerType.player2,
      );

      final jumpMove = moves.firstWhere((m) => m.isJump);
      expect(jumpMove.to, equals(const BoardPoint(2, 2)));
      expect(jumpMove.capturedPoint, equals(const BoardPoint(1, 1)));

      final newBoard = RuleEngine.applyMove(board, jumpMove, PlayerType.player2);
      expect(newBoard[0], isNull);
      expect(newBoard[6], isNull); // Captured piece removed!
      expect(newBoard[12], equals(PlayerType.player2)); // Landed at (2,2)
      expect(RuleEngine.countPieces(newBoard, PlayerType.player1), equals(0));
    });

    test('Game over detected when player has 0 pieces remaining', () {
      final board = List<PlayerType?>.filled(25, null);
      board[12] = PlayerType.player2;

      final status = RuleEngine.checkGameStatus(board, PlayerType.player1);
      expect(status.isGameOver, isTrue);
      expect(status.winner, equals(PlayerType.player2));
    });
  });

  group('AI Engine Multi-Difficulty Tests', () {
    test('Easy, Medium, and Hard AI generate valid legal moves from initial board', () async {
      final board = RuleEngine.createInitialBoard();

      // Test Easy AI
      final easyMove = await AiEngine.chooseMove(
        board: board,
        aiPlayer: PlayerType.player1,
        difficulty: Difficulty.easy,
      );
      expect(easyMove, isNotNull);
      expect(board[easyMove!.from.index], equals(PlayerType.player1));
      expect(board[easyMove.to.index], isNull);

      // Test Medium AI
      final medMove = await AiEngine.chooseMove(
        board: board,
        aiPlayer: PlayerType.player1,
        difficulty: Difficulty.medium,
      );
      expect(medMove, isNotNull);
      expect(board[medMove!.from.index], equals(PlayerType.player1));
      expect(board[medMove.to.index], isNull);

      // Test Hard AI
      final hardMove = await AiEngine.chooseMove(
        board: board,
        aiPlayer: PlayerType.player1,
        difficulty: Difficulty.hard,
      );
      expect(hardMove, isNotNull);
      expect(board[hardMove!.from.index], equals(PlayerType.player1));
      expect(board[hardMove.to.index], isNull);
    });

    test('Hard AI prioritizes immediate capture when available', () async {
      final board = List<PlayerType?>.filled(25, null);
      board[0] = PlayerType.player1; // (0,0) AI
      board[6] = PlayerType.player2; // (1,1) Opponent
      board[24] = PlayerType.player2; // dummy

      final hardMove = await AiEngine.chooseMove(
        board: board,
        aiPlayer: PlayerType.player1,
        difficulty: Difficulty.hard,
      );

      expect(hardMove, isNotNull);
      expect(hardMove!.isJump, isTrue);
      expect(hardMove.to, equals(const BoardPoint(2, 2)));
    });
  });
}
