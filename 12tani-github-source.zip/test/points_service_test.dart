import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/points/points_service.dart';
import 'package:twelvetani/views/widgets/daily_bonus_dialog.dart';
import 'package:twelvetani/views/widgets/lucky_spin_wheel_dialog.dart';
import 'package:twelvetani/views/widgets/points_badge.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Points Economy & Bonus Tests', () {
    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      final service = PointsService();
      await service.resetPoints(100);
    });

    test('PointsService initializes with 100 default points', () async {
      final service = PointsService();
      await service.init();
      expect(service.points, equals(100));
    });

    test('addPoints adds points correctly', () async {
      final service = PointsService();
      await service.addPoints(10);
      expect(service.points, equals(110));
    });

    test('deductPoints deducts points and prevents negative balance', () async {
      final service = PointsService();
      final success1 = await service.deductPoints(10);
      expect(success1, isTrue);
      expect(service.points, equals(90));

      final success2 = await service.deductPoints(200);
      expect(success2, isFalse);
      expect(service.points, equals(90));
    });

    test('claimDailyBonus awards 100 points once per day', () async {
      final service = PointsService();
      expect(service.isDailyBonusAvailable(), isTrue);

      final reward = await service.claimDailyBonus();
      expect(reward, equals(100));
      expect(service.points, equals(200));

      // Cannot claim again on same day
      expect(service.isDailyBonusAvailable(), isFalse);
      final reward2 = await service.claimDailyBonus();
      expect(reward2, equals(0));
      expect(service.points, equals(200));
    });

    testWidgets('PointsBadge displays current wallet points', (WidgetTester tester) async {
      final service = PointsService();
      await service.resetPoints(150);

      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: PointsBadge(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('150'), findsOneWidget);
      expect(find.byIcon(Icons.monetization_on), findsOneWidget);
    });

    testWidgets('LuckySpinWheelDialog renders spin wheel with action button', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: LuckySpinWheelDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('قسمت کا پہیہ'), findsOneWidget);
      expect(find.text('پہیہ گھمائیں'), findsOneWidget);
    });

    testWidgets('DailyBonusDialog renders daily bonus claim dialog', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: DailyBonusDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('🎁 روزانہ کا مفت تحفہ!'), findsOneWidget);
      expect(find.text('+100 پوائنٹس'), findsOneWidget);
    });

    test('Lucky Wheel enforces 10-hour cooldown between spins', () async {
      final service = PointsService();
      expect(service.isSpinAvailable(), isTrue);
      expect(service.timeUntilNextSpin(), equals(Duration.zero));

      await service.recordSpin();
      expect(service.isSpinAvailable(), isFalse);
      final remaining = service.timeUntilNextSpin();
      expect(remaining.inMinutes, greaterThan(0));
      expect(remaining.inHours, lessThanOrEqualTo(10));
    });
  });
}
