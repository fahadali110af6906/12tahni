import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/constants/game_constants.dart';
import 'package:twelvetani/models/game_mode.dart';
import 'package:twelvetani/models/player_type.dart';
import 'package:twelvetani/providers/game_controller.dart';
import 'package:twelvetani/views/widgets/player_card.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('10-Second Turn Timer & 5 Timeout Strikes Tests', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });

    test('Initial game state has 10s turn timer and 0 timeout strikes', () {
      final controller = GameController();
      expect(controller.state.turnTimeRemaining, equals(GameConstants.turnTimerSeconds));
      expect(controller.state.player1Timeouts, equals(0));
      expect(controller.state.player2Timeouts, equals(0));
      expect(controller.state.isTimeoutVictory, isFalse);
      controller.dispose();
    });

    testWidgets('PlayerCard renders 10s countdown timer and 5 timeout strike dots', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: PlayerCard(
                player: PlayerType.player2,
                mode: GameMode.vsAi,
                piecesRemaining: 12,
                isCurrentTurn: true,
                turnTimeRemaining: 8,
                timeoutStrikes: 2,
              ),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('8s'), findsOneWidget);
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });
  });
}
