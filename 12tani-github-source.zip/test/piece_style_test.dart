import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/settings/settings_service.dart';
import 'package:twelvetani/models/piece_style.dart';
import 'package:twelvetani/models/player_type.dart';
import 'package:twelvetani/views/widgets/piece_widget.dart';
import 'package:twelvetani/views/widgets/settings_dialog.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('PieceStyle Tests', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });

    test('PieceStyle enum has 6 distinct designs with Urdu labels', () {
      expect(PieceStyle.values.length, equals(6));
      expect(PieceStyle.crystalMarble.labelUrdu, equals('کرسٹل ماربل'));
      expect(PieceStyle.royalCoin.labelUrdu, equals('طلائی سکہ'));
      expect(PieceStyle.facetedGem.labelUrdu, equals('تراشیدہ ہیرا'));
      expect(PieceStyle.royalCrown.labelUrdu, equals('شاہی تاج'));
      expect(PieceStyle.warriorShield.labelUrdu, equals('جنگی ڈھال'));
      expect(PieceStyle.mughalFloral.labelUrdu, equals('مغل پھول'));
    });

    test('SettingsService updates and persists piece styles', () async {
      final settings = SettingsService();
      await settings.init();

      await settings.setPlayer1Style(PieceStyle.royalCrown);
      expect(settings.player1Style, equals(PieceStyle.royalCrown));

      await settings.setPlayer2Style(PieceStyle.facetedGem);
      expect(settings.player2Style, equals(PieceStyle.facetedGem));

      await settings.resetToDefaults();
      expect(settings.player1Style, equals(PieceStyle.crystalMarble));
      expect(settings.player2Style, equals(PieceStyle.crystalMarble));
    });

    testWidgets('PieceWidget renders all 6 piece styles without error', (WidgetTester tester) async {
      for (final style in PieceStyle.values) {
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: Center(
                child: PieceWidget(
                  player: PlayerType.player1,
                  customStyle: style,
                ),
              ),
            ),
          ),
        );
        await tester.pump();
        expect(find.byType(PieceWidget), findsOneWidget);
      }
    });

    testWidgets('SettingsDialog renders Piece Styles section', (WidgetTester tester) async {
      SharedPreferences.setMockInitialValues({});
      final settings = SettingsService();
      await settings.init();

      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: SettingsDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('مہروں کے مختلف ڈیزائن اور اشکال (Piece Styles)'), findsOneWidget);
    });
  });
}
