import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/constants/app_strings.dart';
import 'package:twelvetani/core/settings/settings_service.dart';
import 'package:twelvetani/models/board_theme_type.dart';
import 'package:twelvetani/models/piece_color_theme.dart';
import 'package:twelvetani/models/user_profile.dart';
import 'package:twelvetani/views/widgets/edit_profile_dialog.dart';
import 'package:twelvetani/views/widgets/settings_dialog.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('SettingsService Tests', () {
    setUp(() {
      SharedPreferences.setMockInitialValues({});
    });

    test('Default values and updates for names, colors, and themes', () async {
      final settings = SettingsService();
      await settings.init();

      // Test custom names
      await settings.setPlayer1Name('شہزاد');
      expect(settings.player1Name, equals('شہزاد'));

      await settings.setPlayer2Name('احمد');
      expect(settings.player2Name, equals('احمد'));

      // Test custom bead colors
      await settings.setPlayer1Color(PieceColorOption.sapphireBlue);
      expect(settings.player1Color, equals(PieceColorOption.sapphireBlue));

      await settings.setPlayer2Color(PieceColorOption.goldenAmber);
      expect(settings.player2Color, equals(PieceColorOption.goldenAmber));

      // Test board theme
      await settings.setBoardTheme(BoardThemeType.royalMarble);
      expect(settings.boardTheme, equals(BoardThemeType.royalMarble));

      // Test toggles
      await settings.setHintsEnabled(false);
      expect(settings.hintsEnabled, isFalse);

      await settings.setFastAiEnabled(true);
      expect(settings.fastAiEnabled, isTrue);

      // Test reset
      await settings.resetToDefaults();
      expect(settings.player1Name, equals('کھلاڑی ۱'));
      expect(settings.player2Name, equals('آپ (سبز)'));
      expect(settings.player1Color, equals(PieceColorOption.rubyRed));
      expect(settings.player2Color, equals(PieceColorOption.emeraldGreen));
      expect(settings.boardTheme, equals(BoardThemeType.classicWood));
    });
  });

  group('SettingsDialog Widget Test', () {
    testWidgets('Renders settings dialog and all options', (WidgetTester tester) async {
      SharedPreferences.setMockInitialValues({});
      final settings = SettingsService();
      await settings.init();

      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: SettingsDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('پلیئرز کے نام (Player Names)'), findsOneWidget);
      expect(find.text('مہروں کے دلکش رنگ (Bead Colors)'), findsOneWidget);
      expect(find.text('بورڈ کا انداز اور تھیم (Board Theme)'), findsOneWidget);
      expect(find.text('آواز اور گیم پلے (Audio & Gameplay)'), findsOneWidget);
    });

    testWidgets('EditProfileDialog allows changing name and avatar', (WidgetTester tester) async {
      SharedPreferences.setMockInitialValues({});
      final user = UserProfile();
      await user.init();

      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: EditProfileDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text(AppStrings.editProfile), findsOneWidget);
      expect(find.text(AppStrings.chooseAvatar), findsOneWidget);
      expect(find.text(AppStrings.save.toUpperCase()), findsOneWidget);

      // Enter a new name
      await tester.enterText(find.byType(TextField), 'Fahad King');
      await tester.pump();

      // Tap on an avatar emoji
      await tester.tap(find.text('🦁'));
      await tester.pump();

      // Tap Save button
      await tester.tap(find.text(AppStrings.save.toUpperCase()));
      await tester.pump();

      expect(user.name, equals('Fahad King'));
      expect(user.avatar, equals('🦁'));
    });
  });
}
