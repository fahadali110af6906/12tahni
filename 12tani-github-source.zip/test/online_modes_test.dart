import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twelvetani/core/constants/app_strings.dart';
import 'package:twelvetani/core/settings/settings_service.dart';
import 'package:twelvetani/models/game_mode.dart';
import 'package:twelvetani/views/widgets/friend_room_dialog.dart';
import 'package:twelvetani/views/widgets/online_lobby_dialog.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('Online & Friend Match Tests', () {
    setUp(() async {
      SharedPreferences.setMockInitialValues({});
      final settings = SettingsService();
      await settings.resetToDefaults();
    });

    test('GameMode enum contains all 4 game modes with localized titles', () {
      expect(GameMode.values.length, equals(4));
      expect(GameMode.values.contains(GameMode.vsAi), isTrue);
      expect(GameMode.values.contains(GameMode.passAndPlay), isTrue);
      expect(GameMode.values.contains(GameMode.onlineMatch), isTrue);
      expect(GameMode.values.contains(GameMode.playWithFriend), isTrue);

      expect(GameMode.onlineMatch.titleUrdu, equals(AppStrings.onlineMatch));
      expect(GameMode.playWithFriend.titleUrdu, equals(AppStrings.playWithFriend));
    });

    testWidgets('OnlineLobbyDialog renders radar matchmaking UI', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: OnlineLobbyDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text(AppStrings.onlineMatch), findsOneWidget);
      expect(find.text(AppStrings.searchingOnlineOpponent), findsOneWidget);
      expect(find.textContaining('Ping'), findsOneWidget);
    });

    testWidgets('FriendRoomDialog renders Create Room & Join Room tabs', (WidgetTester tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: FriendRoomDialog(),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text(AppStrings.playWithFriend), findsOneWidget);
      expect(find.text(AppStrings.createRoom), findsWidgets);
      expect(find.text(AppStrings.joinRoom), findsWidgets);
      expect(find.text(AppStrings.copyCode), findsOneWidget);
      expect(find.text(AppStrings.share), findsOneWidget);
      expect(find.text('ENTER ROOM (LOBBY)'), findsOneWidget);

      // Switch to Join Room tab
      await tester.tap(find.text(AppStrings.joinRoom).first);
      await tester.pumpAndSettle();

      expect(find.text(AppStrings.enterRoomCode), findsOneWidget);
    });
  });
}
