package com.antigravity.twelvetani.twelvetani

import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.SoundPool
import io.flutter.FlutterInjector
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.antigravity.twelvetani/sound"
    private var soundPool: SoundPool? = null
    private val soundMap = HashMap<String, Int>()

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(6)
            .setAudioAttributes(audioAttributes)
            .build()

        // Preload sounds
        val soundFiles = listOf("move.wav", "capture.wav", "select.wav", "invalid.wav", "victory.wav", "button.wav")
        val flutterLoader = FlutterInjector.instance().flutterLoader()

        for (file in soundFiles) {
            try {
                val assetKey = flutterLoader.getLookupKeyForAsset("assets/audio/$file")
                val afd: AssetFileDescriptor = assets.openFd(assetKey)
                val soundId = soundPool?.load(afd, 1) ?: 0
                soundMap[file] = soundId
            } catch (e: Exception) {
                try {
                    val afd = assets.openFd("flutter_assets/assets/audio/$file")
                    val soundId = soundPool?.load(afd, 1) ?: 0
                    soundMap[file] = soundId
                } catch (_: Exception) {}
            }
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "playSound" -> {
                    val soundFile = call.argument<String>("file")
                    if (soundFile != null && soundMap.containsKey(soundFile)) {
                        val soundId = soundMap[soundFile] ?: 0
                        if (soundId > 0) {
                            soundPool?.play(soundId, 1.0f, 1.0f, 1, 0, 1.0f)
                        }
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onDestroy() {
        soundPool?.release()
        soundPool = null
        super.onDestroy()
    }
}
