import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core/audio/sound_service.dart';
import 'core/constants/app_strings.dart';
import 'core/points/points_service.dart';
import 'core/settings/settings_service.dart';
import 'core/supabase/supabase_service.dart';
import 'core/theme/app_theme.dart';
import 'models/user_profile.dart';
import 'views/screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock orientation to portrait for optimal board gameplay experience
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Set system UI overlay style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF090D16),
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  // Initialize core services
  await SoundService().init();
  await SettingsService().init();
  await PointsService().init();
  await UserProfile().init();
  await SupabaseService().init();

  runApp(const TwelveTaniApp());
}

/// Custom ScrollBehavior enabling mouse drag, wheel, touch and stylus scrolling everywhere
class AppScrollBehavior extends MaterialScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.trackpad,
        PointerDeviceKind.stylus,
        PointerDeviceKind.unknown,
      };
}

class TwelveTaniApp extends StatelessWidget {
  const TwelveTaniApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = SettingsService();

    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return MaterialApp(
          title: AppStrings.appName,
          debugShowCheckedModeBanner: false,
          theme: AppTheme.darkTheme,
          scrollBehavior: AppScrollBehavior(),
          home: Directionality(
            textDirection: settings.language.direction,
            child: const SplashScreen(),
          ),
        );
      },
    );
  }
}
