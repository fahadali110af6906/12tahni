import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import '../core/audio/sound_service.dart';
import '../core/constants/app_strings.dart';
import '../core/constants/game_constants.dart';
import '../core/points/points_service.dart';
import '../core/settings/settings_service.dart';
import '../engine/ai_engine.dart';
import '../engine/rule_engine.dart';
import '../models/board_point.dart';
import '../models/difficulty.dart';
import '../models/game_emoji.dart';
import '../models/game_mode.dart';
import '../models/game_move.dart';
import '../models/game_state.dart';
import '../models/player_type.dart';

class GameController extends ChangeNotifier {
  late GameState _state;
  final SoundService _sound = SoundService();
  final SettingsService _settings = SettingsService();
  final PointsService _pointsService = PointsService();
  String? _feedbackMessage;

  GameEmoji? _player1Emoji;
  GameEmoji? _player2Emoji;
  Timer? _p1EmojiTimer;
  Timer? _p2EmojiTimer;
  Timer? _turnTimer;

  GameState get state => _state;
  String? get feedbackMessage => _feedbackMessage;
  GameEmoji? get player1Emoji => _player1Emoji;
  GameEmoji? get player2Emoji => _player2Emoji;

  bool isRemoteMultiplayer = false;
  PlayerType localPlayerType = PlayerType.player2;
  ValueChanged<GameMove>? onMoveExecuted;

  GameController({
    GameMode initialMode = GameMode.vsAi,
    Difficulty initialDifficulty = Difficulty.medium,
    this.isRemoteMultiplayer = false,
    this.localPlayerType = PlayerType.player2,
  }) {
    _initGame(mode: initialMode, difficulty: initialDifficulty);
  }

  void _initGame({required GameMode mode, required Difficulty difficulty}) {
    _turnTimer?.cancel();
    final board = RuleEngine.createInitialBoard();
    _state = GameState(
      board: board,
      currentTurn: PlayerType.player2, // Player 2 (Human) goes first
      mode: mode,
      difficulty: difficulty,
      player1Pieces: GameConstants.piecesPerPlayer,
      player2Pieces: GameConstants.piecesPerPlayer,
      turnTimeRemaining: GameConstants.turnTimerSeconds,
      player1Timeouts: 0,
      player2Timeouts: 0,
      isTimeoutVictory: false,
    );
    _feedbackMessage = null;
    _player1Emoji = null;
    _player2Emoji = null;
    _p1EmojiTimer?.cancel();
    _p2EmojiTimer?.cancel();
    notifyListeners();

    _startTurnTimer();
  }

  void startNewGame({GameMode? mode, Difficulty? difficulty}) {
    _sound.playButtonClick();
    _initGame(
      mode: mode ?? _state.mode,
      difficulty: difficulty ?? _state.difficulty,
    );
  }

  void restartGame() {
    _sound.playButtonClick();
    _initGame(mode: _state.mode, difficulty: _state.difficulty);
  }

  void pauseGame() {
    _sound.playButtonClick();
    _turnTimer?.cancel();
    _state = _state.copyWith(isPaused: true);
    notifyListeners();
  }

  void resumeGame() {
    _sound.playButtonClick();
    _state = _state.copyWith(isPaused: false);
    notifyListeners();
    _startTurnTimer();
  }

  void setDifficulty(Difficulty difficulty) {
    _sound.playButtonClick();
    _state = _state.copyWith(difficulty: difficulty);
    notifyListeners();
  }

  void setGameMode(GameMode mode) {
    _sound.playButtonClick();
    startNewGame(mode: mode);
  }

  void clearFeedback() {
    _feedbackMessage = null;
    notifyListeners();
  }

  /// Turn timer: 10s countdown per turn with 5-strike timeout rule
  void _startTurnTimer() {
    _turnTimer?.cancel();
    if (_state.isGameOver || _state.isPaused) return;

    _state = _state.copyWith(turnTimeRemaining: GameConstants.turnTimerSeconds);

    _turnTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_state.isGameOver || _state.isPaused) {
        timer.cancel();
        return;
      }

      final remaining = _state.turnTimeRemaining - 1;

      if (remaining > 0) {
        _state = _state.copyWith(turnTimeRemaining: remaining);
        notifyListeners();
      } else {
        // Timer ran out!
        timer.cancel();
        _handleTurnTimeout();
      }
    });
  }

  void _handleTurnTimeout() {
    if (_state.isGameOver || _state.isPaused) return;

    final timedOutPlayer = _state.currentTurn;
    final isP1 = timedOutPlayer == PlayerType.player1;

    final newP1Timeouts = isP1 ? _state.player1Timeouts + 1 : _state.player1Timeouts;
    final newP2Timeouts = !isP1 ? _state.player2Timeouts + 1 : _state.player2Timeouts;

    final currentStrikes = isP1 ? newP1Timeouts : newP2Timeouts;

    // Check if 5 timeout strikes reached -> Instant Game Over!
    if (currentStrikes >= GameConstants.maxTimeoutStrikes) {
      final winner = timedOutPlayer.opponent;
      _state = _state.copyWith(
        turnTimeRemaining: 0,
        player1Timeouts: newP1Timeouts,
        player2Timeouts: newP2Timeouts,
        isGameOver: true,
        winner: winner,
        isTimeoutVictory: true,
        clearSelectedPoint: true,
        clearChainJumpPoint: true,
      );
      _sound.playVictory();
      _feedbackMessage = AppStrings.timeoutDefeatDesc;

      if (winner == PlayerType.player2) {
        _pointsService.addPoints(PointsService.victoryPointsReward);
      }

      notifyListeners();
      return;
    }

    // Otherwise, warning and switch turn to opponent
    _sound.playInvalid();
    _feedbackMessage = AppStrings.turnSwitchedTimeout;

    _state = _state.copyWith(
      turnTimeRemaining: GameConstants.turnTimerSeconds,
      player1Timeouts: newP1Timeouts,
      player2Timeouts: newP2Timeouts,
      clearSelectedPoint: true,
      clearChainJumpPoint: true,
      validMovesForSelected: [],
    );

    _endTurn();
  }

  /// Send an in-game reaction emoji from [player]
  void sendEmoji(PlayerType player, GameEmoji emoji) {
    if (player == PlayerType.player1) {
      _p1EmojiTimer?.cancel();
      _player1Emoji = emoji;
      _p1EmojiTimer = Timer(const Duration(milliseconds: 2400), () {
        _player1Emoji = null;
        notifyListeners();
      });
    } else {
      _p2EmojiTimer?.cancel();
      _player2Emoji = emoji;
      _p2EmojiTimer = Timer(const Duration(milliseconds: 2400), () {
        _player2Emoji = null;
        notifyListeners();
      });

      if ((_state.mode == GameMode.vsAi ||
              _state.mode == GameMode.onlineMatch ||
              _state.mode == GameMode.playWithFriend) &&
          !_state.isGameOver) {
        _triggerAiEmojiResponse(emoji);
      }
    }
    notifyListeners();
  }

  void _triggerAiEmojiResponse(GameEmoji userEmoji) {
    Future.delayed(const Duration(milliseconds: 750), () {
      if (_state.isGameOver || _player1Emoji != null) return;

      GameEmoji aiResponse;
      switch (userEmoji.id) {
        case 'laugh':
          aiResponse = const GameEmoji(id: 'devil', emoji: '😈', labelUrdu: 'دیکھتے ہیں!');
          break;
        case 'devil':
        case 'fire':
          aiResponse = const GameEmoji(id: 'cool', emoji: '😎', labelUrdu: 'میں تیار ہوں!');
          break;
        case 'shock':
        case 'cry':
          aiResponse = const GameEmoji(id: 'laugh', emoji: '😂', labelUrdu: 'ہاہاہا!');
          break;
        case 'trophy':
          aiResponse = const GameEmoji(id: 'target', emoji: '🎯', labelUrdu: 'ابھی نہیں!');
          break;
        case 'handshake':
        case 'clap':
          aiResponse = const GameEmoji(id: 'handshake', emoji: '🤝', labelUrdu: 'شکریہ!');
          break;
        default:
          aiResponse = const GameEmoji(id: 'think', emoji: '🤔', labelUrdu: 'سوچ رہا ہوں...');
      }

      sendEmoji(PlayerType.player1, aiResponse);
    });
  }

  /// Handles human tap on a board point
  Future<void> onPointTapped(BoardPoint point) async {
    if (_state.isGameOver || _state.isPaused || _state.isAiThinking) {
      return;
    }

    if (_state.mode == GameMode.vsAi && _state.currentTurn == PlayerType.player1) {
      _triggerInvalidMove(AppStrings.computerTurn);
      return;
    }

    if (isRemoteMultiplayer && _state.currentTurn != localPlayerType) {
      _triggerInvalidMove(AppStrings.notYourTurn);
      return;
    }

    // 1. If currently in a chain jump mode
    if (_state.chainJumpPoint != null) {
      final chainMoves = _state.validMovesForSelected;
      final selectedMove = chainMoves.cast<GameMove?>().firstWhere(
            (m) => m?.to == point,
            orElse: () => null,
          );

      if (selectedMove != null) {
        await _executeHumanMove(selectedMove);
      } else if (point == _state.chainJumpPoint) {
        _endTurn();
      } else {
        _triggerInvalidMove(AppStrings.chainJumpTurn);
      }
      return;
    }

    final pieceAtPoint = _state.board[point.index];

    // 2. If no piece is currently selected
    if (_state.selectedPoint == null) {
      if (pieceAtPoint == _state.currentTurn) {
        final validMoves = RuleEngine.getLegalMovesForPoint(
          _state.board,
          point,
          _state.currentTurn,
        );

        if (validMoves.isNotEmpty) {
          _sound.playSelect();
          _state = _state.copyWith(
            selectedPoint: point,
            validMovesForSelected: validMoves,
          );
          _feedbackMessage = AppStrings.tapTargetToMove;
          notifyListeners();
        } else {
          _triggerInvalidMove('اس مہرے کی کوئی درست چال موجود نہیں ہے');
        }
      } else if (pieceAtPoint != null) {
        _triggerInvalidMove(AppStrings.notYourTurn);
      }
      return;
    }

    // 3. A piece is already selected
    if (_state.selectedPoint == point) {
      _state = _state.copyWith(
        clearSelectedPoint: true,
        validMovesForSelected: [],
      );
      _feedbackMessage = null;
      notifyListeners();
      return;
    }

    // If user selects another own piece
    if (pieceAtPoint == _state.currentTurn) {
      final validMoves = RuleEngine.getLegalMovesForPoint(
        _state.board,
        point,
        _state.currentTurn,
      );

      if (validMoves.isNotEmpty) {
        _sound.playSelect();
        _state = _state.copyWith(
          selectedPoint: point,
          validMovesForSelected: validMoves,
        );
        _feedbackMessage = AppStrings.tapTargetToMove;
        notifyListeners();
      } else {
        _triggerInvalidMove('اس مہرے کی کوئی درست چال موجود نہیں ہے');
      }
      return;
    }

    // Check if tapped point is a valid move target
    final move = _state.validMovesForSelected.cast<GameMove?>().firstWhere(
          (m) => m?.to == point,
          orElse: () => null,
        );

    if (move != null) {
      await _executeHumanMove(move);
    } else {
      _triggerInvalidMove(AppStrings.invalidMoveDesc);
    }
  }

  /// Executes human move and handles subsequent jump or AI response
  Future<void> _executeHumanMove(GameMove move) async {
    final player = _state.currentTurn;
    final newBoard = RuleEngine.applyMove(_state.board, move, player);
    final p1Count = RuleEngine.countPieces(newBoard, PlayerType.player1);
    final p2Count = RuleEngine.countPieces(newBoard, PlayerType.player2);

    if (move.isJump) {
      _sound.playCapture();

      // Award +10 Points on successful piece capture!
      await _pointsService.addPoints(PointsService.capturePointsReward);

      if (_state.mode == GameMode.vsAi && Random().nextDouble() < 0.45) {
        final shockEmojis = [
          const GameEmoji(id: 'shock', emoji: '😱', labelUrdu: 'اوہ نہیں!'),
          const GameEmoji(id: 'cry', emoji: '😭', labelUrdu: 'میرا مہرہ!'),
          const GameEmoji(id: 'think', emoji: '🤔', labelUrdu: 'اچھی چال!'),
        ];
        sendEmoji(PlayerType.player1, shockEmojis[Random().nextInt(shockEmojis.length)]);
      }
    } else {
      _sound.playMove();
    }

    final newHistory = List<GameMove>.from(_state.moveHistory)..add(move);

    // Check if chain jump is available
    if (move.isJump) {
      final subsequentJumps = RuleEngine.getSubsequentJumps(newBoard, move.to, player);
      if (subsequentJumps.isNotEmpty) {
        _state = _state.copyWith(
          board: newBoard,
          player1Pieces: p1Count,
          player2Pieces: p2Count,
          selectedPoint: move.to,
          chainJumpPoint: move.to,
          validMovesForSelected: subsequentJumps,
          totalMoves: _state.totalMoves + 1,
          moveHistory: newHistory,
          lastMove: move,
        );
        _feedbackMessage = AppStrings.chainJumpTurn;
        notifyListeners();
        _startTurnTimer();
        return;
      }
    }

    // Notify listeners/Supabase if callback registered
    onMoveExecuted?.call(move.copyWith(player: player));

    // Turn finishes
    _state = _state.copyWith(
      board: newBoard,
      player1Pieces: p1Count,
      player2Pieces: p2Count,
      clearSelectedPoint: true,
      clearChainJumpPoint: true,
      validMovesForSelected: [],
      totalMoves: _state.totalMoves + 1,
      moveHistory: newHistory,
      lastMove: move,
    );

    _endTurn();
  }

  /// Apply move received from remote online opponent over Supabase
  Future<void> applyRemoteMove(GameMove move) async {
    if (_state.isGameOver || _state.isPaused) return;

    final player = move.player ?? _state.currentTurn;
    final newBoard = RuleEngine.applyMove(_state.board, move, player);
    final p1Count = RuleEngine.countPieces(newBoard, PlayerType.player1);
    final p2Count = RuleEngine.countPieces(newBoard, PlayerType.player2);

    if (move.isJump) {
      _sound.playCapture();
    } else {
      _sound.playMove();
    }

    final newHistory = List<GameMove>.from(_state.moveHistory)..add(move);

    _state = _state.copyWith(
      board: newBoard,
      player1Pieces: p1Count,
      player2Pieces: p2Count,
      clearSelectedPoint: true,
      clearChainJumpPoint: true,
      validMovesForSelected: [],
      totalMoves: _state.totalMoves + 1,
      moveHistory: newHistory,
      lastMove: move,
    );

    _endTurn();
  }

  /// Receive emoji from remote opponent
  void receiveRemoteEmoji(String emojiSymbol) {
    sendEmoji(PlayerType.player1, GameEmoji(id: 'remote', emoji: emojiSymbol, labelUrdu: ''));
  }

  void _endTurn() {
    final nextPlayer = _state.currentTurn.opponent;
    final status = RuleEngine.checkGameStatus(_state.board, nextPlayer);

    if (status.isGameOver) {
      _turnTimer?.cancel();
      _state = _state.copyWith(
        isGameOver: true,
        winner: status.winner,
        clearSelectedPoint: true,
        clearChainJumpPoint: true,
      );
      _sound.playVictory();
      _feedbackMessage = status.winner == PlayerType.player2
          ? AppStrings.youWon
          : AppStrings.computerWon;

      // Award +50 Points victory bonus when human wins
      if (status.winner == PlayerType.player2) {
        _pointsService.addPoints(PointsService.victoryPointsReward);
      }

      notifyListeners();
      return;
    }

    _state = _state.copyWith(
      currentTurn: nextPlayer,
      clearSelectedPoint: true,
      clearChainJumpPoint: true,
      validMovesForSelected: [],
    );
    _feedbackMessage = null;
    notifyListeners();

    _startTurnTimer();

    // Trigger local AI only if in vsAi mode and not in remote multiplayer
    if (!isRemoteMultiplayer &&
        _state.mode == GameMode.vsAi &&
        _state.currentTurn == PlayerType.player1) {
      _triggerAiTurn();
    }
  }

  /// AI decision making and move execution
  Future<void> _triggerAiTurn() async {
    _state = _state.copyWith(isAiThinking: true);
    notifyListeners();

    final isFast = _settings.fastAiEnabled;
    final delayMs = isFast
        ? 250
        : (_state.difficulty == Difficulty.easy
            ? GameConstants.easyAiDelayMs
            : _state.difficulty == Difficulty.medium
                ? GameConstants.mediumAiDelayMs
                : GameConstants.hardAiDelayMs);

    await Future.delayed(Duration(milliseconds: delayMs));

    if (_state.isGameOver || _state.isPaused) {
      _state = _state.copyWith(isAiThinking: false);
      notifyListeners();
      return;
    }

    BoardPoint? currentAiChain;
    while (true) {
      final aiMove = await AiEngine.chooseMove(
        board: _state.board,
        aiPlayer: PlayerType.player1,
        difficulty: _state.difficulty,
        chainJumpFrom: currentAiChain,
      );

      if (aiMove == null) {
        _turnTimer?.cancel();
        _state = _state.copyWith(
          isAiThinking: false,
          isGameOver: true,
          winner: PlayerType.player2,
        );
        _sound.playVictory();
        _pointsService.addPoints(PointsService.victoryPointsReward);
        notifyListeners();
        return;
      }

      final newBoard = RuleEngine.applyMove(_state.board, aiMove, PlayerType.player1);
      final p1Count = RuleEngine.countPieces(newBoard, PlayerType.player1);
      final p2Count = RuleEngine.countPieces(newBoard, PlayerType.player2);

      if (aiMove.isJump) {
        _sound.playCapture();
        if (Random().nextDouble() < 0.4) {
          final taunts = [
            const GameEmoji(id: 'cool', emoji: '😎', labelUrdu: 'شکار ہو گیا!'),
            const GameEmoji(id: 'fire', emoji: '🔥', labelUrdu: 'شاندار چال!'),
            const GameEmoji(id: 'devil', emoji: '😈', labelUrdu: 'بچ کے رہو!'),
          ];
          sendEmoji(PlayerType.player1, taunts[Random().nextInt(taunts.length)]);
        }
      } else {
        _sound.playMove();
      }

      final newHistory = List<GameMove>.from(_state.moveHistory)..add(aiMove);

      _state = _state.copyWith(
        board: newBoard,
        player1Pieces: p1Count,
        player2Pieces: p2Count,
        totalMoves: _state.totalMoves + 1,
        moveHistory: newHistory,
        lastMove: aiMove,
      );
      notifyListeners();

      if (aiMove.isJump) {
        final chainJumps = RuleEngine.getSubsequentJumps(newBoard, aiMove.to, PlayerType.player1);
        if (chainJumps.isNotEmpty) {
          currentAiChain = aiMove.to;
          await Future.delayed(const Duration(milliseconds: 350));
          continue;
        }
      }

      break;
    }

    // Check game over
    final status = RuleEngine.checkGameStatus(_state.board, PlayerType.player2);
    if (status.isGameOver) {
      _turnTimer?.cancel();
      _state = _state.copyWith(
        isGameOver: true,
        winner: status.winner,
        isAiThinking: false,
      );
      _sound.playVictory();
      _feedbackMessage = status.winner == PlayerType.player2
          ? AppStrings.youWon
          : AppStrings.computerWon;

      if (status.winner == PlayerType.player2) {
        _pointsService.addPoints(PointsService.victoryPointsReward);
      }

      notifyListeners();
      return;
    }

    _state = _state.copyWith(
      currentTurn: PlayerType.player2,
      isAiThinking: false,
      clearSelectedPoint: true,
      clearChainJumpPoint: true,
    );
    notifyListeners();

    _startTurnTimer();
  }

  /// Undo last move (costs 10 points)
  Future<void> undoMove() async {
    if (_state.isAiThinking || _state.moveHistory.isEmpty) {
      _sound.playInvalid();
      return;
    }

    // Check if player has at least 10 points to undo
    if (!_pointsService.canAfford(PointsService.undoPointsCost)) {
      _triggerInvalidMove(AppStrings.notEnoughPointsForUndo);
      return;
    }

    // Deduct 10 points for undo
    await _pointsService.deductPoints(PointsService.undoPointsCost);

    _sound.playButtonClick();

    final targetHistoryLength = _state.mode == GameMode.vsAi
        ? (_state.moveHistory.length >= 2 ? _state.moveHistory.length - 2 : 0)
        : _state.moveHistory.length - 1;

    var newBoard = RuleEngine.createInitialBoard();
    var turn = PlayerType.player2;

    for (int i = 0; i < targetHistoryLength; i++) {
      final move = _state.moveHistory[i];
      newBoard = RuleEngine.applyMove(newBoard, move, turn);
      if (i + 1 < targetHistoryLength) {
        final nextMove = _state.moveHistory[i + 1];
        if (move.isJump && nextMove.from == move.to && nextMove.isJump) {
        } else {
          turn = turn.opponent;
        }
      } else {
        turn = turn.opponent;
      }
    }

    final p1 = RuleEngine.countPieces(newBoard, PlayerType.player1);
    final p2 = RuleEngine.countPieces(newBoard, PlayerType.player2);
    final truncatedHistory = _state.moveHistory.sublist(0, targetHistoryLength);

    _state = _state.copyWith(
      board: newBoard,
      currentTurn: _state.mode == GameMode.vsAi ? PlayerType.player2 : turn,
      player1Pieces: p1,
      player2Pieces: p2,
      clearSelectedPoint: true,
      clearChainJumpPoint: true,
      clearWinner: true,
      isGameOver: false,
      totalMoves: targetHistoryLength,
      moveHistory: truncatedHistory,
      lastMove: truncatedHistory.isNotEmpty ? truncatedHistory.last : null,
      clearLastMove: truncatedHistory.isEmpty,
    );
    _feedbackMessage = AppStrings.undoCostNotice;
    notifyListeners();
    _startTurnTimer();
  }

  void _triggerInvalidMove(String message) {
    _sound.playInvalid();
    _feedbackMessage = message;
    notifyListeners();
  }

  @override
  void dispose() {
    _turnTimer?.cancel();
    _p1EmojiTimer?.cancel();
    _p2EmojiTimer?.cancel();
    super.dispose();
  }
}
