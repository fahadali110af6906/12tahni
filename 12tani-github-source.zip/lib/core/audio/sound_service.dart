import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SoundService {
  static final SoundService _instance = SoundService._internal();
  factory SoundService() => _instance;
  SoundService._internal();

  static const MethodChannel _channel = MethodChannel('com.antigravity.twelvetani/sound');
  bool _soundEnabled = true;
  bool _hapticsEnabled = true;
  bool _hintsEnabled = true;
  bool _fastAiEnabled = false;
  bool _initialized = false;

  bool get soundEnabled => _soundEnabled;
  set soundEnabled(bool v) => setSoundEnabled(v);
  bool get hapticsEnabled => _hapticsEnabled;
  bool get hintsEnabled => _hintsEnabled;
  bool get fastAiEnabled => _fastAiEnabled;

  Future<void> init() async {
    if (_initialized) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      _soundEnabled = prefs.getBool('sound_enabled') ?? true;
      _hapticsEnabled = prefs.getBool('haptics_enabled') ?? true;
      _hintsEnabled = prefs.getBool('hints_enabled') ?? true;
      _fastAiEnabled = prefs.getBool('fast_ai_enabled') ?? false;
      _initialized = true;
    } catch (e) {
      debugPrint('SoundService init error: $e');
    }
  }

  Future<void> setSoundEnabled(bool value) async {
    _soundEnabled = value;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('sound_enabled', _soundEnabled);
    } catch (_) {}
  }

  Future<void> toggleSound() async {
    await setSoundEnabled(!_soundEnabled);
  }

  Future<void> setHapticsEnabled(bool value) async {
    _hapticsEnabled = value;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('haptics_enabled', _hapticsEnabled);
    } catch (_) {}
  }

  Future<void> toggleHaptics() async {
    await setHapticsEnabled(!_hapticsEnabled);
  }

  Future<void> setHintsEnabled(bool value) async {
    _hintsEnabled = value;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('hints_enabled', _hintsEnabled);
    } catch (_) {}
  }

  Future<void> setFastAiEnabled(bool value) async {
    _fastAiEnabled = value;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('fast_ai_enabled', _fastAiEnabled);
    } catch (_) {}
  }

  Future<void> resetDefaults() async {
    await setSoundEnabled(true);
    await setHapticsEnabled(true);
    await setHintsEnabled(true);
    await setFastAiEnabled(false);
  }

  Future<void> playMove() async {
    _vibrateLight();
    await _playSound('move.wav');
  }

  Future<void> playCapture() async {
    _vibrateMedium();
    await _playSound('capture.wav');
  }

  Future<void> playSelect() async {
    _vibrateLight();
    await _playSound('select.wav');
  }

  Future<void> playInvalid() async {
    _vibrateHeavy();
    await _playSound('invalid.wav');
  }

  Future<void> playVictory() async {
    _vibrateMedium();
    await _playSound('victory.wav');
  }

  Future<void> playButtonClick() async {
    _vibrateLight();
    await _playSound('button.wav');
  }

  Future<void> _playSound(String filename) async {
    if (!_soundEnabled) return;
    try {
      await _channel.invokeMethod('playSound', {'file': filename});
    } catch (e) {
      // Fallback to SystemSound on desktop/web/test
      try {
        SystemSound.play(SystemSoundType.click);
      } catch (_) {}
    }
  }

  void _vibrateLight() {
    if (!_hapticsEnabled) return;
    try {
      HapticFeedback.lightImpact();
    } catch (_) {}
  }

  void _vibrateMedium() {
    if (!_hapticsEnabled) return;
    try {
      HapticFeedback.mediumImpact();
    } catch (_) {}
  }

  void _vibrateHeavy() {
    if (!_hapticsEnabled) return;
    try {
      HapticFeedback.heavyImpact();
    } catch (_) {}
  }

  void dispose() {}
}
