import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/app_language.dart';
import '../../models/board_theme_type.dart';
import '../../models/piece_color_theme.dart';
import '../../models/piece_style.dart';

class SettingsService extends ChangeNotifier {
  static final SettingsService _instance = SettingsService._internal();
  factory SettingsService() => _instance;
  SettingsService._internal();

  AppLanguage _language = AppLanguage.urdu;
  String _player1Name = 'کھلاڑی ۱';
  String _player2Name = 'آپ (سبز)';
  PieceColorOption _player1Color = PieceColorOption.rubyRed;
  PieceColorOption _player2Color = PieceColorOption.emeraldGreen;
  PieceStyle _player1Style = PieceStyle.crystalMarble;
  PieceStyle _player2Style = PieceStyle.crystalMarble;
  BoardThemeType _boardTheme = BoardThemeType.classicWood;
  bool _soundEnabled = true;
  bool _hapticsEnabled = true;
  bool _hintsEnabled = true;
  bool _fastAiEnabled = false;
  bool _initialized = false;

  AppLanguage get language => _language;
  String get player1Name => _player1Name;
  String get player2Name => _player2Name;
  PieceColorOption get player1Color => _player1Color;
  PieceColorOption get player2Color => _player2Color;
  PieceStyle get player1Style => _player1Style;
  PieceStyle get player2Style => _player2Style;
  BoardThemeType get boardTheme => _boardTheme;
  bool get soundEnabled => _soundEnabled;
  bool get hapticsEnabled => _hapticsEnabled;
  bool get hintsEnabled => _hintsEnabled;
  bool get fastAiEnabled => _fastAiEnabled;

  Future<void> init() async {
    if (_initialized) return;
    try {
      final prefs = await SharedPreferences.getInstance();

      final langCode = prefs.getString('app_language');
      if (langCode != null) {
        _language = AppLanguage.values.firstWhere(
          (l) => l.code == langCode,
          orElse: () => AppLanguage.urdu,
        );
      }

      _player1Name = prefs.getString('p1_name') ?? (_language == AppLanguage.english ? 'Player 1' : 'کھلاڑی ۱');
      _player2Name = prefs.getString('p2_name') ?? (_language == AppLanguage.english ? 'Player 2' : 'کھلاڑی ۲');

      final p1ColorIdx = prefs.getInt('p1_color') ?? 0;
      if (p1ColorIdx >= 0 && p1ColorIdx < PieceColorOption.values.length) {
        _player1Color = PieceColorOption.values[p1ColorIdx];
      }

      final p2ColorIdx = prefs.getInt('p2_color') ?? 1;
      if (p2ColorIdx >= 0 && p2ColorIdx < PieceColorOption.values.length) {
        _player2Color = PieceColorOption.values[p2ColorIdx];
      }

      final p1StyleIdx = prefs.getInt('p1_style') ?? 0;
      if (p1StyleIdx >= 0 && p1StyleIdx < PieceStyle.values.length) {
        _player1Style = PieceStyle.values[p1StyleIdx];
      }

      final p2StyleIdx = prefs.getInt('p2_style') ?? 0;
      if (p2StyleIdx >= 0 && p2StyleIdx < PieceStyle.values.length) {
        _player2Style = PieceStyle.values[p2StyleIdx];
      }

      final boardIdx = prefs.getInt('board_theme') ?? 0;
      if (boardIdx >= 0 && boardIdx < BoardThemeType.values.length) {
        _boardTheme = BoardThemeType.values[boardIdx];
      }

      _soundEnabled = prefs.getBool('sound_enabled') ?? true;
      _hapticsEnabled = prefs.getBool('haptics_enabled') ?? true;
      _hintsEnabled = prefs.getBool('hints_enabled') ?? true;
      _fastAiEnabled = prefs.getBool('fast_ai_enabled') ?? false;

      _initialized = true;
      notifyListeners();
    } catch (e) {
      debugPrint('SettingsService init error: $e');
    }
  }

  Future<void> setLanguage(AppLanguage language) async {
    _language = language;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('app_language', language.code);
    } catch (_) {}
  }

  Future<void> setPlayer1Name(String name) async {
    final trimmed = name.trim();
    _player1Name = trimmed.isEmpty
        ? (_language == AppLanguage.english ? 'Player 1' : 'کھلاڑی ۱')
        : trimmed;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('p1_name', _player1Name);
    } catch (_) {}
  }

  Future<void> setPlayer2Name(String name) async {
    final trimmed = name.trim();
    _player2Name = trimmed.isEmpty
        ? (_language == AppLanguage.english ? 'Player 2' : 'کھلاڑی ۲')
        : trimmed;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('p2_name', _player2Name);
    } catch (_) {}
  }

  Future<void> setPlayer1Color(PieceColorOption color) async {
    _player1Color = color;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('p1_color', PieceColorOption.values.indexOf(color));
    } catch (_) {}
  }

  Future<void> setPlayer2Color(PieceColorOption color) async {
    _player2Color = color;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('p2_color', PieceColorOption.values.indexOf(color));
    } catch (_) {}
  }

  Future<void> setPlayer1Style(PieceStyle style) async {
    _player1Style = style;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('p1_style', PieceStyle.values.indexOf(style));
    } catch (_) {}
  }

  Future<void> setPlayer2Style(PieceStyle style) async {
    _player2Style = style;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('p2_style', PieceStyle.values.indexOf(style));
    } catch (_) {}
  }

  Future<void> setBoardTheme(BoardThemeType theme) async {
    _boardTheme = theme;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('board_theme', BoardThemeType.values.indexOf(theme));
    } catch (_) {}
  }

  Future<void> setSoundEnabled(bool enabled) async {
    _soundEnabled = enabled;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('sound_enabled', enabled);
    } catch (_) {}
  }

  Future<void> setHapticsEnabled(bool enabled) async {
    _hapticsEnabled = enabled;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('haptics_enabled', enabled);
    } catch (_) {}
  }

  Future<void> setHintsEnabled(bool enabled) async {
    _hintsEnabled = enabled;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('hints_enabled', enabled);
    } catch (_) {}
  }

  Future<void> setFastAiEnabled(bool enabled) async {
    _fastAiEnabled = enabled;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('fast_ai_enabled', enabled);
    } catch (_) {}
  }

  Future<void> resetToDefaults() async {
    _language = AppLanguage.urdu;
    _player1Name = 'کھلاڑی ۱';
    _player2Name = 'آپ (سبز)';
    _player1Color = PieceColorOption.rubyRed;
    _player2Color = PieceColorOption.emeraldGreen;
    _player1Style = PieceStyle.crystalMarble;
    _player2Style = PieceStyle.crystalMarble;
    _boardTheme = BoardThemeType.classicWood;
    _soundEnabled = true;
    _hapticsEnabled = true;
    _hintsEnabled = true;
    _fastAiEnabled = false;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('app_language');
      await prefs.remove('p1_name');
      await prefs.remove('p2_name');
      await prefs.remove('p1_color');
      await prefs.remove('p2_color');
      await prefs.remove('p1_style');
      await prefs.remove('p2_style');
      await prefs.remove('board_theme');
      await prefs.remove('sound_enabled');
      await prefs.remove('haptics_enabled');
      await prefs.remove('hints_enabled');
      await prefs.remove('fast_ai_enabled');
    } catch (_) {}
  }
}
