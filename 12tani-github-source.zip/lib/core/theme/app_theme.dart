import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class AppTheme {
  static ThemeData get darkTheme {
    final baseTheme = ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.backgroundDark,
      primaryColor: AppColors.goldAccent,
      useMaterial3: true,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.goldAccent,
        secondary: AppColors.amberAccent,
        surface: AppColors.surfaceWoodDark,
        error: AppColors.errorRed,
      ),
    );

    // Apply Urdu-friendly typography
    TextStyle urduFont({
      double fontSize = 16,
      FontWeight fontWeight = FontWeight.normal,
      Color color = AppColors.textLight,
      double height = 1.5,
    }) {
      return TextStyle(
        fontFamily: 'Noto Nastaliq Urdu',
        fontFamilyFallback: const ['Amiri', 'Segoe UI Historic', 'Arial', 'sans-serif'],
        fontSize: fontSize,
        fontWeight: fontWeight,
        color: color,
        height: height,
      );
    }

    return baseTheme.copyWith(
      textTheme: TextTheme(
        displayLarge: urduFont(fontSize: 32, fontWeight: FontWeight.bold, color: AppColors.goldAccent),
        displayMedium: urduFont(fontSize: 26, fontWeight: FontWeight.bold, color: AppColors.textLight),
        titleLarge: urduFont(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.textLight),
        titleMedium: urduFont(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.textLight),
        titleSmall: urduFont(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textMuted),
        bodyLarge: urduFont(fontSize: 16, fontWeight: FontWeight.normal, color: AppColors.textLight),
        bodyMedium: urduFont(fontSize: 14, fontWeight: FontWeight.normal, color: AppColors.textMuted),
        labelLarge: urduFont(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textDark),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.goldAccent,
          foregroundColor: AppColors.textDark,
          elevation: 6,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: urduFont(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textDark),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.goldAccent,
          side: const BorderSide(color: AppColors.goldAccent, width: 2),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: urduFont(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.goldAccent),
        ),
      ),
      cardTheme: CardThemeData(
        color: AppColors.cardBackground,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: AppColors.cardBorder, width: 1.5),
        ),
        elevation: 8,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: AppColors.surfaceWoodDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: AppColors.goldAccent, width: 2),
        ),
        elevation: 16,
      ),
    );
  }
}
