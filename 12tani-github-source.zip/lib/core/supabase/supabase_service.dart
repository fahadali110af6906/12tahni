import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:supabase/supabase.dart';
import '../../models/board_point.dart';
import '../../models/game_move.dart';
import '../../models/player_type.dart';

class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();
  factory SupabaseService() => _instance;
  SupabaseService._internal();

  static const String supabaseUrl = 'https://lcrtlqzgzilzzvgtdpar.supabase.co';
  static const String supabaseAnonKey = 'sb_publishable_TyzLMrrNpKi3mOi1WrutbA_O4vWFwP4';

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  SupabaseClient? _client;
  SupabaseClient? get client => _client;

  RealtimeChannel? _activeGameChannel;
  String? _currentRoomCode;

  // Stream controllers for online events
  final _moveStreamController = StreamController<GameMove>.broadcast();
  final _opponentJoinedController = StreamController<Map<String, dynamic>>.broadcast();
  final _emojiStreamController = StreamController<String>.broadcast();
  final _gameResetStreamController = StreamController<void>.broadcast();

  Stream<GameMove> get onOpponentMove => _moveStreamController.stream;
  Stream<Map<String, dynamic>> get onOpponentJoined => _opponentJoinedController.stream;
  Stream<String> get onOpponentEmoji => _emojiStreamController.stream;
  Stream<void> get onGameReset => _gameResetStreamController.stream;

  Future<void> init() async {
    if (_isInitialized) return;
    try {
      _client = SupabaseClient(supabaseUrl, supabaseAnonKey);
      _isInitialized = true;
      debugPrint('⚡ Supabase pure Dart client initialized successfully!');

      // Sign in anonymously if not authenticated
      try {
        if (_client?.auth.currentSession == null) {
          await _client?.auth.signInAnonymously();
          debugPrint('🔑 Supabase Anonymous Auth session established.');
        }
      } catch (authError) {
        debugPrint('ℹ️ Supabase Auth notice: $authError');
      }
    } catch (e) {
      debugPrint('⚠️ Supabase init error: $e');
      _isInitialized = false;
    }
  }

  /// Join or Create a Realtime Game Room for Online 1v1 or Friend match
  Future<RealtimeChannel?> joinGameRoom({
    required String roomCode,
    required String playerName,
    required String playerAvatar,
    required bool isHost,
    int wager = 200,
  }) async {
    if (!_isInitialized || _client == null) return null;

    await leaveGameRoom();
    _currentRoomCode = roomCode;

    try {
      final channel = _client!.channel('twelve_tani_room_$roomCode');

      channel.onBroadcast(
        event: 'game_move',
        callback: (payload) {
          try {
            final fromRow = payload['fromRow'] as int;
            final fromCol = payload['fromCol'] as int;
            final toRow = payload['toRow'] as int;
            final toCol = payload['toCol'] as int;
            final isJump = payload['isJump'] as bool? ?? false;
            final capturedRow = payload['capturedRow'] as int?;
            final capturedCol = payload['capturedCol'] as int?;

            final from = BoardPoint(fromRow, fromCol);
            final to = BoardPoint(toRow, toCol);
            BoardPoint? captured;
            if (capturedRow != null && capturedCol != null) {
              captured = BoardPoint(capturedRow, capturedCol);
            }

            final senderIsHost = payload['isHost'] as bool? ?? (!isHost);
            final movePlayer = senderIsHost ? PlayerType.player2 : PlayerType.player1;

            final move = GameMove(
              from: from,
              to: to,
              isJump: isJump,
              capturedPoint: captured,
              player: movePlayer,
            );

            _moveStreamController.add(move);
          } catch (err) {
            debugPrint('Error parsing move broadcast: $err');
          }
        },
      );

      channel.onBroadcast(
        event: 'player_joined',
        callback: (payload) {
          _opponentJoinedController.add(payload);
        },
      );

      channel.onBroadcast(
        event: 'emoji',
        callback: (payload) {
          final emoji = payload['emoji'] as String?;
          if (emoji != null) {
            _emojiStreamController.add(emoji);
          }
        },
      );

      channel.onBroadcast(
        event: 'game_reset',
        callback: (payload) {
          _gameResetStreamController.add(null);
        },
      );

      await channel.subscribe((status, [error]) {
        debugPrint('Room channel $roomCode status: $status');
        if (status == RealtimeSubscribeStatus.subscribed) {
          // Broadcast presence
          channel.sendBroadcastMessage(
            event: 'player_joined',
            payload: {
              'name': playerName,
              'avatar': playerAvatar,
              'isHost': isHost,
              'wager': wager,
            },
          );
        }
      });

      _activeGameChannel = channel;
      return channel;
    } catch (e) {
      debugPrint('Error joining Supabase game room: $e');
      return null;
    }
  }

  /// Send presence (name, avatar, host status)
  Future<void> sendPresence({
    required String playerName,
    required String playerAvatar,
    required bool isHost,
    int wager = 200,
  }) async {
    if (_activeGameChannel == null) return;
    try {
      await _activeGameChannel!.sendBroadcastMessage(
        event: 'player_joined',
        payload: {
          'name': playerName,
          'avatar': playerAvatar,
          'isHost': isHost,
          'wager': wager,
        },
      );
    } catch (e) {
      debugPrint('Error broadcasting presence: $e');
    }
  }

  /// Send player move to opponent in realtime
  Future<void> sendMove(GameMove move, {bool? isHost}) async {
    if (_activeGameChannel == null) return;
    try {
      await _activeGameChannel!.sendBroadcastMessage(
        event: 'game_move',
        payload: {
          'fromRow': move.from.row,
          'fromCol': move.from.col,
          'toRow': move.to.row,
          'toCol': move.to.col,
          'isJump': move.isJump,
          'capturedRow': move.capturedPoint?.row,
          'capturedCol': move.capturedPoint?.col,
          if (isHost != null) 'isHost': isHost,
        },
      );
    } catch (e) {
      debugPrint('Error broadcasting move: $e');
    }
  }

  /// Send emoji to opponent in realtime
  Future<void> sendEmoji(String emojiSymbol) async {
    if (_activeGameChannel == null) return;
    try {
      await _activeGameChannel!.sendBroadcastMessage(
        event: 'emoji',
        payload: {'emoji': emojiSymbol},
      );
    } catch (e) {
      debugPrint('Error broadcasting emoji: $e');
    }
  }

  /// Reset/Rematch the room
  Future<void> sendGameReset() async {
    if (_activeGameChannel == null) return;
    try {
      await _activeGameChannel!.sendBroadcastMessage(
        event: 'game_reset',
        payload: {},
      );
    } catch (e) {
      debugPrint('Error broadcasting reset: $e');
    }
  }

  /// Leave active game room
  Future<void> leaveGameRoom() async {
    if (_activeGameChannel != null && _client != null) {
      try {
        await _client!.removeChannel(_activeGameChannel!);
      } catch (_) {}
      _activeGameChannel = null;
      _currentRoomCode = null;
    }
  }

  /// Cloud Leaderboard - Fetch Global Top Players with graceful fallback
  Future<List<Map<String, dynamic>>> fetchLeaderboard() async {
    if (!_isInitialized || _client == null) {
      return _getDefaultLeaderboard();
    }
    try {
      final response = await _client!
          .from('leaderboard')
          .select()
          .order('wins', ascending: false)
          .limit(20);

      if (response.isNotEmpty) {
        return List<Map<String, dynamic>>.from(response);
      }
    } catch (e) {
      debugPrint('Leaderboard table query fallback: $e');
    }
    return _getDefaultLeaderboard();
  }

  /// Cloud Leaderboard - Submit user score
  Future<void> submitScore({
    required String playerName,
    required String avatar,
    required int wins,
    required int totalGames,
    required int coins,
  }) async {
    if (!_isInitialized || _client == null) return;
    try {
      await _client!.from('leaderboard').upsert({
        'player_name': playerName,
        'avatar': avatar,
        'wins': wins,
        'total_games': totalGames,
        'coins': coins,
        'updated_at': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      debugPrint('Notice on submitting score: $e');
    }
  }

  List<Map<String, dynamic>> _getDefaultLeaderboard() {
    return [
      {'rank': 1, 'name': 'David K.', 'winRate': '78%', 'avatar': '👑', 'trophies': '1,840', 'wins': 320},
      {'rank': 2, 'name': 'Sarah', 'winRate': '78%', 'avatar': '👩', 'trophies': '1,720', 'isUser': true, 'wins': 290},
      {'rank': 3, 'name': 'Mike B.', 'winRate': '78%', 'avatar': '🧔', 'trophies': '1,690', 'wins': 275},
      {'rank': 4, 'name': 'Alex J.', 'winRate': '56%', 'avatar': '👦', 'trophies': '1,540', 'wins': 210},
      {'rank': 5, 'name': 'Elena S.', 'winRate': '54%', 'avatar': '👧', 'trophies': '1,490', 'wins': 195},
      {'rank': 6, 'name': 'Tariq M.', 'winRate': '52%', 'avatar': '👳', 'trophies': '1,410', 'wins': 180},
    ];
  }
}
