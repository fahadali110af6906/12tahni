import 'package:flutter/material.dart';

class AppColors {
  // Background & Atmosphere (Dark Luxury Cosmic Obsidian Navy)
  static const Color backgroundDark = Color(0xFF0B0F19);
  static const Color backgroundLight = Color(0xFF131A2B);
  static const Color surfaceWoodDark = Color(0xFF141B2D);
  static const Color surfaceWoodMedium = Color(0xFF1B243B);
  static const Color surfaceWoodLight = Color(0xFF263353);
  static const Color woodBorder = Color(0xFF384F7C);

  // Board Lines & Grooves (12 Tani)
  static const Color boardLine = Color(0xFFFFD700); // Polished Brilliant Gold
  static const Color boardLineShadow = Color(0x99000000);
  static const Color boardSocket = Color(0xFF0C1322);
  static const Color boardSocketBorder = Color(0xFF00E5FF); // Glowing Cyan Socket Trim

  // Player 1 (Red / Coral Ruby / AI or Top Player)
  static const Color player1Primary = Color(0xFFFF2A55);
  static const Color player1Dark = Color(0xFFC2185B);
  static const Color player1Light = Color(0xFFFF80AB);
  static const Color player1Glow = Color(0xFFFF1744);
  static const Color player1Border = Color(0xFFFFCDD2);

  // Player 2 (Cyan / Electrified Turquoise Cyan / User or Bottom Player)
  static const Color player2Primary = Color(0xFF00E5FF);
  static const Color player2Dark = Color(0xFF0097A7);
  static const Color player2Light = Color(0xFF84FFFF);
  static const Color player2Glow = Color(0xFF00F0FF);
  static const Color player2Border = Color(0xFFE0F7FA);

  // Highlights & Valid Moves
  static const Color validMoveTarget = Color(0xFF00F0FF); // Neon Electric Cyan
  static const Color validMovePulse = Color(0x6600F0FF);
  static const Color validJumpTarget = Color(0xFFFFD700); // Radiant Golden Star
  static const Color selectedGlow = Color(0xFFFFEB3B);
  static const Color errorRed = Color(0xFFFF3B30);
  static const Color successGreen = Color(0xFF00E676);
  static const Color emeraldGreen = Color(0xFF00C853);

  // UI Accents & Text
  static const Color goldAccent = Color(0xFFFFD700);
  static const Color goldSatin = Color(0xFFF5A623);
  static const Color amberAccent = Color(0xFFFF9100);
  static const Color gemCyan = Color(0xFF00E5FF);
  static const Color cardBackground = Color(0xFF151C2D);
  static const Color cardBorder = Color(0xFF263654);
  static const Color textLight = Color(0xFFF0F6FC);
  static const Color textMuted = Color(0xFF8FA3BF);
  static const Color textDark = Color(0xFF0A0F1D);
  static const Color overlayDark = Color(0xDD050810);

  // Reference UI Game Mode Card Backgrounds
  static const Color modeOnlineBg = Color(0xFF1E3A2B);
  static const Color modeVsAiBg = Color(0xFF3E2818);
  static const Color modePassPlayBg = Color(0xFF162B3D);
  static const Color modeTournamentBg = Color(0xFF2E193C);

  // Gradients
  static const LinearGradient woodGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF253559),
      Color(0xFF162038),
      Color(0xFF0B101E),
    ],
  );

  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFFFFEA9F),
      Color(0xFFFFD700),
      Color(0xFFF5A623),
    ],
  );

  static const LinearGradient guestLoginGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFFE5A642),
      Color(0xFFBF7A1D),
      Color(0xFF8C530A),
    ],
  );

  static const LinearGradient rubyGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFFFF4081),
      Color(0xFFFF1744),
      Color(0xFF880E4F),
    ],
  );

  static const LinearGradient jadeGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF84FFFF),
      Color(0xFF00E5FF),
      Color(0xFF006064),
    ],
  );

  static const LinearGradient greenActionGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF00E676),
      Color(0xFF00C853),
      Color(0xFF1B5E20),
    ],
  );

  static const LinearGradient redActionGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFFFF5252),
      Color(0xFFD32F2F),
      Color(0xFF7F0000),
    ],
  );

  static const LinearGradient onlineModeGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF1E5128),
      Color(0xFF113217),
    ],
  );

  static const LinearGradient vsAiModeGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF5D3A1A),
      Color(0xFF3A230F),
    ],
  );

  static const LinearGradient passPlayModeGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF19324B),
      Color(0xFF0F1E2E),
    ],
  );

  static const LinearGradient tournamentModeGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF3D1F52),
      Color(0xFF231131),
    ],
  );
}
