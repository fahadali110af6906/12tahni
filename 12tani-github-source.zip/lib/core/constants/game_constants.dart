class GameConstants {
  static const int gridSize = 5;
  static const int totalPoints = 25;
  static const int piecesPerPlayer = 12;
  static const int centerIndex = 12; // (row 2, col 2)

  // Turn Timer Constants
  static const int turnTimerSeconds = 10;
  static const int maxTimeoutStrikes = 5;

  // Initial piece indices for Player 1 (Red / Top)
  static const List<int> initialPlayer1Indices = [
    0, 1, 2, 3, 4,
    5, 6, 7, 8, 9,
    10, 11
  ];

  // Initial piece indices for Player 2 (Green / Bottom)
  static const List<int> initialPlayer2Indices = [
    13, 14,
    15, 16, 17, 18, 19,
    20, 21, 22, 23, 24
  ];

  // AI Thinking Delays (ms)
  static const int easyAiDelayMs = 500;
  static const int mediumAiDelayMs = 700;
  static const int hardAiDelayMs = 900;
}
