import '../../models/app_language.dart';
import '../settings/settings_service.dart';

class AppStrings {
  static AppLanguage get _lang => SettingsService().language;

  // App Title & Subtitle
  static String get appName {
    switch (_lang) {
      case AppLanguage.urdu:
        return '12 ٹہنی';
      case AppLanguage.english:
        return '12 Tani';
      case AppLanguage.hindi:
        return '12 टहनी (Baro Guti)';
      case AppLanguage.punjabi:
        return '12 ٹہنی';
      case AppLanguage.arabic:
        return '12 غصناً (12 Tani)';
      case AppLanguage.bengali:
        return '১২ দানা (Baro Guti)';
    }
  }

  static String get appSubtitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روایتی دیسی حکمت عملی بورڈ گیم';
      case AppLanguage.english:
        return 'Traditional Desi Strategy Board Game';
      case AppLanguage.hindi:
        return 'पारंपरिक देसी रणनीति बोर्ड गेम';
      case AppLanguage.punjabi:
        return 'روایتی دیسی حکمت عملی بورڈ گیم';
      case AppLanguage.arabic:
        return 'لعبة الطاولة الاستراتيجية الشعبية';
      case AppLanguage.bengali:
        return 'ঐতিহ্যবাহী দেশি কৌশল বোর্ড গেম';
    }
  }

  static const String bead12English = '12 Tani • Bead 12';

  // Game Modes
  static String get singlePlayer {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'سنگل پلیئر (بمقابلہ AI)';
      case AppLanguage.english:
        return 'Single Player (vs AI)';
      case AppLanguage.hindi:
        return 'सिंगल प्लेयर (बनाम AI)';
      case AppLanguage.punjabi:
        return 'سنگل پلیئر (بمقابلہ AI)';
      case AppLanguage.arabic:
        return 'لاعب فردي (ضد الذكاء الاصطناعي)';
      case AppLanguage.bengali:
        return 'একক খেলোয়াড় (বনাম AI)';
    }
  }

  static String get singlePlayerDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کمپیوٹر کے ساتھ 3 مختلف مہارتوں میں کھیلیں';
      case AppLanguage.english:
        return 'Play against computer with 3 difficulty levels';
      case AppLanguage.hindi:
        return '3 कठिनाई स्तरों में कंप्यूटर के खिलाफ खेलें';
      case AppLanguage.punjabi:
        return 'کمپیوٹر دے نال ۳ وکھری مہارت وچ کھیلو';
      case AppLanguage.arabic:
        return 'العب ضد الكمبيوتر مع 3 مستويات صعوبة';
      case AppLanguage.bengali:
        return '৩টি স্তরে কম্পিউটারের সাথে খেলুন';
    }
  }

  static String get twoPlayer {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دو کھلاڑی (Pass & Play)';
      case AppLanguage.english:
        return 'Two Players (Pass & Play)';
      case AppLanguage.hindi:
        return 'दो खिलाड़ी (पास एंड प्ले)';
      case AppLanguage.punjabi:
        return 'دو کھلاڑی (Pass & Play)';
      case AppLanguage.arabic:
        return 'لاعبان (Pass & Play)';
      case AppLanguage.bengali:
        return 'দুই খেলোয়াড় (পাস ও প্লে)';
    }
  }

  static String get twoPlayerDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ایک ہی موبائل پر دوست یا فیملی کے ساتھ کھیلیں';
      case AppLanguage.english:
        return 'Play with a friend or family on the same device';
      case AppLanguage.hindi:
        return 'एक ही फोन पर दोस्त या परिवार के साथ खेलें';
      case AppLanguage.punjabi:
        return 'اکو فون تے دوست یا فیملی نال کھیلو';
      case AppLanguage.arabic:
        return 'العب مع صديق أو العائلة على نفس الجهاز';
      case AppLanguage.bengali:
        return 'একই ফোনে বন্ধু বা পরিবারের সাথে খেলুন';
    }
  }

  static String get onlineMatch {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آن لائن مقابلہ (Online)';
      case AppLanguage.english:
        return 'Online Match';
      case AppLanguage.hindi:
        return 'ऑनलाइन मुकाबला (Online)';
      case AppLanguage.punjabi:
        return 'آن لائن مقابلہ (Online)';
      case AppLanguage.arabic:
        return 'مباراة أونلاين (Online)';
      case AppLanguage.bengali:
        return 'অনলাইন ম্যাচ (Online)';
    }
  }

  static String get onlineMatchDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پوری دنیا کے آن لائن کھلاڑیوں سے فوری مقابلہ کریں';
      case AppLanguage.english:
        return 'Quick matchmaking with online players worldwide';
      case AppLanguage.hindi:
        return 'दुनिया भर के ऑनलाइन खिलाड़ियों के साथ खेलें';
      case AppLanguage.punjabi:
        return 'پوری دنیا دے آن لائن کھلاڑیاں نال فوری مقابلہ';
      case AppLanguage.arabic:
        return 'مطابقة سريعة مع لاعبين عبر الإنترنت حول العالم';
      case AppLanguage.bengali:
        return 'বিশ্বব্যাপী অনলাইন খেলোয়াড়দের সাথে দ্রুত খেলুন';
    }
  }

  static String get playWithFriend {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دوست کے ساتھ کھیلیں (Friend)';
      case AppLanguage.english:
        return 'Play with Friend';
      case AppLanguage.hindi:
        return 'दोस्त के साथ खेलें (Friend)';
      case AppLanguage.punjabi:
        return 'یار نال کھیلو (Friend)';
      case AppLanguage.arabic:
        return 'العب مع صديق (Friend)';
      case AppLanguage.bengali:
        return 'বন্ধুর সাথে খেলুন (Friend)';
    }
  }

  static String get playWithFriendDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پرائیویٹ روم کوڈ بنائیں یا دوست کے روم میں شامل ہوں';
      case AppLanguage.english:
        return 'Create private room code or join friend room';
      case AppLanguage.hindi:
        return 'प्राइवेट रूम कोड बनाएं या दोस्त के रूम में शामिल हों';
      case AppLanguage.punjabi:
        return 'پرائیویٹ روم کوڈ بناؤ یا یار دے روم چ شامل ہوو';
      case AppLanguage.arabic:
        return 'أنشئ رمز غرفة خاصة أو انضم لغرفة صديقك';
      case AppLanguage.bengali:
        return 'ব্যক্তিগত রুম কোড তৈরি করুন বা বন্ধুর রুমে যোগ দিন';
    }
  }

  static String get createRoom {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'نیا روم بنائیں';
      case AppLanguage.english:
        return 'Create Room';
      case AppLanguage.hindi:
        return 'नया कमरा बनाएं';
      case AppLanguage.punjabi:
        return 'نواں روم بناؤ';
      case AppLanguage.arabic:
        return 'إنشاء غرفة';
      case AppLanguage.bengali:
        return 'রুম তৈরি করুন';
    }
  }

  static String get joinRoom {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روم میں شامل ہوں';
      case AppLanguage.english:
        return 'Join Room';
      case AppLanguage.hindi:
        return 'कमरे में शामिल हों';
      case AppLanguage.punjabi:
        return 'روم چ شامل ہوو';
      case AppLanguage.arabic:
        return 'الانضمام إلى غرفة';
      case AppLanguage.bengali:
        return 'রুমে যোগ দিন';
    }
  }

  static String get roomCode {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روم کوڈ:';
      case AppLanguage.english:
        return 'Room Code:';
      case AppLanguage.hindi:
        return 'रूम कोड:';
      case AppLanguage.punjabi:
        return 'روم کوڈ:';
      case AppLanguage.arabic:
        return 'رمز الغرفة:';
      case AppLanguage.bengali:
        return 'রুম কোড:';
    }
  }

  static String get enterRoomCode {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۴ ہندسوں کا روم کوڈ درج کریں';
      case AppLanguage.english:
        return 'Enter 4-digit Room Code';
      case AppLanguage.hindi:
        return '4 अंकों का रूम कोड दर्ज करें';
      case AppLanguage.punjabi:
        return '۴ ہندسیاں دا روم کوڈ لکھو';
      case AppLanguage.arabic:
        return 'أدخل رمز الغرفة المكون من 4 أرقام';
      case AppLanguage.bengali:
        return '৪ ডিজিটের রুম কোড লিখুন';
    }
  }

  static String get shareRoomCode {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دوست کے ساتھ کوڈ شیئر کریں';
      case AppLanguage.english:
        return 'Share Code with Friend';
      case AppLanguage.hindi:
        return 'दोस्त के साथ कोड शेयर करें';
      case AppLanguage.punjabi:
        return 'یار نال کوڈ شیئر کرو';
      case AppLanguage.arabic:
        return 'شارك الرمز مع صديقك';
      case AppLanguage.bengali:
        return 'বন্ধুর সাথে কোড শেয়ার করুন';
    }
  }

  static String get waitingForFriend {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دوست کے شامل ہونے کا انتظار ہے...';
      case AppLanguage.english:
        return 'Waiting for friend to join...';
      case AppLanguage.hindi:
        return 'दोस्त के जुड़ने का इंतजार है...';
      case AppLanguage.punjabi:
        return 'یار دے شامل ہون دا انتظار اے...';
      case AppLanguage.arabic:
        return 'بانتظار انضمام الصديق...';
      case AppLanguage.bengali:
        return 'বন্ধুর যোগদানের অপেক্ষায়...';
    }
  }

  static String get searchingOnlineOpponent {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آن لائن حریف کھلاڑی کی تلاش جاری ہے...';
      case AppLanguage.english:
        return 'Searching for online opponent...';
      case AppLanguage.hindi:
        return 'ऑनलाइन प्रतिद्वंद्वी की खोज जारी है...';
      case AppLanguage.punjabi:
        return 'آن لائن کھلاڑی دی تلاش اے...';
      case AppLanguage.arabic:
        return 'جاري البحث عن خصم عبر الإنترنت...';
      case AppLanguage.bengali:
        return 'অনলাইন প্রতিপক্ষ খোঁজা হচ্ছে...';
    }
  }

  static String get opponentFound {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی مل گیا! میچ شروع ہو رہا ہے...';
      case AppLanguage.english:
        return 'Opponent found! Starting match...';
      case AppLanguage.hindi:
        return 'खिलाड़ी मिल गया! मैच शुरू हो रहा है...';
      case AppLanguage.punjabi:
        return 'کھلاڑی مل گیا! میچ شروع ہو رہیا اے...';
      case AppLanguage.arabic:
        return 'تم العثور على خصم! تبدأ المباراة...';
      case AppLanguage.bengali:
        return 'প্রতিপক্ষ পাওয়া গেছে! ম্যাচ শুরু হচ্ছে...';
    }
  }

  static String get copyCode {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کوڈ کاپی کریں';
      case AppLanguage.english:
        return 'Copy Code';
      case AppLanguage.hindi:
        return 'कोड कॉपी करें';
      case AppLanguage.punjabi:
        return 'کوڈ کاپی کرو';
      case AppLanguage.arabic:
        return 'نسخ الرمز';
      case AppLanguage.bengali:
        return 'কোড কপি করুন';
    }
  }

  static String get codeCopied {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روم کوڈ کلپ بورڈ پر کاپی ہو گیا!';
      case AppLanguage.english:
        return 'Room code copied to clipboard!';
      case AppLanguage.hindi:
        return 'रूम कोड क्लिपबोर्ड पर कॉपी हो गया!';
      case AppLanguage.punjabi:
        return 'روم کوڈ کاپی ہو گیا!';
      case AppLanguage.arabic:
        return 'تم نسخ رمز الغرفة بنجاح!';
      case AppLanguage.bengali:
        return 'রুম কোড ক্লিপবোর্ডে কপি হয়েছে!';
    }
  }

  static String get startMatch {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'میچ شروع کریں';
      case AppLanguage.english:
        return 'Start Match';
      case AppLanguage.hindi:
        return 'मैच शुरू करें';
      case AppLanguage.punjabi:
        return 'میچ شروع کرو';
      case AppLanguage.arabic:
        return 'بدء المباراة';
      case AppLanguage.bengali:
        return 'ম্যাচ শুরু করুন';
    }
  }

  static String get online {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آن لائن';
      case AppLanguage.english:
        return 'Online';
      case AppLanguage.hindi:
        return 'ऑनलाइन';
      case AppLanguage.punjabi:
        return 'آن لائن';
      case AppLanguage.arabic:
        return 'أونلاين';
      case AppLanguage.bengali:
        return 'অনলাইন';
    }
  }

  static String get roomNumber {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روم:';
      case AppLanguage.english:
        return 'Room:';
      case AppLanguage.hindi:
        return 'कमरा:';
      case AppLanguage.punjabi:
        return 'روم:';
      case AppLanguage.arabic:
        return 'غرفة:';
      case AppLanguage.bengali:
        return 'রুম:';
    }
  }

  // Difficulties
  static String get difficulty {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مشکل کی سطح';
      case AppLanguage.english:
        return 'Difficulty Level';
      case AppLanguage.hindi:
        return 'कठिनाई स्तर';
      case AppLanguage.punjabi:
        return 'مشکل دی سطح';
      case AppLanguage.arabic:
        return 'مستوى الصعوبة';
      case AppLanguage.bengali:
        return 'কঠিনতার স্তর';
    }
  }

  static String get easy {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آسان';
      case AppLanguage.english:
        return 'Easy';
      case AppLanguage.hindi:
        return 'आसान';
      case AppLanguage.punjabi:
        return 'سودھا / آسان';
      case AppLanguage.arabic:
        return 'سهل';
      case AppLanguage.bengali:
        return 'সহজ';
    }
  }

  static String get easyDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'نئے کھلاڑیوں اور بچوں کے لیے بہترین';
      case AppLanguage.english:
        return 'Best for beginners and children';
      case AppLanguage.hindi:
        return 'शुरुआती और बच्चों के लिए सबसे अच्छा';
      case AppLanguage.punjabi:
        return 'نویں کھلاڑیاں تے بالاں لئی بہترین';
      case AppLanguage.arabic:
        return 'مناسب للمبتدئين والأطفال';
      case AppLanguage.bengali:
        return 'নতুন ও শিশুদের জন্য সেরা';
    }
  }

  static String get medium {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'درمیانہ';
      case AppLanguage.english:
        return 'Medium';
      case AppLanguage.hindi:
        return 'मध्यम';
      case AppLanguage.punjabi:
        return 'درمیانہ';
      case AppLanguage.arabic:
        return 'متوسط';
      case AppLanguage.bengali:
        return 'মাঝারি';
    }
  }

  static String get mediumDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'متوازن اور چیلنجنگ گیم پلے';
      case AppLanguage.english:
        return 'Balanced and challenging gameplay';
      case AppLanguage.hindi:
        return 'संतुलित और चुनौतीपूर्ण खेल';
      case AppLanguage.punjabi:
        return 'متوازن تے چیلنجنگ گیم';
      case AppLanguage.arabic:
        return 'لعب متوازن وتحدي ممتع';
      case AppLanguage.bengali:
        return 'ভারসাম্যপূর্ণ ও চমৎকার খেলা';
    }
  }

  static String get hard {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مشکل';
      case AppLanguage.english:
        return 'Hard';
      case AppLanguage.hindi:
        return 'कठिन';
      case AppLanguage.punjabi:
        return 'اڈاری / مشکل';
      case AppLanguage.arabic:
        return 'صعب';
      case AppLanguage.bengali:
        return 'কঠিন';
    }
  }

  static String get hardDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'تجربہ کار کھلاڑیوں کے لیے گہری حکمت عملی';
      case AppLanguage.english:
        return 'Deep strategic challenge for experts';
      case AppLanguage.hindi:
        return 'विशेषज्ञों के लिए गहरी रणनीति';
      case AppLanguage.punjabi:
        return 'استاد کھلاڑیاں لئی ڈونگھی حکمت عملی';
      case AppLanguage.arabic:
        return 'استراتيجية عميقة للخبراء';
      case AppLanguage.bengali:
        return 'অভিজ্ঞদের জন্য গভীর কৌশল';
    }
  }

  // Player Labels
  static String get player1 {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۱ (سرخ)';
      case AppLanguage.english:
        return 'Player 1 (Red)';
      case AppLanguage.hindi:
        return 'खिलाड़ी 1 (लाल)';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۱ (لال)';
      case AppLanguage.arabic:
        return 'اللاعب 1 (الأحمر)';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ১ (লাল)';
    }
  }

  static String get player2 {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۲ (سبز)';
      case AppLanguage.english:
        return 'Player 2 (Green)';
      case AppLanguage.hindi:
        return 'खिलाड़ी 2 (हरा)';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۲ (ہرا)';
      case AppLanguage.arabic:
        return 'اللاعب 2 (الأخضر)';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ২ (সবুজ)';
    }
  }

  static String get computer {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کمپیوٹر (AI)';
      case AppLanguage.english:
        return 'Computer (AI)';
      case AppLanguage.hindi:
        return 'कंप्यूटर (AI)';
      case AppLanguage.punjabi:
        return 'کمپیوٹر (AI)';
      case AppLanguage.arabic:
        return 'الكمبيوتر (AI)';
      case AppLanguage.bengali:
        return 'কম্পিউটার (AI)';
    }
  }

  static String get you {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آپ (سبز)';
      case AppLanguage.english:
        return 'You (Green)';
      case AppLanguage.hindi:
        return 'आप (हरा)';
      case AppLanguage.punjabi:
        return 'تسی (ہرا)';
      case AppLanguage.arabic:
        return 'أنت (الأخضر)';
      case AppLanguage.bengali:
        return 'আপনি (সবুজ)';
    }
  }

  static String get yourTurn {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آپ کی باری ہے';
      case AppLanguage.english:
        return 'Your Turn';
      case AppLanguage.hindi:
        return 'आपकी बारी है';
      case AppLanguage.punjabi:
        return 'تہاڈی واری اے';
      case AppLanguage.arabic:
        return 'دورك الآن';
      case AppLanguage.bengali:
        return 'আপনার চাল';
    }
  }

  static String get computerTurn {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کمپیوٹر سوچ رہا ہے...';
      case AppLanguage.english:
        return 'Computer is thinking...';
      case AppLanguage.hindi:
        return 'कंप्यूटर सोच रहा है...';
      case AppLanguage.punjabi:
        return 'کمپیوٹر سوچ رہیا اے...';
      case AppLanguage.arabic:
        return 'الكمبيوتر يفكر...';
      case AppLanguage.bengali:
        return 'কম্পিউটার ভাবছে...';
    }
  }

  static String get chainJumpTurn {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'شاباش! اگلا شکار بھی کر سکتے ہیں';
      case AppLanguage.english:
        return 'Awesome! You can capture again!';
      case AppLanguage.hindi:
        return 'शाबाश! आप दोबारा शिकार कर सकते हैं';
      case AppLanguage.punjabi:
        return 'شاباش! اگلا شکار وی کر سکدے او';
      case AppLanguage.arabic:
        return 'أحسنت! يمكنك القفز والأكل مجدداً';
      case AppLanguage.bengali:
        return 'দারুণ! আপনি আবার শিকার করতে পারেন';
    }
  }

  // Status & Guidance
  static String get tapPieceToSelect {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'اپنے مہرے پر ٹیپ کریں';
      case AppLanguage.english:
        return 'Tap on your piece';
      case AppLanguage.hindi:
        return 'अपनी गोटी पर टैप करें';
      case AppLanguage.punjabi:
        return 'اپنی گوٹی تے ٹیپ کرو';
      case AppLanguage.arabic:
        return 'المس قطعتك لتحديدها';
      case AppLanguage.bengali:
        return 'আপনার দানায় চাপ দিন';
    }
  }

  static String get tapTargetToMove {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روشن دائرے پر ٹیپ کر کے چال چلیں';
      case AppLanguage.english:
        return 'Tap a glowing circle to move';
      case AppLanguage.hindi:
        return 'चलने के लिए चमकते घेरे पर टैप करें';
      case AppLanguage.punjabi:
        return 'چال چلن لئی لشکدے دائرے تے ٹیپ کرو';
      case AppLanguage.arabic:
        return 'المس الدائرة المضيئة للتحرك';
      case AppLanguage.bengali:
        return 'চাল দিতে আলোকিত বৃত্তে চাপুন';
    }
  }

  static String get invalidMoveTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'غلط چال!';
      case AppLanguage.english:
        return 'Invalid Move!';
      case AppLanguage.hindi:
        return 'अमान्य चाल!';
      case AppLanguage.punjabi:
        return 'غلط چال!';
      case AppLanguage.arabic:
        return 'حركة غير صالحة!';
      case AppLanguage.bengali:
        return 'ভুল চাল!';
    }
  }

  static String get invalidMoveDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مہرہ صرف متصل خالی پوائنٹ یا درست شکار پر جا سکتا ہے';
      case AppLanguage.english:
        return 'Piece can only move to connected empty point or jump';
      case AppLanguage.hindi:
        return 'गोटी केवल जुड़े हुए खाली बिंदु पर जा सकती है या कूद सकती है';
      case AppLanguage.punjabi:
        return 'گوٹی صرف جڑے ہوئے خالی تھاں تے جا سکدی اے';
      case AppLanguage.arabic:
        return 'يمكن تحريك القطعة للنقطة المتصلة الفارغة أو القفز';
      case AppLanguage.bengali:
        return 'দানা শুধু সংযুক্ত খালি ঘরে বা লাফিয়ে যেতে পারে';
    }
  }

  static String get notYourTurn {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ابھی آپ کی باری نہیں ہے';
      case AppLanguage.english:
        return 'Not your turn yet';
      case AppLanguage.hindi:
        return 'अभी आपकी बारी नहीं है';
      case AppLanguage.punjabi:
        return 'ہجے تہاڈی واری نئیں اے';
      case AppLanguage.arabic:
        return 'ليس دورك الآن';
      case AppLanguage.bengali:
        return 'এখন আপনার চাল নয়';
    }
  }

  // Points & Economy Strings
  static String get points {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پوائنٹس';
      case AppLanguage.english:
        return 'Points';
      case AppLanguage.hindi:
        return 'अंक';
      case AppLanguage.punjabi:
        return 'پوائنٹس';
      case AppLanguage.arabic:
        return 'نقاط';
      case AppLanguage.bengali:
        return 'পয়েন্ট';
    }
  }

  static String get captureReward {
    switch (_lang) {
      case AppLanguage.urdu:
        return '+10 پوائنٹس! شاندار شکار';
      case AppLanguage.english:
        return '+10 Points! Great capture!';
      case AppLanguage.hindi:
        return '+10 अंक! शानदार शिकार';
      case AppLanguage.punjabi:
        return '+10 پوائنٹس! شاندار شکار';
      case AppLanguage.arabic:
        return '+10 نقاط! قفزة رائعة';
      case AppLanguage.bengali:
        return '+১০ পয়েন্ট! চমৎকার শিকার';
    }
  }

  static String get undoCostNotice {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'چال واپس لینے پر 10 پوائنٹس کٹ گئے';
      case AppLanguage.english:
        return '10 Points deducted for Undo';
      case AppLanguage.hindi:
        return 'चाल वापस लेने पर 10 अंक कटे';
      case AppLanguage.punjabi:
        return 'چال واپس لین تے ۱۰ پوائنٹس کٹ گئے';
      case AppLanguage.arabic:
        return 'تم خصم 10 نقاط للتراجع عن الحركة';
      case AppLanguage.bengali:
        return 'চাল ফেরাতে ১০ পয়েন্ট কাটা হয়েছে';
    }
  }

  static String get notEnoughPointsForUndo {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'چال واپس لینے کے لیے کم از کم 10 پوائنٹس درکار ہیں!';
      case AppLanguage.english:
        return 'Need at least 10 Points to undo a move!';
      case AppLanguage.hindi:
        return 'चाल वापस लेने के लिए कम से कम 10 अंक चाहिए!';
      case AppLanguage.punjabi:
        return 'چال واپس لین لئی گھٹو گھٹ ۱۰ پوائنٹس چاہیدے نیں!';
      case AppLanguage.arabic:
        return 'تحتاج 10 نقاط على الأقل للتراجع عن الحركة!';
      case AppLanguage.bengali:
        return 'চাল ফেরাতে কমপক্ষে ১০ পয়েন্ট লাগবে!';
    }
  }

  // Daily Bonus Strings
  static String get dailyBonus {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ڈیلی بونس';
      case AppLanguage.english:
        return 'Daily Bonus';
      case AppLanguage.hindi:
        return 'दैनिक बोनस';
      case AppLanguage.punjabi:
        return 'ڈیلی بونس';
      case AppLanguage.arabic:
        return 'المكافأة اليومية';
      case AppLanguage.bengali:
        return 'দৈনিক বোনাস';
    }
  }

  static String get dailyBonusTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return '🎁 روزانہ کا مفت تحفہ!';
      case AppLanguage.english:
        return '🎁 Daily Free Reward!';
      case AppLanguage.hindi:
        return '🎁 दैनिक मुफ्त इनाम!';
      case AppLanguage.punjabi:
        return '🎁 روز دا مفت انعام!';
      case AppLanguage.arabic:
        return '🎁 الهدية اليومية المجانية!';
      case AppLanguage.bengali:
        return '🎁 দৈনিক ফ্রি উপহার!';
    }
  }

  static String get dailyBonusDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہر 24 گھنٹے بعد 100 مفت پوائنٹس حاصل کریں اور گیم انجوائے کریں۔';
      case AppLanguage.english:
        return 'Claim 100 free points every 24 hours to enjoy the game.';
      case AppLanguage.hindi:
        return 'हर 24 घंटे में 100 मुफ्त अंक प्राप्त करें।';
      case AppLanguage.punjabi:
        return 'ہر ۲۴ گھنٹے بعد ۱۰۰ مفت پوائنٹس حاصل کرو۔';
      case AppLanguage.arabic:
        return 'احصل على 100 نقطة مجانية كل 24 ساعة.';
      case AppLanguage.bengali:
        return 'প্রতি ২৪ ঘণ্টায় ১০০ ফ্রি পয়েন্ট পান।';
    }
  }

  static String get claimDailyBonus {
    switch (_lang) {
      case AppLanguage.urdu:
        return '100 پوائنٹس حاصل کریں';
      case AppLanguage.english:
        return 'Claim 100 Points';
      case AppLanguage.hindi:
        return '100 अंक प्राप्त करें';
      case AppLanguage.punjabi:
        return '۱۰۰ پوائنٹس لوو';
      case AppLanguage.arabic:
        return 'استلم 100 نقطة';
      case AppLanguage.bengali:
        return '১০০ পয়েন্ট নিন';
    }
  }

  static String get dailyBonusClaimed {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مبارک ہو! آپ کو 100 پوائنٹس مل گئے! 🎉';
      case AppLanguage.english:
        return 'Congratulations! You received 100 Points! 🎉';
      case AppLanguage.hindi:
        return 'बधाई हो! आपको 100 अंक मिले! 🎉';
      case AppLanguage.punjabi:
        return 'مبارکاں! تہانوں ۱۰۰ پوائنٹس مل گئے! 🎉';
      case AppLanguage.arabic:
        return 'مبروك! لقد حصلت على 100 نقطة! 🎉';
      case AppLanguage.bengali:
        return 'অভিনন্দন! আপনি ১০০ পয়েন্ট পেয়েছেন! 🎉';
    }
  }

  static String get dailyBonusAlreadyClaimed {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آج کا ڈیلی بونس آپ پہلے ہی کلیم کر چکے ہیں! کل دوبارہ تشریف لائیں۔';
      case AppLanguage.english:
        return 'Today\'s bonus is already claimed! Come back tomorrow.';
      case AppLanguage.hindi:
        return 'आज का बोनस पहले ही लिया जा चुका है! कल वापस आएं।';
      case AppLanguage.punjabi:
        return 'اج دا بونس تسی پہلے ای لے چکے او! کل آونا۔';
      case AppLanguage.arabic:
        return 'تم استلام مكافأة اليوم بالفعل! عد غداً.';
      case AppLanguage.bengali:
        return 'আজকের বোনাস নেওয়া হয়েছে! কাল আবার আসুন।';
    }
  }

  // Lucky Spin Wheel Strings
  static String get luckySpin {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'قسمت کا پہیہ';
      case AppLanguage.english:
        return 'Lucky Wheel';
      case AppLanguage.hindi:
        return 'भाग्य का पहिया';
      case AppLanguage.punjabi:
        return 'قسمت دا پہیا';
      case AppLanguage.arabic:
        return 'عجلة الحظ';
      case AppLanguage.bengali:
        return 'ভাগ্যের চাকা';
    }
  }

  static String get luckySpinDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پہیہ گھمائیں اور جیتیں 0، 5، 10، 20، 50 یا 100 پوائنٹس!';
      case AppLanguage.english:
        return 'Spin the wheel and win 0, 5, 10, 20, 50 or 100 Points!';
      case AppLanguage.hindi:
        return 'पहिया घुमाएं और 0, 5, 10, 20, 50 या 100 अंक जीतें!';
      case AppLanguage.punjabi:
        return 'پہیا گھماؤ تے ۰، ۵، ۱۰، ۲۰، ۵۰ یا ۱۰۰ پوائنٹس جتو!';
      case AppLanguage.arabic:
        return 'أدر العجلة واربح 0، 5، 10، 20، 50 أو 100 نقطة!';
      case AppLanguage.bengali:
        return 'চাকা ঘুরিয়ে ০, ৫, ১০, ২০, ৫০ বা ১০০ পয়েন্ট জিতুন!';
    }
  }

  static String get spinCooldownDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'لکی ویل ہر 10 گھنٹے بعد دستیاب ہوتا ہے';
      case AppLanguage.english:
        return 'Lucky Wheel is available once every 10 hours';
      case AppLanguage.hindi:
        return 'लकी व्हील हर 10 घंटे में एक बार उपलब्ध होता है';
      case AppLanguage.punjabi:
        return 'لکی ویل ہر ۱۰ گھنٹے بعد گھمایا جا سکدا اے';
      case AppLanguage.arabic:
        return 'عجلة الحظ متاحة مرة واحدة كل 10 ساعات';
      case AppLanguage.bengali:
        return 'ভাগ্যের চাকা প্রতি ১০ ঘণ্টায় একবার উপলব্ধ';
    }
  }

  static String get nextSpinIn {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'اگلا اسپن دستیاب ہوگا:';
      case AppLanguage.english:
        return 'Next spin in:';
      case AppLanguage.hindi:
        return 'अगला स्पिन:';
      case AppLanguage.punjabi:
        return 'اگلا اسپن:';
      case AppLanguage.arabic:
        return 'اللفة القادمة في:';
      case AppLanguage.bengali:
        return 'পরবর্তী স্পিন:';
    }
  }

  static String get soundEffects {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'صوتی اثرات (Sound FX)';
      case AppLanguage.english:
        return 'Sound Effects';
      case AppLanguage.hindi:
        return 'ध्वनि प्रभाव (Sound FX)';
      case AppLanguage.punjabi:
        return 'آواز دے اثرات';
      case AppLanguage.arabic:
        return 'المؤثرات الصوتية';
      case AppLanguage.bengali:
        return 'শব্দ প্রভাব';
    }
  }

  static String get soundEffectsDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مہرے کی چال، شکار اور جیت کی آوازیں';
      case AppLanguage.english:
        return 'Move, capture and victory sounds';
      case AppLanguage.hindi:
        return 'चाल, शिकार और जीत की आवाजें';
      case AppLanguage.punjabi:
        return 'چال، شکار تے جت دیاں آوازاں';
      case AppLanguage.arabic:
        return 'أصوات الحركة والأكل والفوز';
      case AppLanguage.bengali:
        return 'চাল, শিকার ও বিজয়ের শব্দ';
    }
  }

  static String get playerNamesSection {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پلیئرز کے نام (Player Names)';
      case AppLanguage.english:
        return 'Player Names';
      case AppLanguage.hindi:
        return 'खिलाड़ियों के नाम';
      case AppLanguage.punjabi:
        return 'کھلاڑیاں دے ناں';
      case AppLanguage.arabic:
        return 'أسماء اللاعبين';
      case AppLanguage.bengali:
        return 'খেলোয়াড়দের নাম';
    }
  }

  static String get player1NameLabel {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۱ کا نام (Player 1 / AI):';
      case AppLanguage.english:
        return 'Player 1 Name (AI / Opponent):';
      case AppLanguage.hindi:
        return 'खिलाड़ी 1 का नाम:';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۱ دا ناں:';
      case AppLanguage.arabic:
        return 'اسم اللاعب 1:';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ১ এর নাম:';
    }
  }

  static String get player2NameLabel {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۲ کا نام (Player 2 / You):';
      case AppLanguage.english:
        return 'Player 2 Name (You):';
      case AppLanguage.hindi:
        return 'खिलाड़ी 2 का नाम:';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۲ دا ناں:';
      case AppLanguage.arabic:
        return 'اسم اللاعب 2:';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ২ এর নাম:';
    }
  }

  static String get player1NameHint {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مثلاً: کھلاڑی ۱ / کمپیوٹر';
      case AppLanguage.english:
        return 'e.g. Player 1 / AI';
      case AppLanguage.hindi:
        return 'उदा: खिलाड़ी 1 / कंप्यूटर';
      case AppLanguage.punjabi:
        return 'مثلاً: کھلاڑی ۱';
      case AppLanguage.arabic:
        return 'مثال: اللاعب 1';
      case AppLanguage.bengali:
        return 'যেমন: খেলোয়াড় ১';
    }
  }

  static String get player2NameHint {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مثلاً: علی / عثمان';
      case AppLanguage.english:
        return 'e.g. Alex / You';
      case AppLanguage.hindi:
        return 'उदा: अमन / आप';
      case AppLanguage.punjabi:
        return 'مثلاً: علی';
      case AppLanguage.arabic:
        return 'مثال: علي';
      case AppLanguage.bengali:
        return 'যেমন: রাহুল';
    }
  }

  static String get beadColorsSection {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مہروں کے دلکش رنگ (Bead Colors)';
      case AppLanguage.english:
        return 'Piece Colors';
      case AppLanguage.hindi:
        return 'मोहरों के आकर्षक रंग';
      case AppLanguage.punjabi:
        return 'گوٹیاں دے سوہنے رنگ';
      case AppLanguage.arabic:
        return 'ألوان القطع الجذابة';
      case AppLanguage.bengali:
        return 'দানার আকর্ষণীয় রঙ';
    }
  }

  static String get player1ColorTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۱ کے مہرے کا رنگ:';
      case AppLanguage.english:
        return 'Player 1 Piece Color:';
      case AppLanguage.hindi:
        return 'खिलाड़ी 1 की मोहर का रंग:';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۱ دی گوٹی دا رنگ:';
      case AppLanguage.arabic:
        return 'لون قطع اللاعب 1:';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ১ এর দানার রঙ:';
    }
  }

  static String get player2ColorTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۲ کے مہرے کا رنگ:';
      case AppLanguage.english:
        return 'Player 2 Piece Color:';
      case AppLanguage.hindi:
        return 'खिलाड़ी 2 की मोहर का रंग:';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۲ دی گوٹی دا رنگ:';
      case AppLanguage.arabic:
        return 'لون قطع اللاعب 2:';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ২ এর দানার রঙ:';
    }
  }

  static String get pieceStylesSection {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مہروں کے مختلف ڈیزائن اور اشکال (Piece Styles)';
      case AppLanguage.english:
        return 'Piece Styles & Designs';
      case AppLanguage.hindi:
        return 'मोहरों के विभिन्न डिजाइन';
      case AppLanguage.punjabi:
        return 'گوٹیاں دے وکھرے ڈیزائن';
      case AppLanguage.arabic:
        return 'تصاميم وأشكال القطع المختلفة';
      case AppLanguage.bengali:
        return 'দানার বিভিন্ন নকশা';
    }
  }

  static String get player1StyleTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۱ کا مہرہ ڈیزائن:';
      case AppLanguage.english:
        return 'Player 1 Piece Design:';
      case AppLanguage.hindi:
        return 'खिलाड़ी 1 का मोहरा डिजाइन:';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۱ دا گوٹی ڈیزائن:';
      case AppLanguage.arabic:
        return 'تصميم قطع اللاعب 1:';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ১ এর নকশা:';
    }
  }

  static String get player2StyleTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھلاڑی ۲ کا مہرہ ڈیزائن:';
      case AppLanguage.english:
        return 'Player 2 Piece Design:';
      case AppLanguage.hindi:
        return 'खिलाड़ी 2 का मोहरा डिजाइन:';
      case AppLanguage.punjabi:
        return 'کھلاڑی ۲ دا گوٹی ڈیزائن:';
      case AppLanguage.arabic:
        return 'تصميم قطع اللاعب 2:';
      case AppLanguage.bengali:
        return 'খেলোয়াড় ২ এর নকশা:';
    }
  }

  static String get boardThemeSection {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'بورڈ کا انداز اور تھیم (Board Theme)';
      case AppLanguage.english:
        return 'Board Theme & Style';
      case AppLanguage.hindi:
        return 'बोर्ड थीम और शैली';
      case AppLanguage.punjabi:
        return 'بورڈ دا انداز تے تھیم';
      case AppLanguage.arabic:
        return 'سمات وطابع الرقعة';
      case AppLanguage.bengali:
        return 'বোর্ড থিম ও স্টাইল';
    }
  }

  static String get audioGameplaySection {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'آواز اور گیم پلے (Audio & Gameplay)';
      case AppLanguage.english:
        return 'Audio & Gameplay';
      case AppLanguage.hindi:
        return 'ध्वनि और गेमप्ले';
      case AppLanguage.punjabi:
        return 'آواز تے گیم پلے';
      case AppLanguage.arabic:
        return 'الصوت واللعب';
      case AppLanguage.bengali:
        return 'অডিও এবং গেমপ্লে';
    }
  }

  static String get vibration {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'جھٹکا (Vibration)';
      case AppLanguage.english:
        return 'Haptic Vibration';
      case AppLanguage.hindi:
        return 'कंपन (Vibration)';
      case AppLanguage.punjabi:
        return 'جھٹکا (وائبریشن)';
      case AppLanguage.arabic:
        return 'الاهتزاز اللمسي';
      case AppLanguage.bengali:
        return 'হ্যাপটিক কম্পন';
    }
  }

  static String get vibrationDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ٹیپ اور شکار پر وائبریشن فیڈبیک';
      case AppLanguage.english:
        return 'Vibration feedback on taps and captures';
      case AppLanguage.hindi:
        return 'टैप और शिकार पर कंपन फीडबैक';
      case AppLanguage.punjabi:
        return 'ٹیپ تے شکار تے وائبریشن';
      case AppLanguage.arabic:
        return 'اهتزاز عند الحركة والأكل';
      case AppLanguage.bengali:
        return 'ট্যাপ ও শিকারে কম্পন প্রতিক্রিয়া';
    }
  }

  static String get moveHints {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'چال کے اشارے (Move Hints)';
      case AppLanguage.english:
        return 'Legal Move Hints';
      case AppLanguage.hindi:
        return 'चाल के संकेत (Hints)';
      case AppLanguage.punjabi:
        return 'چال دے اشارے';
      case AppLanguage.arabic:
        return 'تلميحات الحركة القانونية';
      case AppLanguage.bengali:
        return 'চালের ইঙ্গিত (Hints)';
    }
  }

  static String get moveHintsDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ممکنہ قانونی چالوں کے لیے روشن دائرے دکھائیں';
      case AppLanguage.english:
        return 'Display glowing indicator rings for valid legal moves';
      case AppLanguage.hindi:
        return 'संभावित कानूनी चालों के लिए चमकते घेरे दिखाएं';
      case AppLanguage.punjabi:
        return 'قانونی چالاں لئی چمکدے دائرے وکھاؤ';
      case AppLanguage.arabic:
        return 'إظهار دوائر مضيئة للتحركات القانونية الممكنة';
      case AppLanguage.bengali:
        return 'বৈধ চালের জন্য উজ্জ্বল বৃত্ত প্রদর্শন করুন';
    }
  }

  static String get fastAi {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'تیز رفتار AI (Fast AI)';
      case AppLanguage.english:
        return 'Fast AI Response';
      case AppLanguage.hindi:
        return 'त्वरित AI प्रतिक्रिया';
      case AppLanguage.punjabi:
        return 'تیز رفتار AI';
      case AppLanguage.arabic:
        return 'استجابة سريعة للذكاء الاصطناعي';
      case AppLanguage.bengali:
        return 'দ্রুত এআই প্রতিক্রিয়া';
    }
  }

  static String get fastAiDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کمپیوٹر کی باری پر فوری چال چلیں';
      case AppLanguage.english:
        return 'AI moves immediately without thinking delay';
      case AppLanguage.hindi:
        return 'कंप्यूटर की बारी पर बिना देरी तुरंत चाल चले';
      case AppLanguage.punjabi:
        return 'کمپیوٹر دی باری تے فوری چال چلے';
      case AppLanguage.arabic:
        return 'يلعب الذكاء الاصطناعي فوراً دون تأخير';
      case AppLanguage.bengali:
        return 'এআই বিলম্ব ছাড়াই তাৎক্ষণিক চাল দেবে';
    }
  }

  static String get resetSettings {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'تمام سیٹنگز اصل حالت پر واپس کریں (Reset to Defaults)';
      case AppLanguage.english:
        return 'Reset All Settings to Defaults';
      case AppLanguage.hindi:
        return 'सभी सेटिंग्स मूल स्थिति में रीसेट करें';
      case AppLanguage.punjabi:
        return 'ساریاں سیٹنگز اصلی حالت تے لیاؤ';
      case AppLanguage.arabic:
        return 'إعادة ضبط كافة الإعدادات إلى الوضع الافتراضي';
      case AppLanguage.bengali:
        return 'সমস্ত সেটিংস ডিফল্ট অবস্থায় রিসেট করুন';
    }
  }

  static String get resetSuccessNotice {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'سیٹنگز اصل حالت پر بحال کر دی گئیں!';
      case AppLanguage.english:
        return 'Settings restored to defaults!';
      case AppLanguage.hindi:
        return 'सेटिंग्स सफलतापूर्वक रीसेट हो गईं!';
      case AppLanguage.punjabi:
        return 'سیٹنگز اصلی حالت تے آ گئیاں!';
      case AppLanguage.arabic:
        return 'تمت استعادة الإعدادات الافتراضية بنجاح!';
      case AppLanguage.bengali:
        return 'সেটিংস সফলভাবে রিসেট করা হয়েছে!';
    }
  }

  static String get spinNow {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پہیہ گھمائیں';
      case AppLanguage.english:
        return 'Spin Wheel';
      case AppLanguage.hindi:
        return 'पहिया घुमाएं';
      case AppLanguage.punjabi:
        return 'پہیا گھماؤ';
      case AppLanguage.arabic:
        return 'أدر العجلة';
      case AppLanguage.bengali:
        return 'চাকা ঘুরান';
    }
  }

  static String get spinning {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پہیہ گھوم رہا ہے...';
      case AppLanguage.english:
        return 'Spinning...';
      case AppLanguage.hindi:
        return 'पहिया घूम रहा है...';
      case AppLanguage.punjabi:
        return 'پہیا گھم رہیا اے...';
      case AppLanguage.arabic:
        return 'العجلة تدور...';
      case AppLanguage.bengali:
        return 'চাকা ঘুরছে...';
    }
  }

  static String get spinWonZero {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'اوہ! 0 پوائنٹس، اگلی بار بہتر قسمت! 🍀';
      case AppLanguage.english:
        return 'Oops! 0 Points, better luck next time! 🍀';
      case AppLanguage.hindi:
        return 'ओह! 0 अंक, अगली बार बेहतर किस्मत! 🍀';
      case AppLanguage.punjabi:
        return 'اوہو! ۰ پوائنٹس، اگلی واری سہی! 🍀';
      case AppLanguage.arabic:
        return 'للأسف 0 نقطة، حظاً أوفر في المرة القادمة! 🍀';
      case AppLanguage.bengali:
        return '০ পয়েন্ট, পরের বার চেষ্টা করুন! 🍀';
    }
  }

  static String get spinWonPoints {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مبارک ہو! آپ نے جیت لیے';
      case AppLanguage.english:
        return 'Congratulations! You won';
      case AppLanguage.hindi:
        return 'बधाई हो! आपने जीते';
      case AppLanguage.punjabi:
        return 'مبارکاں! تسی جتے';
      case AppLanguage.arabic:
        return 'مبروك! لقد ربحت';
      case AppLanguage.bengali:
        return 'অভিনন্দন! আপনি জিতেছেন';
    }
  }

  // Timer & Timeout Strings
  static String get timeoutWarning {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'وقت ختم!';
      case AppLanguage.english:
        return 'Time\'s Up!';
      case AppLanguage.hindi:
        return 'समय समाप्त!';
      case AppLanguage.punjabi:
        return 'ویلا مک گیا!';
      case AppLanguage.arabic:
        return 'انتهى الوقت!';
      case AppLanguage.bengali:
        return 'সময় শেষ!';
    }
  }

  static String get turnSwitchedTimeout {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'وقت ختم! باری دوسرے کھلاڑی کو مل گئی';
      case AppLanguage.english:
        return 'Time up! Turn passed to opponent';
      case AppLanguage.hindi:
        return 'समय समाप्त! बारी अगले खिलाड़ी को मिली';
      case AppLanguage.punjabi:
        return 'ویلا مک گیا! واری اگلے کھلاڑی کول چلی گئی';
      case AppLanguage.arabic:
        return 'انتهى الوقت! انتقل الدور للخصم';
      case AppLanguage.bengali:
        return 'সময় শেষ! চাল প্রতিপক্ষকে দেওয়া হল';
    }
  }

  static String get timeoutVictoryTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'وقت ختم ہونے پر فتح!';
      case AppLanguage.english:
        return 'Timeout Victory!';
      case AppLanguage.hindi:
        return 'समय समाप्ति पर जीत!';
      case AppLanguage.punjabi:
        return 'ویلا مکن تے جت!';
      case AppLanguage.arabic:
        return 'الفوز لانتهاء الوقت!';
      case AppLanguage.bengali:
        return 'সময় শেষ হওয়ায় জয়!';
    }
  }

  static String get timeoutDefeatTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'وقت ختم ہونے پر شکست!';
      case AppLanguage.english:
        return 'Timeout Defeat!';
      case AppLanguage.hindi:
        return 'समय समाप्ति पर हार!';
      case AppLanguage.punjabi:
        return 'ویلا مکن تے ہار!';
      case AppLanguage.arabic:
        return 'الخسارة لانتهاء الوقت!';
      case AppLanguage.bengali:
        return 'সময় শেষ হওয়ায় পরাজয়!';
    }
  }

  static String get timeoutDefeatDesc {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۵ بار وقت پر چال نہ چلنے پر گیم ختم ہو گئی!';
      case AppLanguage.english:
        return 'Game over after 5 timeouts!';
      case AppLanguage.hindi:
        return '5 बार समय समाप्त होने पर खेल समाप्त!';
      case AppLanguage.punjabi:
        return '۵ واری ویلا مکن تے گیم مک گئی!';
      case AppLanguage.arabic:
        return 'انتهت اللعبة بعد انتهاء الوقت 5 مرات!';
      case AppLanguage.bengali:
        return '৫ বার সময় শেষ হওয়ায় খেলা সমাপ্ত!';
    }
  }

  // Stats & Counters
  static String get beadsLeft {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'باقی مہرے';
      case AppLanguage.english:
        return 'Beads Left';
      case AppLanguage.hindi:
        return 'शेष गोटियाँ';
      case AppLanguage.punjabi:
        return 'باقی گوٹیاں';
      case AppLanguage.arabic:
        return 'القطع المتبقية';
      case AppLanguage.bengali:
        return 'বাকি দানা';
    }
  }

  // Buttons & Controls
  static String get playNow {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ابھی کھیلیں';
      case AppLanguage.english:
        return 'Play Now';
      case AppLanguage.hindi:
        return 'अभी खेलें';
      case AppLanguage.punjabi:
        return 'ہنڑے کھیلو';
      case AppLanguage.arabic:
        return 'العب الآن';
      case AppLanguage.bengali:
        return 'এখন খেলুন';
    }
  }

  static String get newGame {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'نیا کھیل';
      case AppLanguage.english:
        return 'New Game';
      case AppLanguage.hindi:
        return 'नया खेल';
      case AppLanguage.punjabi:
        return 'نواں کھیل';
      case AppLanguage.arabic:
        return 'لعبة جديدة';
      case AppLanguage.bengali:
        return 'নতুন খেলা';
    }
  }

  static String get restart {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دوبارہ شروع کریں';
      case AppLanguage.english:
        return 'Restart';
      case AppLanguage.hindi:
        return 'पुनः आरंभ करें';
      case AppLanguage.punjabi:
        return 'مڑ شروع کرو';
      case AppLanguage.arabic:
        return 'إعادة التشغيل';
      case AppLanguage.bengali:
        return 'পুনরায় শুরু';
    }
  }

  static String get pause {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'روکیں';
      case AppLanguage.english:
        return 'Pause';
      case AppLanguage.hindi:
        return 'रोकें';
      case AppLanguage.punjabi:
        return 'روکو';
      case AppLanguage.arabic:
        return 'إيقاف مؤقت';
      case AppLanguage.bengali:
        return 'বিরতি';
    }
  }

  static String get resume {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'جاری رکھیں';
      case AppLanguage.english:
        return 'Resume';
      case AppLanguage.hindi:
        return 'जारी रखें';
      case AppLanguage.punjabi:
        return 'جاری رکھو';
      case AppLanguage.arabic:
        return 'استئناف';
      case AppLanguage.bengali:
        return 'চালিয়ে যান';
    }
  }

  static String get undo {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'چال واپس';
      case AppLanguage.english:
        return 'Undo';
      case AppLanguage.hindi:
        return 'चाल वापस';
      case AppLanguage.punjabi:
        return 'چال واپس';
      case AppLanguage.arabic:
        return 'تراجع';
      case AppLanguage.bengali:
        return 'চাল ফেরান';
    }
  }

  static String get home {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہوم';
      case AppLanguage.english:
        return 'Home';
      case AppLanguage.hindi:
        return 'होम';
      case AppLanguage.punjabi:
        return 'ہوم';
      case AppLanguage.arabic:
        return 'الرئيسية';
      case AppLanguage.bengali:
        return 'হোম';
    }
  }

  static String get rules {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھیل کے اصول';
      case AppLanguage.english:
        return 'Rules';
      case AppLanguage.hindi:
        return 'खेल के नियम';
      case AppLanguage.punjabi:
        return 'کھیل دے اصول';
      case AppLanguage.arabic:
        return 'قواعد اللعبة';
      case AppLanguage.bengali:
        return 'খেলার নিয়ম';
    }
  }

  static String get settings {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'سیٹنگز';
      case AppLanguage.english:
        return 'Settings';
      case AppLanguage.hindi:
        return 'सेटिंग्स';
      case AppLanguage.punjabi:
        return 'سیٹنگز';
      case AppLanguage.arabic:
        return 'الإعدادات';
      case AppLanguage.bengali:
        return 'সেটিংস';
    }
  }

  static String get rematch {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دوبارہ مقابلہ';
      case AppLanguage.english:
        return 'Rematch';
      case AppLanguage.hindi:
        return 'दोबारा मुकाबला';
      case AppLanguage.punjabi:
        return 'مڑ مقابلہ';
      case AppLanguage.arabic:
        return 'مباراة ثانية';
      case AppLanguage.bengali:
        return 'পুনরায় খেলুন';
    }
  }

  static String get confirm {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ٹھیک ہے';
      case AppLanguage.english:
        return 'OK';
      case AppLanguage.hindi:
        return 'ठीक है';
      case AppLanguage.punjabi:
        return 'ٹھیک اے';
      case AppLanguage.arabic:
        return 'حسناً';
      case AppLanguage.bengali:
        return 'ঠিক আছে';
    }
  }

  static String get cancel {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'منسوخ';
      case AppLanguage.english:
        return 'Cancel';
      case AppLanguage.hindi:
        return 'रद्द करें';
      case AppLanguage.punjabi:
        return 'منسوخ';
      case AppLanguage.arabic:
        return 'إلغاء';
      case AppLanguage.bengali:
        return 'বাতিল';
    }
  }

  static String get yes {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہاں';
      case AppLanguage.english:
        return 'Yes';
      case AppLanguage.hindi:
        return 'हाँ';
      case AppLanguage.punjabi:
        return 'ہاں';
      case AppLanguage.arabic:
        return 'نعم';
      case AppLanguage.bengali:
        return 'হ্যাঁ';
    }
  }

  static String get no {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'نہیں';
      case AppLanguage.english:
        return 'No';
      case AppLanguage.hindi:
        return 'नहीं';
      case AppLanguage.punjabi:
        return 'نئیں';
      case AppLanguage.arabic:
        return 'لا';
      case AppLanguage.bengali:
        return 'না';
    }
  }

  static String get settingsTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'گیم سیٹنگز (Settings)';
      case AppLanguage.english:
        return 'Game Settings';
      case AppLanguage.hindi:
        return 'गेम सेटिंग्स (Settings)';
      case AppLanguage.punjabi:
        return 'گیم سیٹنگز (Settings)';
      case AppLanguage.arabic:
        return 'إعدادات اللعبة (Settings)';
      case AppLanguage.bengali:
        return 'গেম সেটিংস (Settings)';
    }
  }

  // Language section strings
  static String get languageTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'زبان (Language)';
      case AppLanguage.english:
        return 'Language (زبان)';
      case AppLanguage.hindi:
        return 'भाषा (Language)';
      case AppLanguage.punjabi:
        return 'بولی (Language)';
      case AppLanguage.arabic:
        return 'اللغة (Language)';
      case AppLanguage.bengali:
        return 'ভাষা (Language)';
    }
  }

  // Dialogs
  static String get gamePaused {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'گیم روک دی گئی ہے';
      case AppLanguage.english:
        return 'Game Paused';
      case AppLanguage.hindi:
        return 'खेल रुका हुआ है';
      case AppLanguage.punjabi:
        return 'گیم رکی ہوئی اے';
      case AppLanguage.arabic:
        return 'اللعبة متوقفة';
      case AppLanguage.bengali:
        return 'খেলা বিরতি';
    }
  }

  static String get restartConfirm {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کیا آپ واقعی نیا کھیل شروع کرنا چاہتے ہیں؟';
      case AppLanguage.english:
        return 'Are you sure you want to restart the game?';
      case AppLanguage.hindi:
        return 'क्या आप वाकई खेल पुनः आरंभ करना चाहते हैं?';
      case AppLanguage.punjabi:
        return 'کی تسی سچی نواں کھیل شروع کرنا چاہندے او؟';
      case AppLanguage.arabic:
        return 'هل أنت متأكد أنك تريد إعادة بدء اللعبة؟';
      case AppLanguage.bengali:
        return 'আপনি কি নিশ্চিত যে নতুন করে শুরু করতে চান?';
    }
  }

  static String get quitConfirm {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کیا آپ گیم چھوڑ کر مرکزی صفحے پر جانا چاہتے ہیں؟';
      case AppLanguage.english:
        return 'Are you sure you want to quit to Home?';
      case AppLanguage.hindi:
        return 'क्या आप मुख्य पृष्ठ पर जाना चाहते हैं?';
      case AppLanguage.punjabi:
        return 'کی تسی گیم چھڈ کے ہوم تے جانا چاہندے او؟';
      case AppLanguage.arabic:
        return 'هل تريد العودة إلى الشاشة الرئيسية؟';
      case AppLanguage.bengali:
        return 'আপনি কি মূল পাতায় ফিরে যেতে চান?';
    }
  }

  // Victory / Defeat
  static String get victoryTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'شاندار فتح! 🎉';
      case AppLanguage.english:
        return 'Spectacular Victory! 🎉';
      case AppLanguage.hindi:
        return 'शानदार जीत! 🎉';
      case AppLanguage.punjabi:
        return 'شاندار جت! 🎉';
      case AppLanguage.arabic:
        return 'فوز رائع! 🎉';
      case AppLanguage.bengali:
        return 'অসাধারণ জয়! 🎉';
    }
  }

  static String get defeatTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کھیل ختم! 😔';
      case AppLanguage.english:
        return 'Game Over! 😔';
      case AppLanguage.hindi:
        return 'खेल समाप्त! 😔';
      case AppLanguage.punjabi:
        return 'کھیل مک گیا! 😔';
      case AppLanguage.arabic:
        return 'انتهت اللعبة! 😔';
      case AppLanguage.bengali:
        return 'খেলা শেষ! 😔';
    }
  }

  static String get drawTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'برابر مقابلہ! 🤝';
      case AppLanguage.english:
        return 'Match Draw! 🤝';
      case AppLanguage.hindi:
        return 'मैच ड्रॉ! 🤝';
      case AppLanguage.punjabi:
        return 'برابر مقابلہ! 🤝';
      case AppLanguage.arabic:
        return 'تعادل! 🤝';
      case AppLanguage.bengali:
        return 'খেলা ড্র! 🤝';
    }
  }

  static String get youWon {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مبارک ہو! آپ نے کمپیوٹر کو ہرا دیا!';
      case AppLanguage.english:
        return 'Congratulations! You defeated the Computer!';
      case AppLanguage.hindi:
        return 'बधाई हो! आपने कंप्यूटर को हरा दिया!';
      case AppLanguage.punjabi:
        return 'مبارکاں! تسی کمپیوٹر نوں ہرا دتا!';
      case AppLanguage.arabic:
        return 'مبروك! لقد هزمت الكمبيوتر!';
      case AppLanguage.bengali:
        return 'অভিনন্দন! আপনি কম্পিউটারকে হারিয়েছেন!';
    }
  }

  static String get computerWon {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'کمپیوٹر جیت گیا! اگلی بار بہتر کوشش کریں۔';
      case AppLanguage.english:
        return 'Computer won! Better luck next time.';
      case AppLanguage.hindi:
        return 'कंप्यूटर जीत गया! अगली बार बेहतर प्रयास करें।';
      case AppLanguage.punjabi:
        return 'کمپیوٹر جت گیا! اگلی واری کوشش کرو۔';
      case AppLanguage.arabic:
        return 'فاز الكمبيوتر! حظاً أوفر في المرة القادمة.';
      case AppLanguage.bengali:
        return 'কম্পিউটার জিতেছে! পরের বার চেষ্টা করুন।';
    }
  }

  // Rules Guide Sections
  static String get rulesTitle {
    switch (_lang) {
      case AppLanguage.urdu:
        return '12 ٹہنی کے مستند اصول';
      case AppLanguage.english:
        return 'Official 12 Tani Rules';
      case AppLanguage.hindi:
        return '12 टहनी के प्रामाणिक नियम';
      case AppLanguage.punjabi:
        return '12 ٹہنی دے مستند اصول';
      case AppLanguage.arabic:
        return 'قواعد لعبة 12 غصناً';
      case AppLanguage.bengali:
        return '১২ দানার নিয়মাবলী';
    }
  }

  static String get rule1Title {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۱. بورڈ اور مہرے';
      case AppLanguage.english:
        return '1. Board & Pieces';
      case AppLanguage.hindi:
        return '1. बोर्ड और गोटियाँ';
      case AppLanguage.punjabi:
        return '۱. بورڈ تے گوٹیاں';
      case AppLanguage.arabic:
        return '١. اللوحة والقطع';
      case AppLanguage.bengali:
        return '১. বোর্ড এবং দানা';
    }
  }

  static String get rule1Desc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'بورڈ پر کل 25 خانے (پوائنٹس) ہوتے ہیں۔ دونوں کھلاڑیوں کے پاس 12، 12 مہرے ہوتے ہیں اور درمیانی پوائنٹ شروع میں خالی ہوتا ہے۔';
      case AppLanguage.english:
        return '5x5 grid with 25 points. Each player has 12 pieces. The center point is empty at start.';
      case AppLanguage.hindi:
        return '25 बिंदुओं का बोर्ड। दोनों खिलाड़ियों के पास 12-12 गोटियाँ होती हैं, बीच का बिंदु खाली होता है।';
      case AppLanguage.punjabi:
        return 'بورڈ تے کل ۲۵ پوائنٹس ہوندے نیں۔ دونوں کھڈاریاں کول ۱۲، ۱۲ گوٹیاں ہوندیاں نیں تے وچکارلا پوائنٹ خالی ہوندا اے۔';
      case AppLanguage.arabic:
        return 'لوحة من 25 نقطة. يمتلك كل لاعب 12 قطعة وتكون النقطة المركزية فارغة في البداية.';
      case AppLanguage.bengali:
        return 'বোর্ডে মোট ২৫টি ঘর থাকে। দুই খেলোয়াড়ের ১২টি করে দানা থাকে এবং মাঝখানের ঘরটি খালি থাকে।';
    }
  }

  static String get rule2Title {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۲. مہرے کی چال';
      case AppLanguage.english:
        return '2. Moving a Piece';
      case AppLanguage.hindi:
        return '2. गोटी की चाल';
      case AppLanguage.punjabi:
        return '۲. گوٹی دی چال';
      case AppLanguage.arabic:
        return '٢. حركة القطعة';
      case AppLanguage.bengali:
        return '২. দানার চাল';
    }
  }

  static String get rule2Desc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہر باری میں ایک مہرہ جڑی ہوئی لائن کے ساتھ والے خالی پوائنٹ پر منتقل کیا جا سکتا ہے۔';
      case AppLanguage.english:
        return 'A piece moves to an adjacent connected empty point along the line.';
      case AppLanguage.hindi:
        return 'गोटी रेखा के साथ जुड़े हुए खाली बिंदु पर एक कदम चल सकती है।';
      case AppLanguage.punjabi:
        return 'ہر واری وچ اک گوٹی نال والے خالی تھاں تے ٹوری جا سکدی اے۔';
      case AppLanguage.arabic:
        return 'تتحرك القطعة إلى نقطة فارغة متصلة على طول الخطوط.';
      case AppLanguage.bengali:
        return 'প্রতি চালে একটি দানা সংযুক্ত খালি ঘরে স্থানান্তর করা যায়।';
    }
  }

  static String get rule3Title {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۳. مہرہ اڑانا اور +10 پوائنٹس';
      case AppLanguage.english:
        return '3. Capturing Pieces & +10 Pts';
      case AppLanguage.hindi:
        return '3. गोटी मारना और +10 अंक';
      case AppLanguage.punjabi:
        return '۳. گوٹی اڑانا تے +۱۰ پوائنٹس';
      case AppLanguage.arabic:
        return '٣. أكل القطع و +10 نقاط';
      case AppLanguage.bengali:
        return '৩. দানা কাটা এবং +১০ পয়েন্ট';
    }
  }

  static String get rule3Desc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مخالف کے مہرے کے اوپر سے چھلانگ لگا کر اسے اڑایا جاتا ہے جس پر فوری +10 پوائنٹس ملتے ہیں۔';
      case AppLanguage.english:
        return 'Jump over an adjacent opponent piece into an empty point behind it to capture it and earn +10 points.';
      case AppLanguage.hindi:
        return 'विरोधी की गोटी के ऊपर से कूदकर उसे मारें और तुरंत +10 अंक अर्जित करें।';
      case AppLanguage.punjabi:
        return 'دوجی گوٹی دے اتوں چھال مار کے اوہنوں اڑاؤ تے ۱۰ پوائنٹس لوو۔';
      case AppLanguage.arabic:
        return 'اقفز فوق قطعة الخصم إلى نقطة فارغة خلفها لأكلها وكسب +10 نقاط.';
      case AppLanguage.bengali:
        return 'প্রতিপক্ষের দানার ওপর দিয়ে লাফিয়ে খালি ঘরে গিয়ে দানাটি কাটুন ও +১০ পয়েন্ট পান।';
    }
  }

  static String get rule4Title {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۴. باری کا 10 سیکنڈ ٹائمر';
      case AppLanguage.english:
        return '4. 10s Turn Timer & Strikes';
      case AppLanguage.hindi:
        return '4. 10 सेकंड टाइमर और 5 चेतावनियाँ';
      case AppLanguage.punjabi:
        return '۴. ۱۰ سیکنڈ ٹائمر تے ۵ وارننگز';
      case AppLanguage.arabic:
        return '٤. مؤقت 10 ثوانٍ و5 إنذارات';
      case AppLanguage.bengali:
        return '৪. ১০ সেকেন্ডের টাইমার ও ৫টি সতর্কবার্তা';
    }
  }

  static String get rule4Desc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہر کھلاڑی کو چال چلنے کے لیے 10 سیکنڈ ملتے ہیں۔ اگر کوئی کھلاڑی 5 بار وقت ختم کر دے تو وہ ہار جائے گا۔';
      case AppLanguage.english:
        return 'Each player has 10 seconds to make a move. Timing out 5 times results in a defeat.';
      case AppLanguage.hindi:
        return 'प्रत्येक खिलाड़ी को 10 सेकंड मिलते हैं। 5 बार समय समाप्त होने पर हार हो जाती है।';
      case AppLanguage.punjabi:
        return 'ہر کھڈاری نوں ۱۰ سیکنڈ ملدے نیں۔ ۵ واری ویلا مکن تے دوجا کھڈاری جت جاوے گا۔';
      case AppLanguage.arabic:
        return 'لديك 10 ثوانٍ لكل حركة. نفاد الوقت 5 مرات يؤدي إلى الهزيمة.';
      case AppLanguage.bengali:
        return 'প্রতি চালে ১০ সেকেন্ড সময় থাকে। ৫ বার সময় শেষ হলে অপর খেলোয়াড় জিতে যাবে।';
    }
  }

  static String get rule5Title {
    switch (_lang) {
      case AppLanguage.urdu:
        return '۵. چال واپسی پر -10 پوائنٹس کٹوتی';
      case AppLanguage.english:
        return '5. Undo Cost & Winning';
      case AppLanguage.hindi:
        return '5. चाल वापसी पर -10 अंक और जीत';
      case AppLanguage.punjabi:
        return '۵. چال واپسی تے -۱۰ پوائنٹس تے جت';
      case AppLanguage.arabic:
        return '٥. تكلفة التراجع والفوز';
      case AppLanguage.bengali:
        return '৫. চাল ফেরাতে -১০ পয়েন্ট ও বিজয়';
    }
  }

  static String get rule5Desc {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہر بار چال واپس لینے پر 10 پوائنٹس کٹیں گے۔ جو کھلاڑی مخالف کے تمام 12 مہرے اڑا دے، وہ فاتح قرار پاتا ہے۔';
      case AppLanguage.english:
        return 'Undoing a move costs 10 Points. The player who eliminates all 12 opponent pieces wins (+50 Pts).';
      case AppLanguage.hindi:
        return 'चाल वापस लेने पर 10 अंक कटते हैं। विरोधी की सभी 12 गोटियाँ खत्म करने वाला जीतता है (+50 अंक)।';
      case AppLanguage.punjabi:
        return 'چال واپس لین تے ۱۰ پوائنٹس کٹدے نیں۔ سارے ۱۲ مہرے اڑان والا فاتح بندا اے۔';
      case AppLanguage.arabic:
        return 'التراجع عن حركة يكلف 10 نقاط. اللاعب الذي يقضي على جميع قطع الخصم الـ 12 يفوز (+50 نقطة).';
      case AppLanguage.bengali:
        return 'চাল ফেরাতে ১০ পয়েন্ট কাটে। বিপক্ষের ১২টি দানা শেষ করা খেলোয়াড় বিজয়ী (+৫০ পয়েন্ট)।';
    }
  }

  // Reference UI Screen Strings
  static String get guestLogin {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مہمان لاگ ان (Guest Login)';
      case AppLanguage.english:
        return 'GUEST LOGIN';
      case AppLanguage.hindi:
        return 'गेस्ट लॉगिन (Guest Login)';
      case AppLanguage.punjabi:
        return 'مہمان لاگ ان';
      case AppLanguage.arabic:
        return 'دخول كضيف';
      case AppLanguage.bengali:
        return 'গেস্ট লগইন';
    }
  }

  static String get strategyAndSkill {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'حکمت عملی اور مہارت';
      case AppLanguage.english:
        return 'Strategy & Skill';
      case AppLanguage.hindi:
        return 'रणनीति और कौशल';
      case AppLanguage.punjabi:
        return 'حکمت عملی تے مہارت';
      case AppLanguage.arabic:
        return 'استراتيجية ومهارة';
      case AppLanguage.bengali:
        return 'কৌশল ও দক্ষতা';
    }
  }

  static String get mainLobby {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'مین لابی (Main Lobby)';
      case AppLanguage.english:
        return 'Main Lobby';
      case AppLanguage.hindi:
        return 'मुख्य लॉबी (Main Lobby)';
      case AppLanguage.punjabi:
        return 'مین لابی';
      case AppLanguage.arabic:
        return 'الصالة الرئيسية';
      case AppLanguage.bengali:
        return 'প্রধান লবি';
    }
  }

  static String get level {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'لیول';
      case AppLanguage.english:
        return 'Level';
      case AppLanguage.hindi:
        return 'स्तर';
      case AppLanguage.punjabi:
        return 'لیول';
      case AppLanguage.arabic:
        return 'مستوى';
      case AppLanguage.bengali:
        return 'লেভেল';
    }
  }

  static String get coins {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'سکے';
      case AppLanguage.english:
        return 'Coins';
      case AppLanguage.hindi:
        return 'सिक्के';
      case AppLanguage.punjabi:
        return 'سکے';
      case AppLanguage.arabic:
        return 'عملات';
      case AppLanguage.bengali:
        return 'কয়েন';
    }
  }

  static String get gems {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'ہیرے';
      case AppLanguage.english:
        return 'Gems';
      case AppLanguage.hindi:
        return 'रत्न';
      case AppLanguage.punjabi:
        return 'ہیرے';
      case AppLanguage.arabic:
        return 'جواهر';
      case AppLanguage.bengali:
        return 'রত্ন';
    }
  }

  static String get online1v1 {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Online 1v1';
      case AppLanguage.english:
        return 'Online 1v1';
      case AppLanguage.hindi:
        return 'Online 1v1';
      case AppLanguage.punjabi:
        return 'Online 1v1';
      case AppLanguage.arabic:
        return 'أونلاين 1v1';
      case AppLanguage.bengali:
        return 'Online 1v1';
    }
  }

  static String get vsAiMode {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Vs AI';
      case AppLanguage.english:
        return 'Vs AI';
      case AppLanguage.hindi:
        return 'Vs AI';
      case AppLanguage.punjabi:
        return 'Vs AI';
      case AppLanguage.arabic:
        return 'ضد AI';
      case AppLanguage.bengali:
        return 'Vs AI';
    }
  }

  static String get withDifficulty {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'w/ difficulty';
      case AppLanguage.english:
        return 'w/ difficulty';
      case AppLanguage.hindi:
        return 'w/ difficulty';
      case AppLanguage.punjabi:
        return 'w/ difficulty';
      case AppLanguage.arabic:
        return 'مع تحديد الصعوبة';
      case AppLanguage.bengali:
        return 'w/ difficulty';
    }
  }

  static String get passAndPlayMode {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Pass & Play';
      case AppLanguage.english:
        return 'Pass & Play';
      case AppLanguage.hindi:
        return 'Pass & Play';
      case AppLanguage.punjabi:
        return 'Pass & Play';
      case AppLanguage.arabic:
        return 'مرر والعب';
      case AppLanguage.bengali:
        return 'Pass & Play';
    }
  }

  static String get tournaments {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Tournaments';
      case AppLanguage.english:
        return 'Tournaments';
      case AppLanguage.hindi:
        return 'Tournaments';
      case AppLanguage.punjabi:
        return 'Tournaments';
      case AppLanguage.arabic:
        return 'البطولات';
      case AppLanguage.bengali:
        return 'Tournaments';
    }
  }

  static String get matchmaking {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Matchmaking';
      case AppLanguage.english:
        return 'Matchmaking';
      case AppLanguage.hindi:
        return 'Matchmaking';
      case AppLanguage.punjabi:
        return 'Matchmaking';
      case AppLanguage.arabic:
        return 'البحث عن مباراة';
      case AppLanguage.bengali:
        return 'Matchmaking';
    }
  }

  static String get searching {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Searching...';
      case AppLanguage.english:
        return 'Searching...';
      case AppLanguage.hindi:
        return 'Searching...';
      case AppLanguage.punjabi:
        return 'Searching...';
      case AppLanguage.arabic:
        return 'جاري البحث...';
      case AppLanguage.bengali:
        return 'Searching...';
    }
  }

  static String get wagerCoins {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Wager: 500 Coins';
      case AppLanguage.english:
        return 'Wager: 500 Coins';
      case AppLanguage.hindi:
        return 'Wager: 500 Coins';
      case AppLanguage.punjabi:
        return 'Wager: 500 Coins';
      case AppLanguage.arabic:
        return 'الرهان: 500 عملة';
      case AppLanguage.bengali:
        return 'Wager: 500 Coins';
    }
  }

  static String get paused {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'PAUSED';
      case AppLanguage.english:
        return 'PAUSED';
      case AppLanguage.hindi:
        return 'PAUSED';
      case AppLanguage.punjabi:
        return 'PAUSED';
      case AppLanguage.arabic:
        return 'مؤقت';
      case AppLanguage.bengali:
        return 'PAUSED';
    }
  }

  static String get validMove {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Valid Move';
      case AppLanguage.english:
        return 'Valid Move';
      case AppLanguage.hindi:
        return 'Valid Move';
      case AppLanguage.punjabi:
        return 'Valid Move';
      case AppLanguage.arabic:
        return 'حركة صحيحة';
      case AppLanguage.bengali:
        return 'Valid Move';
    }
  }

  static String get captureRule {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Capture Rule';
      case AppLanguage.english:
        return 'Capture Rule';
      case AppLanguage.hindi:
        return 'Capture Rule';
      case AppLanguage.punjabi:
        return 'Capture Rule';
      case AppLanguage.arabic:
        return 'قاعدة الأكل';
      case AppLanguage.bengali:
        return 'Capture Rule';
    }
  }

  static String get audio {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Audio';
      case AppLanguage.english:
        return 'Audio';
      case AppLanguage.hindi:
        return 'Audio';
      case AppLanguage.punjabi:
        return 'Audio';
      case AppLanguage.arabic:
        return 'الصوت';
      case AppLanguage.bengali:
        return 'Audio';
    }
  }

  static String get quit {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'QUIT';
      case AppLanguage.english:
        return 'QUIT';
      case AppLanguage.hindi:
        return 'QUIT';
      case AppLanguage.punjabi:
        return 'QUIT';
      case AppLanguage.arabic:
        return 'خروج';
      case AppLanguage.bengali:
        return 'QUIT';
    }
  }

  static String get celebration {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Celebration!';
      case AppLanguage.english:
        return 'Celebration!';
      case AppLanguage.hindi:
        return 'Celebration!';
      case AppLanguage.punjabi:
        return 'Celebration!';
      case AppLanguage.arabic:
        return 'احتفال!';
      case AppLanguage.bengali:
        return 'Celebration!';
    }
  }

  static String get victory {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'VICTORY!';
      case AppLanguage.english:
        return 'VICTORY!';
      case AppLanguage.hindi:
        return 'VICTORY!';
      case AppLanguage.punjabi:
        return 'VICTORY!';
      case AppLanguage.arabic:
        return 'انتصار!';
      case AppLanguage.bengali:
        return 'VICTORY!';
    }
  }

  static String get youWonExclamation {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'You Won!';
      case AppLanguage.english:
        return 'You Won!';
      case AppLanguage.hindi:
        return 'You Won!';
      case AppLanguage.punjabi:
        return 'You Won!';
      case AppLanguage.arabic:
        return 'لقد فزت!';
      case AppLanguage.bengali:
        return 'You Won!';
    }
  }

  static String get capturedBeadsLabel {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Captured Beads';
      case AppLanguage.english:
        return 'Captured Beads';
      case AppLanguage.hindi:
        return 'Captured Beads';
      case AppLanguage.punjabi:
        return 'Captured Beads';
      case AppLanguage.arabic:
        return 'القطع المأكولة';
      case AppLanguage.bengali:
        return 'Captured Beads';
    }
  }

  static String get coinsWonLabel {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Coins Won';
      case AppLanguage.english:
        return 'Coins Won';
      case AppLanguage.hindi:
        return 'Coins Won';
      case AppLanguage.punjabi:
        return 'Coins Won';
      case AppLanguage.arabic:
        return 'العملات المكتسبة';
      case AppLanguage.bengali:
        return 'Coins Won';
    }
  }

  static String get shop {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'SHOP';
      case AppLanguage.english:
        return 'SHOP';
      case AppLanguage.hindi:
        return 'SHOP';
      case AppLanguage.punjabi:
        return 'SHOP';
      case AppLanguage.arabic:
        return 'المتجر';
      case AppLanguage.bengali:
        return 'SHOP';
    }
  }

  static String get beadsCategory {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'BEADS';
      case AppLanguage.english:
        return 'BEADS';
      case AppLanguage.hindi:
        return 'BEADS';
      case AppLanguage.punjabi:
        return 'BEADS';
      case AppLanguage.arabic:
        return 'القطع';
      case AppLanguage.bengali:
        return 'BEADS';
    }
  }

  static String get boardsCategory {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'BOARDS';
      case AppLanguage.english:
        return 'BOARDS';
      case AppLanguage.hindi:
        return 'BOARDS';
      case AppLanguage.punjabi:
        return 'BOARDS';
      case AppLanguage.arabic:
        return 'الرقعات';
      case AppLanguage.bengali:
        return 'BOARDS';
    }
  }

  static String get avatarsCategory {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'AVATARS';
      case AppLanguage.english:
        return 'AVATARS';
      case AppLanguage.hindi:
        return 'AVATARS';
      case AppLanguage.punjabi:
        return 'AVATARS';
      case AppLanguage.arabic:
        return 'الصور الرمزية';
      case AppLanguage.bengali:
        return 'AVATARS';
    }
  }

  static String get globalRanking {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'GLOBAL RANKING';
      case AppLanguage.english:
        return 'GLOBAL RANKING';
      case AppLanguage.hindi:
        return 'GLOBAL RANKING';
      case AppLanguage.punjabi:
        return 'GLOBAL RANKING';
      case AppLanguage.arabic:
        return 'الترتيب العالمي';
      case AppLanguage.bengali:
        return 'GLOBAL RANKING';
    }
  }

  static String get winRate {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'Win Rate';
      case AppLanguage.english:
        return 'Win Rate';
      case AppLanguage.hindi:
        return 'Win Rate';
      case AppLanguage.punjabi:
        return 'Win Rate';
      case AppLanguage.arabic:
        return 'نسبة الفوز';
      case AppLanguage.bengali:
        return 'Win Rate';
    }
  }

  static String get equipped {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'EQUIPPED';
      case AppLanguage.english:
        return 'EQUIPPED';
      case AppLanguage.hindi:
        return 'EQUIPPED';
      case AppLanguage.punjabi:
        return 'EQUIPPED';
      case AppLanguage.arabic:
        return 'مفعل';
      case AppLanguage.bengali:
        return 'EQUIPPED';
    }
  }

  static String get equip {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'EQUIP';
      case AppLanguage.english:
        return 'EQUIP';
      case AppLanguage.hindi:
        return 'EQUIP';
      case AppLanguage.punjabi:
        return 'EQUIP';
      case AppLanguage.arabic:
        return 'تفعيل';
      case AppLanguage.bengali:
        return 'EQUIP';
    }
  }

  static String get save {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'محفوظ کریں';
      case AppLanguage.english:
        return 'Save';
      case AppLanguage.hindi:
        return 'सहेजें';
      case AppLanguage.punjabi:
        return 'محفوظ کرو';
      case AppLanguage.arabic:
        return 'حفظ';
      case AppLanguage.bengali:
        return 'সংরক্ষণ করুন';
    }
  }

  static String get editProfile {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پروفائل تبدیل کریں';
      case AppLanguage.english:
        return 'Edit Profile';
      case AppLanguage.hindi:
        return 'प्रोफ़ाइल संपादित करें';
      case AppLanguage.punjabi:
        return 'پروفائل بدلو';
      case AppLanguage.arabic:
        return 'تعديل الملف الشخصي';
      case AppLanguage.bengali:
        return 'প্রোফাইল সম্পাদনা করুন';
    }
  }

  static String get chooseAvatar {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'اواتار منتخب کریں';
      case AppLanguage.english:
        return 'Choose Avatar';
      case AppLanguage.hindi:
        return 'अवतार चुनें';
      case AppLanguage.punjabi:
        return 'اواتار چنو';
      case AppLanguage.arabic:
        return 'اختر الصورة الرمزية';
      case AppLanguage.bengali:
        return 'অবতার নির্বাচন করুন';
    }
  }

  static String get privateRoom {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پرائیویٹ روم (Private Room)';
      case AppLanguage.english:
        return 'Private Room';
      case AppLanguage.hindi:
        return 'प्राइवेट रूम';
      case AppLanguage.punjabi:
        return 'پرائیویٹ روم';
      case AppLanguage.arabic:
        return 'غرفة خاصة';
      case AppLanguage.bengali:
        return 'ব্যক্তিগত রুম';
    }
  }

  static String get share {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'شیئر کریں';
      case AppLanguage.english:
        return 'Share';
      case AppLanguage.hindi:
        return 'शेयर करें';
      case AppLanguage.punjabi:
        return 'شیئر کرو';
      case AppLanguage.arabic:
        return 'مشاركة';
      case AppLanguage.bengali:
        return 'শেয়ার করুন';
    }
  }

  static String get paste {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'پیسٹ کریں';
      case AppLanguage.english:
        return 'Paste';
      case AppLanguage.hindi:
        return 'पेस्ट करें';
      case AppLanguage.punjabi:
        return 'پیسٹ کرو';
      case AppLanguage.arabic:
        return 'لصق';
      case AppLanguage.bengali:
        return 'পেস্ট করুন';
    }
  }

  static String get friendJoined {
    switch (_lang) {
      case AppLanguage.urdu:
        return 'دوست روم میں شامل ہو گیا ہے! 🎉';
      case AppLanguage.english:
        return 'Friend joined the room! 🎉';
      case AppLanguage.hindi:
        return 'दोस्त रूम में शामिल हो गया! 🎉';
      case AppLanguage.punjabi:
        return 'یار روم چ آ گیا اے! 🎉';
      case AppLanguage.arabic:
        return 'انضم الصديق إلى الغرفة! 🎉';
      case AppLanguage.bengali:
        return 'বন্ধু রুমে যোগ দিয়েছে! 🎉';
    }
  }
}
