import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PointsService extends ChangeNotifier {
  static final PointsService _instance = PointsService._internal();
  factory PointsService() => _instance;
  PointsService._internal();

  static const String _keyPoints = 'twelve_tani_user_points';
  static const String _keyLastDailyBonus = 'twelve_tani_last_daily_bonus';
  static const String _keyLastSpin = 'twelve_tani_last_spin_date';

  static const int initialBonusPoints = 100;
  static const int dailyBonusAmount = 100;
  static const int capturePointsReward = 10;
  static const int undoPointsCost = 10;
  static const int victoryPointsReward = 50;

  // 10-hour cooldown between Lucky Wheel spins
  static const Duration spinCooldown = Duration(hours: 10);

  int _points = initialBonusPoints;
  DateTime? _lastDailyBonusDate;
  DateTime? _lastSpinDate;
  bool _isInitialized = false;

  int get points => _points;
  bool get isInitialized => _isInitialized;
  DateTime? get lastSpinDate => _lastSpinDate;

  Future<void> init() async {
    if (_isInitialized) return;
    final prefs = await SharedPreferences.getInstance();
    _points = prefs.getInt(_keyPoints) ?? initialBonusPoints;

    final lastBonusStr = prefs.getString(_keyLastDailyBonus);
    if (lastBonusStr != null) {
      _lastDailyBonusDate = DateTime.tryParse(lastBonusStr);
    }

    final lastSpinStr = prefs.getString(_keyLastSpin);
    if (lastSpinStr != null) {
      _lastSpinDate = DateTime.tryParse(lastSpinStr);
    }

    _isInitialized = true;
    notifyListeners();
  }

  /// Adds [amount] points to the balance and persists
  Future<void> addPoints(int amount) async {
    if (amount <= 0) return;
    _points += amount;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyPoints, _points);
  }

  /// Attempts to deduct [amount] points. Returns true if successful.
  Future<bool> deductPoints(int amount) async {
    if (amount <= 0) return true;
    if (_points < amount) return false;

    _points -= amount;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyPoints, _points);
    return true;
  }

  /// Checks if the player can afford [amount]
  bool canAfford(int amount) => _points >= amount;

  /// Checks if daily bonus (100 pts) can be claimed (once per calendar day)
  bool isDailyBonusAvailable() {
    if (_lastDailyBonusDate == null) return true;
    final now = DateTime.now();
    final last = _lastDailyBonusDate!;
    return now.year != last.year || now.month != last.month || now.day != last.day;
  }

  /// Claims daily bonus of 100 points
  Future<int> claimDailyBonus() async {
    if (!isDailyBonusAvailable()) return 0;

    final now = DateTime.now();
    _lastDailyBonusDate = now;
    await addPoints(dailyBonusAmount);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyLastDailyBonus, now.toIso8601String());
    return dailyBonusAmount;
  }

  /// Checks if lucky spin is available (10-hour cooldown)
  bool isSpinAvailable() {
    if (_lastSpinDate == null) return true;
    final elapsed = DateTime.now().difference(_lastSpinDate!);
    return elapsed >= spinCooldown;
  }

  /// Returns remaining Duration until the next spin is unlocked
  Duration timeUntilNextSpin() {
    if (isSpinAvailable()) return Duration.zero;
    final elapsed = DateTime.now().difference(_lastSpinDate!);
    final remaining = spinCooldown - elapsed;
    return remaining.isNegative ? Duration.zero : remaining;
  }

  /// Records spin execution with 10-hour cooldown
  Future<void> recordSpin() async {
    final now = DateTime.now();
    _lastSpinDate = now;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyLastSpin, now.toIso8601String());
    notifyListeners();
  }

  /// Resets points for testing/debugging
  Future<void> resetPoints([int initial = initialBonusPoints]) async {
    _points = initial;
    _lastDailyBonusDate = null;
    _lastSpinDate = null;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyPoints, _points);
    await prefs.remove(_keyLastDailyBonus);
    await prefs.remove(_keyLastSpin);
  }
}
