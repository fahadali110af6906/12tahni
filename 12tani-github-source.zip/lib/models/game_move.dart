import 'board_point.dart';
import 'player_type.dart';

class GameMove {
  final BoardPoint from;
  final BoardPoint to;
  final BoardPoint? capturedPoint;
  final bool isJump;
  final PlayerType? player;

  const GameMove({
    required this.from,
    required this.to,
    this.capturedPoint,
    this.isJump = false,
    this.player,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GameMove &&
          runtimeType == other.runtimeType &&
          from == other.from &&
          to == other.to &&
          capturedPoint == other.capturedPoint &&
          isJump == other.isJump &&
          player == other.player;

  @override
  int get hashCode =>
      from.hashCode ^ to.hashCode ^ capturedPoint.hashCode ^ isJump.hashCode ^ player.hashCode;

  GameMove copyWith({
    BoardPoint? from,
    BoardPoint? to,
    BoardPoint? capturedPoint,
    bool? isJump,
    PlayerType? player,
  }) {
    return GameMove(
      from: from ?? this.from,
      to: to ?? this.to,
      capturedPoint: capturedPoint ?? this.capturedPoint,
      isJump: isJump ?? this.isJump,
      player: player ?? this.player,
    );
  }

  @override
  String toString() =>
      'GameMove(from: $from, to: $to, jump: $isJump, captured: $capturedPoint, player: $player)';
}
