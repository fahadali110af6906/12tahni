enum ShopCategory { beads, boards, avatars }

class ShopItem {
  final String id;
  final String title;
  final ShopCategory category;
  final int price;
  final bool isGem;
  final String assetOrPreview;
  final String description;

  const ShopItem({
    required this.id,
    required this.title,
    required this.category,
    required this.price,
    this.isGem = false,
    required this.assetOrPreview,
    this.description = '',
  });

  static const List<ShopItem> allItems = [
    // Bead Skins
    ShopItem(
      id: 'gemstone',
      title: 'Gemstone',
      category: ShopCategory.beads,
      price: 70,
      isGem: true,
      assetOrPreview: '💎',
      description: 'Radiant glowing emerald gemstone beads',
    ),
    ShopItem(
      id: 'metallic',
      title: 'Metallic',
      category: ShopCategory.beads,
      price: 20,
      isGem: true,
      assetOrPreview: '🪙',
      description: 'Polished silver chrome specular beads',
    ),
    ShopItem(
      id: 'classic_wood',
      title: 'Classic Wooden',
      category: ShopCategory.beads,
      price: 120,
      isGem: false,
      assetOrPreview: '🪵',
      description: 'Carved natural teakwood polished spheres',
    ),
    ShopItem(
      id: 'marble',
      title: 'Royal Marble',
      category: ShopCategory.beads,
      price: 300,
      isGem: false,
      assetOrPreview: '⚪',
      description: 'Smooth white Venetian marble beads',
    ),

    // Board Themes
    ShopItem(
      id: 'royal_ivory',
      title: 'Royal Ivory',
      category: ShopCategory.boards,
      price: 1650,
      isGem: true,
      assetOrPreview: '🏛️',
      description: 'Luxury obsidian & royal ivory board',
    ),
    ShopItem(
      id: 'teak_wood',
      title: 'Teak Wood',
      category: ShopCategory.boards,
      price: 1450,
      isGem: false,
      assetOrPreview: '🌲',
      description: 'Authentic warm teak grain table',
    ),
    ShopItem(
      id: 'emerald_entry',
      title: 'Emerald Entry',
      category: ShopCategory.boards,
      price: 1420,
      isGem: false,
      assetOrPreview: '🟢',
      description: 'Deep forest green wood with gold grooves',
    ),
    ShopItem(
      id: 'classic_dark',
      title: 'Dark Walnut',
      category: ShopCategory.boards,
      price: 1200,
      isGem: false,
      assetOrPreview: '🪵',
      description: 'Traditional dark walnut board',
    ),
  ];
}
