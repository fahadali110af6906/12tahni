enum PlayerType {
  player1, // Red / Ruby (Top / AI in Single Player)
  player2; // Green / Jade (Bottom / User in Single Player)

  PlayerType get opponent =>
      this == PlayerType.player1 ? PlayerType.player2 : PlayerType.player1;
}
