import 'board_point.dart';
import 'difficulty.dart';
import 'game_mode.dart';
import 'game_move.dart';
import 'player_type.dart';

class GameState {
  final List<PlayerType?> board;
  final PlayerType currentTurn;
  final GameMode mode;
  final Difficulty difficulty;
  final BoardPoint? selectedPoint;
  final List<GameMove> validMovesForSelected;
  final BoardPoint? chainJumpPoint;
  final PlayerType? winner;
  final bool isDraw;
  final bool isGameOver;
  final bool isPaused;
  final bool isAiThinking;
  final int player1Pieces;
  final int player2Pieces;
  final int totalMoves;
  final List<GameMove> moveHistory;
  final GameMove? lastMove;
  final int turnTimeRemaining; // 10s countdown
  final int player1Timeouts;  // Number of times timer ran out (max 5)
  final int player2Timeouts;  // Number of times timer ran out (max 5)
  final bool isTimeoutVictory; // Game ended due to 5 timeouts

  const GameState({
    required this.board,
    required this.currentTurn,
    required this.mode,
    required this.difficulty,
    this.selectedPoint,
    this.validMovesForSelected = const [],
    this.chainJumpPoint,
    this.winner,
    this.isDraw = false,
    this.isGameOver = false,
    this.isPaused = false,
    this.isAiThinking = false,
    required this.player1Pieces,
    required this.player2Pieces,
    this.totalMoves = 0,
    this.moveHistory = const [],
    this.lastMove,
    this.turnTimeRemaining = 10,
    this.player1Timeouts = 0,
    this.player2Timeouts = 0,
    this.isTimeoutVictory = false,
  });

  GameState copyWith({
    List<PlayerType?>? board,
    PlayerType? currentTurn,
    GameMode? mode,
    Difficulty? difficulty,
    BoardPoint? selectedPoint,
    bool clearSelectedPoint = false,
    List<GameMove>? validMovesForSelected,
    BoardPoint? chainJumpPoint,
    bool clearChainJumpPoint = false,
    PlayerType? winner,
    bool clearWinner = false,
    bool? isDraw,
    bool? isGameOver,
    bool? isPaused,
    bool? isAiThinking,
    int? player1Pieces,
    int? player2Pieces,
    int? totalMoves,
    List<GameMove>? moveHistory,
    GameMove? lastMove,
    bool clearLastMove = false,
    int? turnTimeRemaining,
    int? player1Timeouts,
    int? player2Timeouts,
    bool? isTimeoutVictory,
  }) {
    return GameState(
      board: board ?? List.from(this.board),
      currentTurn: currentTurn ?? this.currentTurn,
      mode: mode ?? this.mode,
      difficulty: difficulty ?? this.difficulty,
      selectedPoint: clearSelectedPoint ? null : (selectedPoint ?? this.selectedPoint),
      validMovesForSelected: validMovesForSelected ?? this.validMovesForSelected,
      chainJumpPoint: clearChainJumpPoint ? null : (chainJumpPoint ?? this.chainJumpPoint),
      winner: clearWinner ? null : (winner ?? this.winner),
      isDraw: isDraw ?? this.isDraw,
      isGameOver: isGameOver ?? this.isGameOver,
      isPaused: isPaused ?? this.isPaused,
      isAiThinking: isAiThinking ?? this.isAiThinking,
      player1Pieces: player1Pieces ?? this.player1Pieces,
      player2Pieces: player2Pieces ?? this.player2Pieces,
      totalMoves: totalMoves ?? this.totalMoves,
      moveHistory: moveHistory ?? List.from(this.moveHistory),
      lastMove: clearLastMove ? null : (lastMove ?? this.lastMove),
      turnTimeRemaining: turnTimeRemaining ?? this.turnTimeRemaining,
      player1Timeouts: player1Timeouts ?? this.player1Timeouts,
      player2Timeouts: player2Timeouts ?? this.player2Timeouts,
      isTimeoutVictory: isTimeoutVictory ?? this.isTimeoutVictory,
    );
  }
}
