import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserProfile extends ChangeNotifier {
  static final UserProfile _instance = UserProfile._internal();
  factory UserProfile() => _instance;
  UserProfile._internal();

  String _name = 'Sarah';
  String _avatar = '👩';
  int _coins = 1250;
  int _gems = 45;
  int _xp = 350;
  int _level = 15;
  int _totalGames = 450;
  int _wins = 290;

  String _equippedBead = 'gemstone';
  String _equippedBoard = 'teak_wood';
  final Set<String> _unlockedItems = {
    'classic_wood',
    'gemstone',
    'teak_wood',
    'royal_ivory',
  };

  String get name => _name;
  String get avatar => _avatar;
  int get coins => _coins;
  int get gems => _gems;
  int get xp => _xp;
  int get level => _level;
  int get totalGames => _totalGames;
  int get wins => _wins;
  int get winRate => _totalGames > 0 ? ((_wins / _totalGames) * 100).round() : 64;

  String get equippedBead => _equippedBead;
  String get equippedBoard => _equippedBoard;
  Set<String> get unlockedItems => _unlockedItems;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _name = prefs.getString('user_profile_name') ?? 'Sarah';
    _avatar = prefs.getString('user_profile_avatar') ?? '👩';
    _coins = prefs.getInt('user_profile_coins') ?? 1250;
    _gems = prefs.getInt('user_profile_gems') ?? 45;
    _xp = prefs.getInt('user_profile_xp') ?? 350;
    _level = prefs.getInt('user_profile_level') ?? 15;
    _totalGames = prefs.getInt('user_profile_total_games') ?? 450;
    _wins = prefs.getInt('user_profile_wins') ?? 290;
    _equippedBead = prefs.getString('user_profile_equipped_bead') ?? 'gemstone';
    _equippedBoard = prefs.getString('user_profile_equipped_board') ?? 'teak_wood';

    final unlockedList = prefs.getStringList('user_profile_unlocked');
    if (unlockedList != null) {
      _unlockedItems.addAll(unlockedList);
    }
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_profile_name', _name);
    await prefs.setString('user_profile_avatar', _avatar);
    await prefs.setInt('user_profile_coins', _coins);
    await prefs.setInt('user_profile_gems', _gems);
    await prefs.setInt('user_profile_xp', _xp);
    await prefs.setInt('user_profile_level', _level);
    await prefs.setInt('user_profile_total_games', _totalGames);
    await prefs.setInt('user_profile_wins', _wins);
    await prefs.setString('user_profile_equipped_bead', _equippedBead);
    await prefs.setString('user_profile_equipped_board', _equippedBoard);
    await prefs.setStringList('user_profile_unlocked', _unlockedItems.toList());
  }

  void setName(String newName) {
    final trimmed = newName.trim();
    if (trimmed.isNotEmpty) {
      _name = trimmed;
      _save();
      notifyListeners();
    }
  }

  void setAvatar(String newAvatar) {
    if (newAvatar.isNotEmpty) {
      _avatar = newAvatar;
      _save();
      notifyListeners();
    }
  }

  void addCoins(int amount) {
    _coins += amount;
    _save();
    notifyListeners();
  }

  bool deductCoins(int amount) {
    if (_coins >= amount) {
      _coins -= amount;
      _save();
      notifyListeners();
      return true;
    }
    return false;
  }

  void addGems(int amount) {
    _gems += amount;
    _save();
    notifyListeners();
  }

  bool deductGems(int amount) {
    if (_gems >= amount) {
      _gems -= amount;
      _save();
      notifyListeners();
      return true;
    }
    return false;
  }

  void recordMatchWin({int coinsWon = 200, int xpGained = 50}) {
    _totalGames++;
    _wins++;
    _coins += coinsWon;
    _xp += xpGained;
    if (_xp >= 500) {
      _level++;
      _xp -= 500;
    }
    _save();
    notifyListeners();
  }

  void recordMatchLoss({int xpGained = 15}) {
    _totalGames++;
    _xp += xpGained;
    if (_xp >= 500) {
      _level++;
      _xp -= 500;
    }
    _save();
    notifyListeners();
  }

  bool isUnlocked(String id) => _unlockedItems.contains(id);

  bool unlockItem(String id, {required int cost, bool isGem = false}) {
    return buyItem(id: id, cost: cost, isGem: isGem);
  }

  bool buyItem({required String id, required int cost, bool isGem = false}) {
    if (isUnlocked(id)) return true;
    if (isGem) {
      if (deductGems(cost)) {
        _unlockedItems.add(id);
        _save();
        notifyListeners();
        return true;
      }
    } else {
      if (deductCoins(cost)) {
        _unlockedItems.add(id);
        _save();
        notifyListeners();
        return true;
      }
    }
    return false;
  }

  void equipBead(String id) {
    _equippedBead = id;
    _save();
    notifyListeners();
  }

  void equipBoard(String id) {
    _equippedBoard = id;
    _save();
    notifyListeners();
  }
}
