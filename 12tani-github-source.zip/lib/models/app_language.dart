import 'package:flutter/material.dart';

enum AppLanguage {
  urdu(
    code: 'ur',
    nativeName: 'اردو',
    englishName: 'Urdu',
    flag: '🇵🇰',
    isRtl: true,
  ),
  english(
    code: 'en',
    nativeName: 'English',
    englishName: 'English',
    flag: '🇬🇧',
    isRtl: false,
  ),
  hindi(
    code: 'hi',
    nativeName: 'हिन्दी',
    englishName: 'Hindi',
    flag: '🇮🇳',
    isRtl: false,
  ),
  punjabi(
    code: 'pa',
    nativeName: 'پنجابی',
    englishName: 'Punjabi',
    flag: '🇵🇰',
    isRtl: true,
  ),
  arabic(
    code: 'ar',
    nativeName: 'العربية',
    englishName: 'Arabic',
    flag: '🇸🇦',
    isRtl: true,
  ),
  bengali(
    code: 'bn',
    nativeName: 'বাংলা',
    englishName: 'Bengali',
    flag: '🇧🇩',
    isRtl: false,
  );

  final String code;
  final String nativeName;
  final String englishName;
  final String flag;
  final bool isRtl;

  const AppLanguage({
    required this.code,
    required this.nativeName,
    required this.englishName,
    required this.flag,
    required this.isRtl,
  });

  TextDirection get direction => isRtl ? TextDirection.rtl : TextDirection.ltr;
}
