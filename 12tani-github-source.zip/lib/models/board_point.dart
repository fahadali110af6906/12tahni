class BoardPoint {
  final int row;
  final int col;

  const BoardPoint(this.row, this.col);

  int get index => row * 5 + col;

  factory BoardPoint.fromIndex(int index) {
    return BoardPoint(index ~/ 5, index % 5);
  }

  bool get isValid => row >= 0 && row < 5 && col >= 0 && col < 5;

  /// In standard Alquerque / 12 Guti board, diagonals exist on intersections
  /// where (row + col) % 2 == 0
  bool get hasDiagonals => (row + col) % 2 == 0;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BoardPoint &&
          runtimeType == other.runtimeType &&
          row == other.row &&
          col == other.col;

  @override
  int get hashCode => row.hashCode ^ col.hashCode;

  @override
  String toString() => '($row, $col)';
}
