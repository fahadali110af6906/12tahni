import '../core/constants/app_strings.dart';

enum Difficulty {
  easy,
  medium,
  hard;

  String get labelUrdu {
    switch (this) {
      case Difficulty.easy:
        return AppStrings.easy;
      case Difficulty.medium:
        return AppStrings.medium;
      case Difficulty.hard:
        return AppStrings.hard;
    }
  }

  String get descriptionUrdu {
    switch (this) {
      case Difficulty.easy:
        return AppStrings.easyDesc;
      case Difficulty.medium:
        return AppStrings.mediumDesc;
      case Difficulty.hard:
        return AppStrings.hardDesc;
    }
  }

  int get searchDepth {
    switch (this) {
      case Difficulty.easy:
        return 1;
      case Difficulty.medium:
        return 2;
      case Difficulty.hard:
        return 4;
    }
  }
}
