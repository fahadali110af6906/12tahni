import 'package:flutter/material.dart';
import '../core/settings/settings_service.dart';
import 'app_language.dart';

enum PieceStyle {
  crystalMarble, // شاہی کرسٹل ماربل (Royal 3D Marble)
  royalCoin,     // شاہی طلائی سکہ (Royal Medallion Coin)
  facetedGem,    // چمکدار تراشیدہ ہیرا (Faceted Gemstone)
  royalCrown,    // شاہی تاج / نشان (Imperial Crown)
  warriorShield, // جنگی ڈھال / تمغہ (Warrior Shield)
  mughalFloral;  // روایتی مغل نقش (Mughal Floral Crest)

  String get labelUrdu => labelForLanguage(AppLanguage.urdu);

  String get label => labelForLanguage(SettingsService().language);

  String labelForLanguage(AppLanguage lang) {
    switch (this) {
      case PieceStyle.crystalMarble:
        switch (lang) {
          case AppLanguage.urdu:
            return 'کرسٹل ماربل';
          case AppLanguage.english:
            return 'Crystal Marble';
          case AppLanguage.hindi:
            return 'क्रिस्टल मार्बल';
          case AppLanguage.punjabi:
            return 'کرسٹل ماربل';
          case AppLanguage.arabic:
            return 'رخام كريستالي';
          case AppLanguage.bengali:
            return 'ক্রিস্টাল মার্বেল';
        }
      case PieceStyle.royalCoin:
        switch (lang) {
          case AppLanguage.urdu:
            return 'طلائی سکہ';
          case AppLanguage.english:
            return 'Royal Coin';
          case AppLanguage.hindi:
            return 'शाही सिक्का';
          case AppLanguage.punjabi:
            return 'سونے دا سکہ';
          case AppLanguage.arabic:
            return 'عملة ملكية';
          case AppLanguage.bengali:
            return 'রাজকীয় মুদ্রা';
        }
      case PieceStyle.facetedGem:
        switch (lang) {
          case AppLanguage.urdu:
            return 'تراشیدہ ہیرا';
          case AppLanguage.english:
            return 'Faceted Gem';
          case AppLanguage.hindi:
            return 'चमकदार हीरा';
          case AppLanguage.punjabi:
            return 'تراشیا ہیرا';
          case AppLanguage.arabic:
            return 'جوهرة براقة';
          case AppLanguage.bengali:
            return 'চকচকে রত্ন';
        }
      case PieceStyle.royalCrown:
        switch (lang) {
          case AppLanguage.urdu:
            return 'شاہی تاج';
          case AppLanguage.english:
            return 'Imperial Crown';
          case AppLanguage.hindi:
            return 'शाही मुकुट';
          case AppLanguage.punjabi:
            return 'شاہی تاج';
          case AppLanguage.arabic:
            return 'التاج الإمبراطوري';
          case AppLanguage.bengali:
            return 'রাজকীয় মুকুট';
        }
      case PieceStyle.warriorShield:
        switch (lang) {
          case AppLanguage.urdu:
            return 'جنگی ڈھال';
          case AppLanguage.english:
            return 'Warrior Shield';
          case AppLanguage.hindi:
            return 'योद्धा ढाल';
          case AppLanguage.punjabi:
            return 'جنگی ڈھال';
          case AppLanguage.arabic:
            return 'درع المحارب';
          case AppLanguage.bengali:
            return 'যোদ্ধার ঢাল';
        }
      case PieceStyle.mughalFloral:
        switch (lang) {
          case AppLanguage.urdu:
            return 'مغل پھول';
          case AppLanguage.english:
            return 'Mughal Floral';
          case AppLanguage.hindi:
            return 'मुगल पुष्प';
          case AppLanguage.punjabi:
            return 'مغل پھل';
          case AppLanguage.arabic:
            return 'النقش المغولي';
          case AppLanguage.bengali:
            return 'মুঘল ফুল';
        }
    }
  }

  IconData get iconData {
    switch (this) {
      case PieceStyle.crystalMarble:
        return Icons.circle;
      case PieceStyle.royalCoin:
        return Icons.monetization_on_rounded;
      case PieceStyle.facetedGem:
        return Icons.diamond_rounded;
      case PieceStyle.royalCrown:
        return Icons.workspace_premium_rounded;
      case PieceStyle.warriorShield:
        return Icons.shield_rounded;
      case PieceStyle.mughalFloral:
        return Icons.filter_vintage_rounded;
    }
  }
}
