import 'package:flutter/material.dart';
import '../core/settings/settings_service.dart';
import 'app_language.dart';

enum BoardThemeType {
  classicWood,  // کلاسک شاہی اخروٹ (Royal Walnut / Teak Wood)
  royalMarble,  // گہرا نیلم ماربل (Sapphire Marble)
  midnightNavy, // کوسمک نائٹ نیوی (Cosmic Midnight Navy)
  royalIvory,   // رائل آئیوری (Royal Ivory)
  emeraldEntry; // زمرد لکڑی (Emerald Entry)

  String get labelUrdu => labelForLanguage(AppLanguage.urdu);

  String get label => labelForLanguage(SettingsService().language);

  String labelForLanguage(AppLanguage lang) {
    switch (this) {
      case BoardThemeType.classicWood:
        switch (lang) {
          case AppLanguage.urdu:
            return 'کلاسک شاہی اخروٹ';
          case AppLanguage.english:
            return 'Royal Walnut Wood';
          case AppLanguage.hindi:
            return 'क्लासिक अखरोट लकड़ी';
          case AppLanguage.punjabi:
            return 'شاہی اخروٹ لکڑ';
          case AppLanguage.arabic:
            return 'خشب الجوز الملكي';
          case AppLanguage.bengali:
            return 'রাজকীয় কাঠ';
        }
      case BoardThemeType.royalMarble:
        switch (lang) {
          case AppLanguage.urdu:
            return 'گہرا نیلم ماربل';
          case AppLanguage.english:
            return 'Sapphire Marble';
          case AppLanguage.hindi:
            return 'नीलम संगमरमर';
          case AppLanguage.punjabi:
            return 'نیلم پتھر';
          case AppLanguage.arabic:
            return 'رخام الياقوت الأزرق';
          case AppLanguage.bengali:
            return 'নীল মার্বেল';
        }
      case BoardThemeType.midnightNavy:
        switch (lang) {
          case AppLanguage.urdu:
            return 'کوسمک نائٹ نیوی';
          case AppLanguage.english:
            return 'Cosmic Midnight Navy';
          case AppLanguage.hindi:
            return 'कॉस्मिक मिडनाइट नेवी';
          case AppLanguage.punjabi:
            return 'کوسمک نیوی';
          case AppLanguage.arabic:
            return 'كحلي ليلي كوني';
          case AppLanguage.bengali:
            return 'কসমিক মধ্যরাত নেভি';
        }
      case BoardThemeType.royalIvory:
        switch (lang) {
          case AppLanguage.urdu:
            return 'شاہی عاج و آبنوس';
          case AppLanguage.english:
            return 'Royal Ivory';
          case AppLanguage.hindi:
            return 'रॉयल आइवरी';
          case AppLanguage.punjabi:
            return 'شاہی آئیوری';
          case AppLanguage.arabic:
            return 'العاج الملكي';
          case AppLanguage.bengali:
            return 'রাজকীয় আইভরি';
        }
      case BoardThemeType.emeraldEntry:
        switch (lang) {
          case AppLanguage.urdu:
            return 'رائل زمرد بورڈ';
          case AppLanguage.english:
            return 'Emerald Entry';
          case AppLanguage.hindi:
            return 'एमराल्ड एंट्री';
          case AppLanguage.punjabi:
            return 'زمرد بورڈ';
          case AppLanguage.arabic:
            return 'مدخل الزمرد';
          case AppLanguage.bengali:
            return 'পান্না এন্ট্রি';
        }
    }
  }

  List<Color> get boardGradient {
    switch (this) {
      case BoardThemeType.classicWood:
        return const [
          Color(0xFF3E2214),
          Color(0xFF24130A),
          Color(0xFF120904),
        ];
      case BoardThemeType.royalMarble:
        return const [
          Color(0xFF1E3A5F),
          Color(0xFF12233A),
          Color(0xFF0A1320),
        ];
      case BoardThemeType.midnightNavy:
        return const [
          Color(0xFF1B2845),
          Color(0xFF11192E),
          Color(0xFF080C17),
        ];
      case BoardThemeType.royalIvory:
        return const [
          Color(0xFF1E293B),
          Color(0xFF0F172A),
          Color(0xFF020617),
        ];
      case BoardThemeType.emeraldEntry:
        return const [
          Color(0xFF065F46),
          Color(0xFF047857),
          Color(0xFF022C22),
        ];
    }
  }

  Color get lineColor {
    switch (this) {
      case BoardThemeType.classicWood:
        return const Color(0xFFFFD700); // Polished Metallic Gold
      case BoardThemeType.royalMarble:
        return const Color(0xFF00F0FF); // Electric Cyan Glow
      case BoardThemeType.midnightNavy:
        return const Color(0xFFFFD700); // Radiant Gold
      case BoardThemeType.royalIvory:
        return const Color(0xFFF59E0B); // Warm Gold
      case BoardThemeType.emeraldEntry:
        return const Color(0xFFFBBF24); // Luminous Amber Gold
    }
  }
}
