class GameEmoji {
  final String id;
  final String emoji;
  final String labelUrdu;

  const GameEmoji({
    required this.id,
    required this.emoji,
    required this.labelUrdu,
  });

  static const List<GameEmoji> availableEmojis = [
    GameEmoji(id: 'laugh', emoji: '😂', labelUrdu: 'ہاہاہا!'),
    GameEmoji(id: 'cool', emoji: '😎', labelUrdu: 'چالاک!'),
    GameEmoji(id: 'fire', emoji: '🔥', labelUrdu: 'شاندار!'),
    GameEmoji(id: 'devil', emoji: '😈', labelUrdu: 'بچ کے رہو!'),
    GameEmoji(id: 'shock', emoji: '😱', labelUrdu: 'اوہ نہیں!'),
    GameEmoji(id: 'think', emoji: '🤔', labelUrdu: 'سوچ رہا ہوں...'),
    GameEmoji(id: 'clap', emoji: '👏', labelUrdu: 'شاباش!'),
    GameEmoji(id: 'cry', emoji: '😭', labelUrdu: 'افسوس!'),
    GameEmoji(id: 'trophy', emoji: '🏆', labelUrdu: 'جیت میری ہے!'),
    GameEmoji(id: 'target', emoji: '🎯', labelUrdu: 'پکا شکار!'),
    GameEmoji(id: 'quiet', emoji: '🤫', labelUrdu: 'خاموشی!'),
    GameEmoji(id: 'handshake', emoji: '🤝', labelUrdu: 'زبردست کھیل!'),
  ];
}
