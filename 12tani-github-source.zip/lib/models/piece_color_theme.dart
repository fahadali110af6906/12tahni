import 'package:flutter/material.dart';
import '../core/settings/settings_service.dart';
import 'app_language.dart';

enum PieceColorOption {
  rubyRed,      // شعلہ سرخ (Ruby Flame)
  emeraldGreen, // الیکٹرک سائین (Electric Cyan Emerald)
  sapphireBlue, // شاہی نیلا (Sapphire Blue)
  goldenAmber,  // سنہری امبر (Golden Amber)
  amethystPurple,// یاقوت جامنی (Amethyst Violet)
  obsidianBlack; // ٹائٹینیم سلور (Titanium Slate)

  String get labelUrdu => labelForLanguage(AppLanguage.urdu);

  String get label => labelForLanguage(SettingsService().language);

  String labelForLanguage(AppLanguage lang) {
    switch (this) {
      case PieceColorOption.rubyRed:
        switch (lang) {
          case AppLanguage.urdu:
            return 'شعلہ سرخ';
          case AppLanguage.english:
            return 'Ruby Red';
          case AppLanguage.hindi:
            return 'रूबी लाल';
          case AppLanguage.punjabi:
            return 'لال رنگ';
          case AppLanguage.arabic:
            return 'أحمر ياقوتي';
          case AppLanguage.bengali:
            return 'রুবি লাল';
        }
      case PieceColorOption.emeraldGreen:
        switch (lang) {
          case AppLanguage.urdu:
            return 'الیکٹرک سائین';
          case AppLanguage.english:
            return 'Electric Cyan';
          case AppLanguage.hindi:
            return 'इलेक्ट्रिक सियान';
          case AppLanguage.punjabi:
            return 'فیروزی رنگ';
          case AppLanguage.arabic:
            return 'سماوي كهربائي';
          case AppLanguage.bengali:
            return 'ইলেকট্রিক সায়ান';
        }
      case PieceColorOption.sapphireBlue:
        switch (lang) {
          case AppLanguage.urdu:
            return 'شاہی نیلا';
          case AppLanguage.english:
            return 'Sapphire Blue';
          case AppLanguage.hindi:
            return 'शाही नीला';
          case AppLanguage.punjabi:
            return 'نیلا رنگ';
          case AppLanguage.arabic:
            return 'أزرق ياقوتي';
          case AppLanguage.bengali:
            return 'নীলকান্তমণি';
        }
      case PieceColorOption.goldenAmber:
        switch (lang) {
          case AppLanguage.urdu:
            return 'سنہری امبر';
          case AppLanguage.english:
            return 'Golden Amber';
          case AppLanguage.hindi:
            return 'सुनहरा अंबर';
          case AppLanguage.punjabi:
            return 'سنہری رنگ';
          case AppLanguage.arabic:
            return 'عنبر ذهبي';
          case AppLanguage.bengali:
            return 'সোনালী অ্যাম্বার';
        }
      case PieceColorOption.amethystPurple:
        switch (lang) {
          case AppLanguage.urdu:
            return 'یاقوت جامنی';
          case AppLanguage.english:
            return 'Amethyst Purple';
          case AppLanguage.hindi:
            return 'बैंगनी अमिथिस्ट';
          case AppLanguage.punjabi:
            return 'جامنی رنگ';
          case AppLanguage.arabic:
            return 'أرجواني جمشتي';
          case AppLanguage.bengali:
            return 'বেগুনী রত্ন';
        }
      case PieceColorOption.obsidianBlack:
        switch (lang) {
          case AppLanguage.urdu:
            return 'ٹائٹینیم سلور';
          case AppLanguage.english:
            return 'Titanium Silver';
          case AppLanguage.hindi:
            return 'टाइटेनियम सिल्वर';
          case AppLanguage.punjabi:
            return 'سلور رنگ';
          case AppLanguage.arabic:
            return 'فضي تيتانيوم';
          case AppLanguage.bengali:
            return 'টাইটানিয়াম সিলভার';
        }
    }
  }

  Color get primaryColor {
    switch (this) {
      case PieceColorOption.rubyRed:
        return const Color(0xFFFF1744);
      case PieceColorOption.emeraldGreen:
        return const Color(0xFF00E5FF);
      case PieceColorOption.sapphireBlue:
        return const Color(0xFF2979FF);
      case PieceColorOption.goldenAmber:
        return const Color(0xFFFFD700);
      case PieceColorOption.amethystPurple:
        return const Color(0xFFE040FB);
      case PieceColorOption.obsidianBlack:
        return const Color(0xFF78909C);
    }
  }

  Color get lightColor {
    switch (this) {
      case PieceColorOption.rubyRed:
        return const Color(0xFFFF80AB);
      case PieceColorOption.emeraldGreen:
        return const Color(0xFF84FFFF);
      case PieceColorOption.sapphireBlue:
        return const Color(0xFF82B1FF);
      case PieceColorOption.goldenAmber:
        return const Color(0xFFFFE57F);
      case PieceColorOption.amethystPurple:
        return const Color(0xFFEA80FC);
      case PieceColorOption.obsidianBlack:
        return const Color(0xFFECEFF1);
    }
  }

  Color get darkColor {
    switch (this) {
      case PieceColorOption.rubyRed:
        return const Color(0xFFB71C1C);
      case PieceColorOption.emeraldGreen:
        return const Color(0xFF00838F);
      case PieceColorOption.sapphireBlue:
        return const Color(0xFF0D47A1);
      case PieceColorOption.goldenAmber:
        return const Color(0xFFFF6F00);
      case PieceColorOption.amethystPurple:
        return const Color(0xFF4A148C);
      case PieceColorOption.obsidianBlack:
        return const Color(0xFF263238);
    }
  }

  Color get glowColor {
    switch (this) {
      case PieceColorOption.rubyRed:
        return const Color(0xFFFF5252);
      case PieceColorOption.emeraldGreen:
        return const Color(0xFF00F0FF);
      case PieceColorOption.sapphireBlue:
        return const Color(0xFF448AFF);
      case PieceColorOption.goldenAmber:
        return const Color(0xFFFFEA00);
      case PieceColorOption.amethystPurple:
        return const Color(0xFFF50057);
      case PieceColorOption.obsidianBlack:
        return const Color(0xFFFFFFFF);
    }
  }
}
