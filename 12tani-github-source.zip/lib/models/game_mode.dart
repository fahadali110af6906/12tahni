import '../core/constants/app_strings.dart';
import '../core/settings/settings_service.dart';
import 'app_language.dart';

enum GameMode {
  vsAi,
  passAndPlay,
  onlineMatch,
  playWithFriend;

  String get titleUrdu => titleForLanguage(AppLanguage.urdu);
  String get descUrdu => descForLanguage(AppLanguage.urdu);

  String get title => titleForLanguage(SettingsService().language);
  String get desc => descForLanguage(SettingsService().language);

  String titleForLanguage(AppLanguage lang) {
    switch (this) {
      case GameMode.vsAi:
        return AppStrings.singlePlayer;
      case GameMode.passAndPlay:
        return AppStrings.twoPlayer;
      case GameMode.onlineMatch:
        return AppStrings.onlineMatch;
      case GameMode.playWithFriend:
        return AppStrings.playWithFriend;
    }
  }

  String descForLanguage(AppLanguage lang) {
    switch (this) {
      case GameMode.vsAi:
        return AppStrings.singlePlayerDesc;
      case GameMode.passAndPlay:
        return AppStrings.twoPlayerDesc;
      case GameMode.onlineMatch:
        return AppStrings.onlineMatchDesc;
      case GameMode.playWithFriend:
        return AppStrings.playWithFriendDesc;
    }
  }
}
