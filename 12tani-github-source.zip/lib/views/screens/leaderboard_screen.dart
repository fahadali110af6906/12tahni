import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/supabase/supabase_service.dart';
import '../../models/user_profile.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  final SoundService _sound = SoundService();
  final UserProfile _user = UserProfile();
  final SupabaseService _supabase = SupabaseService();
  int _selectedTab = 0; // 0: Global, 1: Friends
  List<Map<String, dynamic>> _topPlayers = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadLeaderboard();
  }

  Future<void> _loadLeaderboard() async {
    setState(() => _isLoading = true);
    final data = await _supabase.fetchLeaderboard();
    if (mounted) {
      setState(() {
        _topPlayers = data;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF090E18),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0E1729),
              Color(0xFF090E18),
              Color(0xFF05080E),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                children: [
                  // Top App Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            _sound.playButtonClick();
                            Navigator.of(context).pop();
                          },
                          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
                        ),
                        const Expanded(
                          child: Text(
                            'LEADERBOARD - SEASON 4',
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: _loadLeaderboard,
                          icon: const Icon(Icons.refresh_rounded, color: Color(0xFFF3C35C), size: 20),
                        ),
                      ],
                    ),
                  ),

                  // Global / Friends Segment Tab
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF162238),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: const Color(0xFF233554)),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              _sound.playButtonClick();
                              setState(() => _selectedTab = 0);
                            },
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: _selectedTab == 0 ? const Color(0xFFD97706) : Colors.transparent,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              alignment: Alignment.center,
                              child: const Text(
                                'Global',
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              _sound.playButtonClick();
                              setState(() => _selectedTab = 1);
                            },
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: _selectedTab == 1 ? const Color(0xFFD97706) : Colors.transparent,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              alignment: Alignment.center,
                              child: const Text(
                                'Friends',
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white70),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Top 3 Podium (1st, 2nd, 3rd)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _buildPodiumBadge(rank: 2, icon: '🥈', color: const Color(0xFF94A3B8), height: 90),
                        const SizedBox(width: 14),
                        _buildPodiumBadge(rank: 1, icon: '🥇', color: const Color(0xFFF59E0B), height: 110),
                        const SizedBox(width: 14),
                        _buildPodiumBadge(rank: 3, icon: '🥉', color: const Color(0xFFB45309), height: 85),
                      ],
                    ),
                  ),

                  // Scrollable Ranked List
                  Expanded(
                    child: _isLoading
                        ? const Center(
                            child: CircularProgressIndicator(color: Color(0xFFF59E0B)),
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                            physics: const BouncingScrollPhysics(),
                            itemCount: _topPlayers.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (context, index) {
                              final p = _topPlayers[index];
                              final isUser = p['isUser'] == true || p['player_name'] == _user.name;
                              final name = p['player_name'] ?? p['name'] ?? 'Player';
                              final avatar = p['avatar'] ?? '👤';
                              final winRate = p['winRate'] ?? '${p['wins'] ?? 0} wins';

                              return Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                decoration: BoxDecoration(
                                  color: isUser ? const Color(0xFF1E2D4A) : const Color(0xFF121B2D),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: isUser ? const Color(0xFFF3C35C) : const Color(0xFF1E2E4E),
                                    width: isUser ? 1.5 : 1.0,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    // Rank
                                    SizedBox(
                                      width: 24,
                                      child: Text(
                                        '${p['rank'] ?? (index + 1)}',
                                        style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w900,
                                          color: isUser ? const Color(0xFFF3C35C) : const Color(0xFF94A3B8),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),

                                    // Avatar
                                    Container(
                                      width: 38,
                                      height: 38,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xFF0F172A),
                                      ),
                                      child: Center(
                                        child: Text(avatar, style: const TextStyle(fontSize: 20)),
                                      ),
                                    ),
                                    const SizedBox(width: 12),

                                    // Player Name
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            name,
                                            style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.bold,
                                              color: isUser ? const Color(0xFFF3C35C) : Colors.white,
                                            ),
                                          ),
                                          Text(
                                            'Win Rate $winRate',
                                            style: const TextStyle(fontSize: 11, color: Color(0xFF64748B)),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // Win Rate / Trophy
                                    Row(
                                      children: [
                                        Text(
                                          '$winRate',
                                          style: const TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white70,
                                          ),
                                        ),
                                        const SizedBox(width: 6),
                                        const Icon(Icons.emoji_events_rounded, color: Color(0xFFF3C35C), size: 18),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),

                  // Bottom Pinned User Profile Card (Sarah)
                  Container(
                    margin: const EdgeInsets.all(12),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF162544),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF2563EB), width: 1.5),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xFF0F172A),
                          ),
                          child: Center(
                            child: Text(_user.avatar, style: const TextStyle(fontSize: 22)),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _user.name,
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white),
                              ),
                              const Text('Player Stats', style: TextStyle(fontSize: 10, color: Color(0xFF94A3B8))),
                            ],
                          ),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _buildStatChip('Games', '${_user.totalGames}'),
                            const SizedBox(width: 8),
                            _buildStatChip('Wins', '${_user.wins}'),
                            const SizedBox(width: 8),
                            _buildStatChip('Rate', '${_user.winRate}%'),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPodiumBadge({required int rank, required String icon, required Color color, required double height}) {
    return Container(
      width: 78,
      height: height,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF131D31),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color, width: 2),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(icon, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 2),
            Text(
              'Rank $rank',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: color),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatChip(String label, String value) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(value, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white)),
        Text(label, style: const TextStyle(fontSize: 8, color: Color(0xFF64748B))),
      ],
    );
  }
}
