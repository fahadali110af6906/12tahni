import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/settings/settings_service.dart';
import '../../models/board_theme_type.dart';
import '../../models/piece_color_theme.dart';
import '../../models/piece_style.dart';
import '../../models/player_type.dart';
import '../../models/shop_item.dart';
import '../../models/user_profile.dart';
import '../widgets/game_board_view.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  final UserProfile _user = UserProfile();
  final SoundService _sound = SoundService();
  final SettingsService _settings = SettingsService();

  final ScrollController _beadScrollController = ScrollController();
  final ScrollController _boardScrollController = ScrollController();

  late String _selectedBeadId;
  late String _selectedBoardId;

  int _beadScrollIndex = 0;
  int _boardScrollIndex = 0;

  @override
  void initState() {
    super.initState();
    _selectedBeadId = _user.equippedBead;
    _selectedBoardId = _user.equippedBoard;
    _user.addListener(_onProfileChanged);

    _beadScrollController.addListener(() {
      if (!_beadScrollController.hasClients) return;
      final max = _beadScrollController.position.maxScrollExtent;
      final current = _beadScrollController.offset;
      final idx = max > 0 ? ((current / max) * 3).round().clamp(0, 3) : 0;
      if (idx != _beadScrollIndex) {
        setState(() => _beadScrollIndex = idx);
      }
    });

    _boardScrollController.addListener(() {
      if (!_boardScrollController.hasClients) return;
      final max = _boardScrollController.position.maxScrollExtent;
      final current = _boardScrollController.offset;
      final idx = max > 0 ? ((current / max) * 3).round().clamp(0, 3) : 0;
      if (idx != _boardScrollIndex) {
        setState(() => _boardScrollIndex = idx);
      }
    });
  }

  void _onProfileChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _user.removeListener(_onProfileChanged);
    _beadScrollController.dispose();
    _boardScrollController.dispose();
    super.dispose();
  }

  String _formatPrice(int price) {
    if (price >= 1000) {
      final thousands = price ~/ 1000;
      final remainder = price % 1000;
      return '$thousands,${remainder.toString().padLeft(3, '0')}';
    }
    return '$price';
  }

  void _onEquipOrPreview() {
    _sound.playButtonClick();

    final bead = ShopItem.allItems.firstWhere(
      (i) => i.id == _selectedBeadId,
      orElse: () => ShopItem.allItems.first,
    );
    final board = ShopItem.allItems.firstWhere(
      (i) => i.id == _selectedBoardId,
      orElse: () => ShopItem.allItems[4],
    );

    // 1. Try to unlock selected Bead if locked
    if (!_user.isUnlocked(_selectedBeadId)) {
      final success = _user.unlockItem(_selectedBeadId, cost: bead.price, isGem: bead.isGem);
      if (!success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Not enough ${bead.isGem ? '💎 Gems' : '🪙 Coins'} for ${bead.title}!'),
            backgroundColor: const Color(0xFFEF4444),
            duration: const Duration(seconds: 2),
          ),
        );
        return;
      }
    }

    // 2. Try to unlock selected Board if locked
    if (!_user.isUnlocked(_selectedBoardId)) {
      final success = _user.unlockItem(_selectedBoardId, cost: board.price, isGem: board.isGem);
      if (!success) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Not enough ${board.isGem ? '💎 Gems' : '🪙 Coins'} for ${board.title}!'),
            backgroundColor: const Color(0xFFEF4444),
            duration: const Duration(seconds: 2),
          ),
        );
        return;
      }
    }

    // 3. Equip both in UserProfile
    _user.equipBead(_selectedBeadId);
    _user.equipBoard(_selectedBoardId);

    // 4. Sync with SettingsService for in-game board rendering
    _syncWithSettings(_selectedBeadId, _selectedBoardId);

    // 5. Open visual preview modal
    _showLivePreviewModal(context, bead, board);
  }

  void _syncWithSettings(String beadId, String boardId) {
    switch (beadId) {
      case 'gemstone':
        _settings.setPlayer1Style(PieceStyle.facetedGem);
        _settings.setPlayer2Style(PieceStyle.facetedGem);
        _settings.setPlayer2Color(PieceColorOption.emeraldGreen);
        break;
      case 'metallic':
        _settings.setPlayer1Style(PieceStyle.royalCoin);
        _settings.setPlayer2Style(PieceStyle.royalCoin);
        _settings.setPlayer2Color(PieceColorOption.obsidianBlack);
        break;
      case 'classic_wood':
        _settings.setPlayer1Style(PieceStyle.crystalMarble);
        _settings.setPlayer2Style(PieceStyle.crystalMarble);
        _settings.setPlayer2Color(PieceColorOption.goldenAmber);
        break;
      case 'marble':
        _settings.setPlayer1Style(PieceStyle.crystalMarble);
        _settings.setPlayer2Style(PieceStyle.crystalMarble);
        _settings.setPlayer2Color(PieceColorOption.sapphireBlue);
        break;
    }

    switch (boardId) {
      case 'royal_ivory':
        _settings.setBoardTheme(BoardThemeType.royalIvory);
        break;
      case 'teak_wood':
        _settings.setBoardTheme(BoardThemeType.classicWood);
        break;
      case 'emerald_entry':
        _settings.setBoardTheme(BoardThemeType.emeraldEntry);
        break;
      case 'classic_dark':
      default:
        _settings.setBoardTheme(BoardThemeType.midnightNavy);
        break;
    }
  }

  void _showLivePreviewModal(BuildContext context, ShopItem bead, ShopItem board) {
    showDialog(
      context: context,
      builder: (ctx) {
        // Initial sample 12 Tani setup for preview
        final sampleBoard = List<PlayerType?>.filled(25, null);
        for (int i = 0; i < 12; i++) {
          sampleBoard[i] = PlayerType.player1;
        }
        for (int i = 13; i < 25; i++) {
          sampleBoard[i] = PlayerType.player2;
        }

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF0F172A),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: const Color(0xFF22C55E), width: 2),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF22C55E).withValues(alpha: 0.35),
                  blurRadius: 24,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'PREVIEW & EQUIPPED! ✨',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                        color: Color(0xFF22C55E),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(ctx).pop(),
                      icon: const Icon(Icons.close_rounded, color: Colors.white70, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Selected Info Tags
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Row(
                        children: [
                          _buildPreviewGraphic(bead, size: 16),
                          const SizedBox(width: 6),
                          Text(
                            bead.title,
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Row(
                        children: [
                          _buildPreviewGraphic(board, size: 16),
                          const SizedBox(width: 6),
                          Text(
                            board.title,
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Live Game Board View
                SizedBox(
                  width: 250,
                  height: 250,
                  child: GameBoardView(
                    board: sampleBoard,
                    onPointTapped: (_) {},
                  ),
                ),
                const SizedBox(height: 18),

                // Confirm Button
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF22C55E),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    ),
                    child: const Text(
                      'READY TO PLAY',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final beadItems = ShopItem.allItems.where((i) => i.category == ShopCategory.beads).toList();
    final boardItems = ShopItem.allItems.where((i) => i.category == ShopCategory.boards).toList();

    return Scaffold(
      backgroundColor: const Color(0xFF0A0F1D),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0F172A),
              Color(0xFF0B1120),
              Color(0xFF060912),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                children: [
                  // 1. Top Navigation Header (Matching Reference UI)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            _sound.playButtonClick();
                            Navigator.of(context).pop();
                          },
                          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                        ),
                        const Expanded(
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'SHOP & CUSTOMIZE',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),

                        // User Wallet (Gems & Coins)
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1E293B),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: const Color(0xFFF3C35C).withValues(alpha: 0.5)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Text('🪙', style: TextStyle(fontSize: 11)),
                                  const SizedBox(width: 3),
                                  Text(
                                    '${_user.coins}',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFFACC15),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 5),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1E293B),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: const Color(0xFF38BDF8).withValues(alpha: 0.5)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Text('💎', style: TextStyle(fontSize: 11)),
                                  const SizedBox(width: 3),
                                  Text(
                                    '${_user.gems}',
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF38BDF8),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // 2. Catalog Scroll Area
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Section 1: BEAD SKINS
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'BEAD SKINS',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                  color: Color(0xFF94A3B8),
                                ),
                              ),
                              _buildDotsIndicator(_beadScrollIndex, 4),
                            ],
                          ),
                          const SizedBox(height: 10),

                          // Responsive 3-Card Carousel for Beads
                          LayoutBuilder(
                            builder: (context, constraints) {
                              const cardGap = 8.0;
                              // Fits exactly 3 cards edge-to-edge on any screen size!
                              final cardWidth = (constraints.maxWidth - (2 * cardGap)) / 3.0;

                              return SizedBox(
                                height: 154,
                                child: ListView.separated(
                                  controller: _beadScrollController,
                                  scrollDirection: Axis.horizontal,
                                  physics: const BouncingScrollPhysics(),
                                  itemCount: beadItems.length,
                                  separatorBuilder: (_, __) => const SizedBox(width: cardGap),
                                  itemBuilder: (context, index) {
                                    final item = beadItems[index];
                                    final isSelected = _selectedBeadId == item.id;
                                    final isEquipped = _user.equippedBead == item.id;
                                    final isUnlocked = _user.isUnlocked(item.id);

                                    return SizedBox(
                                      width: cardWidth,
                                      child: _buildSkinCard(
                                        item: item,
                                        isSelected: isSelected,
                                        isEquipped: isEquipped,
                                        isUnlocked: isUnlocked,
                                        onTap: () {
                                          _sound.playButtonClick();
                                          setState(() {
                                            _selectedBeadId = item.id;
                                          });
                                        },
                                      ),
                                    );
                                  },
                                ),
                              );
                            },
                          ),

                          const SizedBox(height: 24),

                          // Section 2: BOARD THEMES
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'BOARD THEMES',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                  color: Color(0xFF94A3B8),
                                ),
                              ),
                              _buildDotsIndicator(_boardScrollIndex, 4),
                            ],
                          ),
                          const SizedBox(height: 10),

                          // Responsive 3-Card Carousel for Board Themes
                          LayoutBuilder(
                            builder: (context, constraints) {
                              const cardGap = 8.0;
                              // Fits exactly 3 cards edge-to-edge on any screen size!
                              final cardWidth = (constraints.maxWidth - (2 * cardGap)) / 3.0;

                              return SizedBox(
                                height: 154,
                                child: ListView.separated(
                                  controller: _boardScrollController,
                                  scrollDirection: Axis.horizontal,
                                  physics: const BouncingScrollPhysics(),
                                  itemCount: boardItems.length,
                                  separatorBuilder: (_, __) => const SizedBox(width: cardGap),
                                  itemBuilder: (context, index) {
                                    final item = boardItems[index];
                                    final isSelected = _selectedBoardId == item.id;
                                    final isEquipped = _user.equippedBoard == item.id;
                                    final isUnlocked = _user.isUnlocked(item.id);

                                    return SizedBox(
                                      width: cardWidth,
                                      child: _buildSkinCard(
                                        item: item,
                                        isSelected: isSelected,
                                        isEquipped: isEquipped,
                                        isUnlocked: isUnlocked,
                                        onTap: () {
                                          _sound.playButtonClick();
                                          setState(() {
                                            _selectedBoardId = item.id;
                                          });
                                        },
                                      ),
                                    );
                                  },
                                ),
                              );
                            },
                          ),

                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ),

                  // 3. Bottom Action Button (PREVIEW / EQUIP)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                    child: Container(
                      width: double.infinity,
                      height: 52,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(26),
                        gradient: const LinearGradient(
                          colors: [Color(0xFF22C55E), Color(0xFF16A34A)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF22C55E).withValues(alpha: 0.4),
                            blurRadius: 14,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: _onEquipOrPreview,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.visibility_rounded, color: Colors.white, size: 20),
                            SizedBox(width: 8),
                            Text(
                              'EQUIP & PREVIEW',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.4,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDotsIndicator(int activeIndex, int totalDots) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('⟨ ', style: TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.bold)),
        for (int i = 0; i < totalDots; i++) ...[
          Container(
            width: i == activeIndex ? 6 : 4,
            height: i == activeIndex ? 6 : 4,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: i == activeIndex ? const Color(0xFF22C55E) : const Color(0xFF64748B),
            ),
          ),
          if (i < totalDots - 1) const SizedBox(width: 4),
        ],
        const Text(' ⟩', style: TextStyle(fontSize: 12, color: Color(0xFF64748B), fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildSkinCard({
    required ShopItem item,
    required bool isSelected,
    required bool isEquipped,
    required bool isUnlocked,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF162238),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF22C55E)
                : isEquipped
                    ? const Color(0xFFF3C35C)
                    : const Color(0xFF233554),
            width: isSelected ? 2.0 : (isEquipped ? 1.6 : 1.2),
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: const Color(0xFF22C55E).withValues(alpha: 0.35),
                    blurRadius: 10,
                  ),
                ]
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 3D Realistic Graphic Preview
            SizedBox(
              width: 50,
              height: 50,
              child: Center(
                child: _buildPreviewGraphic(item),
              ),
            ),
            const SizedBox(height: 8),

            // Title with Auto-Fit (Never truncated awkwardly)
            SizedBox(
              height: 16,
              child: Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    item.title,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),

            // Price / Equipped Tag
            if (isEquipped)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFFF3C35C).withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: const Color(0xFFF3C35C).withValues(alpha: 0.6), width: 0.8),
                ),
                child: const FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    'EQUIPPED',
                    style: TextStyle(
                      fontSize: 8.5,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFFF3C35C),
                      letterSpacing: 0.4,
                    ),
                  ),
                ),
              )
            else if (isUnlocked)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFF22C55E).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: const Color(0xFF22C55E).withValues(alpha: 0.4), width: 0.8),
                ),
                child: const FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    'UNLOCKED',
                    style: TextStyle(
                      fontSize: 8.5,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF22C55E),
                      letterSpacing: 0.4,
                    ),
                  ),
                ),
              )
            else
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: Colors.white12, width: 0.8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(item.isGem ? '💎' : '🪙', style: const TextStyle(fontSize: 9.5)),
                    const SizedBox(width: 3),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        _formatPrice(item.price),
                        style: TextStyle(
                          fontSize: 9.5,
                          fontWeight: FontWeight.w800,
                          color: item.isGem ? const Color(0xFF38BDF8) : const Color(0xFFFACC15),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPreviewGraphic(ShopItem item, {double size = 48}) {
    switch (item.id) {
      case 'gemstone':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              center: Alignment(-0.35, -0.4),
              radius: 0.85,
              colors: [
                Color(0xFF6EE7B7), // Mint highlight
                Color(0xFF10B981), // Emerald body
                Color(0xFF047857), // Deep emerald
                Color(0xFF022C22), // Shadow
              ],
              stops: [0.0, 0.35, 0.75, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF10B981).withValues(alpha: 0.5),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Stack(
            children: [
              CustomPaint(
                size: Size(size, size),
                painter: _GemstoneFacetsPainter(),
              ),
              Positioned(
                top: size * 0.14,
                left: size * 0.20,
                child: Container(
                  width: size * 0.28,
                  height: size * 0.16,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.85),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        );

      case 'metallic':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              center: Alignment(-0.35, -0.4),
              radius: 0.9,
              colors: [
                Color(0xFFFFFFFF),
                Color(0xFFE2E8F0),
                Color(0xFF94A3B8),
                Color(0xFF475569),
                Color(0xFF1E293B),
              ],
              stops: [0.0, 0.25, 0.55, 0.85, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF94A3B8).withValues(alpha: 0.4),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                top: size * 0.12,
                left: size * 0.18,
                child: Container(
                  width: size * 0.3,
                  height: size * 0.15,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.95),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              Positioned(
                bottom: size * 0.14,
                right: size * 0.20,
                child: Container(
                  width: size * 0.2,
                  height: size * 0.08,
                  decoration: BoxDecoration(
                    color: const Color(0xFFCBD5E1).withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
              ),
            ],
          ),
        );

      case 'classic_wood':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              center: Alignment(-0.35, -0.4),
              radius: 0.85,
              colors: [
                Color(0xFFF59E0B),
                Color(0xFFB45309),
                Color(0xFF78350F),
                Color(0xFF451A03),
              ],
              stops: [0.0, 0.35, 0.75, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFB45309).withValues(alpha: 0.4),
                blurRadius: 8,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Stack(
            children: [
              CustomPaint(
                size: Size(size, size),
                painter: _WoodGrainPainter(),
              ),
              Positioned(
                top: size * 0.16,
                left: size * 0.22,
                child: Container(
                  width: size * 0.24,
                  height: size * 0.12,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ],
          ),
        );

      case 'marble':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              center: Alignment(-0.35, -0.4),
              radius: 0.85,
              colors: [
                Color(0xFFFFFFFF),
                Color(0xFFF8FAFC),
                Color(0xFFE2E8F0),
                Color(0xFF94A3B8),
              ],
              stops: [0.0, 0.3, 0.7, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.white.withValues(alpha: 0.3),
                blurRadius: 8,
              ),
            ],
          ),
          child: Stack(
            children: [
              CustomPaint(
                size: Size(size, size),
                painter: _MarbleVeinPainter(),
              ),
              Positioned(
                top: size * 0.14,
                left: size * 0.20,
                child: Container(
                  width: size * 0.28,
                  height: size * 0.14,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.95),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ],
          ),
        );

      case 'royal_ivory':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF1E293B),
                Color(0xFF0F172A),
                Color(0xFF020617),
              ],
            ),
            border: Border.all(color: const Color(0xFFF59E0B).withValues(alpha: 0.6), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 6,
              ),
            ],
          ),
          child: CustomPaint(
            size: Size(size, size),
            painter: _MiniBoardPainter(lineColor: const Color(0xFFF59E0B)),
          ),
        );

      case 'teak_wood':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF92400E),
                Color(0xFF78350F),
                Color(0xFF451A03),
              ],
            ),
            border: Border.all(color: const Color(0xFFFCD34D).withValues(alpha: 0.6), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 6,
              ),
            ],
          ),
          child: CustomPaint(
            size: Size(size, size),
            painter: _MiniBoardPainter(lineColor: const Color(0xFFFCD34D)),
          ),
        );

      case 'emerald_entry':
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF047857),
                Color(0xFF065F46),
                Color(0xFF064E3B),
              ],
            ),
            border: Border.all(color: const Color(0xFFFBBF24).withValues(alpha: 0.6), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 6,
              ),
            ],
          ),
          child: CustomPaint(
            size: Size(size, size),
            painter: _MiniBoardPainter(lineColor: const Color(0xFFFBBF24)),
          ),
        );

      case 'classic_dark':
      default:
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF3E2214),
                Color(0xFF24130A),
                Color(0xFF120904),
              ],
            ),
            border: Border.all(color: const Color(0xFFFFD700).withValues(alpha: 0.6), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.5),
                blurRadius: 6,
              ),
            ],
          ),
          child: CustomPaint(
            size: Size(size, size),
            painter: _MiniBoardPainter(lineColor: const Color(0xFFFFD700)),
          ),
        );
    }
  }
}

class _GemstoneFacetsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.5);
    final radius = size.width * 0.42;

    final facetPaint = Paint()
      ..color = const Color(0xFF6EE7B7).withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;

    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = i * (pi / 3);
      final p1 = center + Offset(cos(angle) * radius * 0.55, sin(angle) * radius * 0.55);
      final p2 = center + Offset(cos(angle + pi / 3) * radius * 0.55, sin(angle + pi / 3) * radius * 0.55);
      path.moveTo(p1.dx, p1.dy);
      path.lineTo(p2.dx, p2.dy);
      path.lineTo(center.dx, center.dy);
    }
    canvas.drawPath(path, facetPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _WoodGrainPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grainPaint = Paint()
      ..color = const Color(0xFF451A03).withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;

    final center = Offset(size.width * 0.48, size.height * 0.48);
    for (double r = size.width * 0.18; r < size.width * 0.45; r += size.width * 0.09) {
      canvas.drawCircle(center, r, grainPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _MarbleVeinPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final veinPaint = Paint()
      ..color = const Color(0xFF94A3B8).withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round;

    final path = Path();
    path.moveTo(size.width * 0.25, size.height * 0.75);
    path.quadraticBezierTo(size.width * 0.5, size.height * 0.45, size.width * 0.75, size.height * 0.25);
    path.moveTo(size.width * 0.4, size.height * 0.6);
    path.quadraticBezierTo(size.width * 0.65, size.height * 0.7, size.width * 0.8, size.height * 0.5);
    canvas.drawPath(path, veinPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _MiniBoardPainter extends CustomPainter {
  final Color lineColor;

  _MiniBoardPainter({required this.lineColor});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = lineColor.withValues(alpha: 0.85)
      ..strokeWidth = 0.9
      ..style = PaintingStyle.stroke;

    final double pad = size.width * 0.12;
    final double w = size.width - pad * 2;
    final double h = size.height - pad * 2;
    final double cellW = w / 4.0;
    final double cellH = h / 4.0;

    Offset pt(int r, int c) => Offset(pad + c * cellW, pad + r * cellH);

    // Border
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pad, pad, w, h), const Radius.circular(3)),
      p,
    );

    // Grid lines
    for (int i = 1; i < 4; i++) {
      canvas.drawLine(pt(i, 0), pt(i, 4), p);
      canvas.drawLine(pt(0, i), pt(4, i), p);
    }
    // Main Diagonals
    canvas.drawLine(pt(0, 0), pt(4, 4), p);
    canvas.drawLine(pt(0, 4), pt(4, 0), p);
    // Diamond
    canvas.drawLine(pt(2, 0), pt(0, 2), p);
    canvas.drawLine(pt(0, 2), pt(2, 4), p);
    canvas.drawLine(pt(2, 4), pt(4, 2), p);
    canvas.drawLine(pt(4, 2), pt(2, 0), p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
