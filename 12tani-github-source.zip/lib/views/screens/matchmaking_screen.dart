import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_strings.dart';
import '../../core/supabase/supabase_service.dart';
import '../../models/difficulty.dart';
import '../../models/game_mode.dart';
import '../../models/user_profile.dart';
import 'game_screen.dart';

class MatchmakingScreen extends StatefulWidget {
  final int wager;

  const MatchmakingScreen({super.key, this.wager = 200});

  @override
  State<MatchmakingScreen> createState() => _MatchmakingScreenState();
}

class _MatchmakingScreenState extends State<MatchmakingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _radarController;
  final SoundService _sound = SoundService();
  final UserProfile _user = UserProfile();
  final SupabaseService _supabase = SupabaseService();
  Timer? _searchTimer;
  StreamSubscription<Map<String, dynamic>>? _opponentSub;

  bool _opponentFound = false;
  String _opponentName = 'David R.';
  String _opponentAvatar = '🧔';
  String _opponentRank = 'Rank 16';
  String _opponentCoins = '🪙 2,400';
  bool _isHost = true;
  String _roomCode = 'matchmaking_queue';

  @override
  void initState() {
    super.initState();
    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();

    _roomCode = 'online_${1000 + Random().nextInt(9000)}';
    _isHost = Random().nextBool();

    _connectToSupabaseMatchmaking();
  }

  Future<void> _connectToSupabaseMatchmaking() async {
    // Join Supabase Realtime channel
    await _supabase.joinGameRoom(
      roomCode: _roomCode,
      playerName: _user.name,
      playerAvatar: _user.avatar,
      isHost: _isHost,
      wager: widget.wager,
    );

    _opponentSub = _supabase.onOpponentJoined.listen((data) {
      if (!mounted) return;
      final name = data['name'] as String? ?? 'Opponent';
      final avatar = data['avatar'] as String? ?? '🧔';
      _onOpponentMatched(name: name, avatar: avatar, rank: 'Rank 15', coins: '🪙 1,800');
    });

    // Fallback timer if no remote player joined in 3.2s
    _searchTimer = Timer(const Duration(milliseconds: 3200), () {
      if (!mounted || _opponentFound) return;
      final botNames = ['David R.', 'Alex M.', 'Vikram S.', 'Ali Khan', 'Elena G.'];
      final botAvatars = ['🧔', '👦', '👳', '🧑', '👧'];
      final idx = Random().nextInt(botNames.length);

      _onOpponentMatched(
        name: botNames[idx],
        avatar: botAvatars[idx],
        rank: 'Rank ${12 + Random().nextInt(8)}',
        coins: '🪙 ${1200 + Random().nextInt(1500)}',
      );
    });
  }

  void _onOpponentMatched({
    required String name,
    required String avatar,
    required String rank,
    required String coins,
  }) {
    if (_opponentFound) return;
    _searchTimer?.cancel();

    setState(() {
      _opponentFound = true;
      _opponentName = name;
      _opponentAvatar = avatar;
      _opponentRank = rank;
      _opponentCoins = coins;
    });

    _sound.playVictory();

    Future.delayed(const Duration(milliseconds: 900), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => GameScreen(
            mode: GameMode.onlineMatch,
            difficulty: Difficulty.hard,
            roomCode: _roomCode,
            isHost: _isHost,
            opponentName: _opponentName,
            opponentAvatar: _opponentAvatar,
          ),
        ),
      );
    });
  }

  @override
  void dispose() {
    _searchTimer?.cancel();
    _opponentSub?.cancel();
    _radarController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF090E17),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0B1322),
              Color(0xFF090E18),
              Color(0xFF05080E),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Title Header: MATCHMAKING
                    Text(
                      AppStrings.matchmaking.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 3.0,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 32),

                    // Radar Sonar Scanner (Center)
                    SizedBox(
                      width: 240,
                      height: 240,
                      child: AnimatedBuilder(
                        animation: _radarController,
                        builder: (context, child) {
                          return CustomPaint(
                            painter: _RadarPainter(_radarController.value),
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 36),

                    // Player vs Opponent Status Row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Left: Sarah (Current User)
                        Column(
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF1E293B),
                                border: Border.all(color: const Color(0xFF22C55E), width: 2.5),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFF22C55E).withValues(alpha: 0.4),
                                    blurRadius: 12,
                                  ),
                                ],
                              ),
                              child: Center(
                                child: Text(_user.avatar, style: const TextStyle(fontSize: 28)),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              _user.name,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              'Rank ${_user.level}',
                              style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
                            ),
                            Text(
                              '🪙 ${_user.coins}',
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFFF3C35C),
                              ),
                            ),
                          ],
                        ),

                        // Center: Status Indicator
                        Column(
                          children: [
                            Text(
                              _opponentFound ? 'OPPONENT FOUND!' : 'FINDING\nOPPONENT...',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                                color: _opponentFound ? const Color(0xFF22C55E) : const Color(0xFFE2E8F0),
                              ),
                            ),
                          ],
                        ),

                        // Right: Opponent
                        Column(
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF1E293B),
                                border: Border.all(
                                  color: _opponentFound ? const Color(0xFFEF4444) : Colors.white24,
                                  width: 2.5,
                                ),
                                boxShadow: _opponentFound
                                    ? [
                                        BoxShadow(
                                          color: const Color(0xFFEF4444).withValues(alpha: 0.4),
                                          blurRadius: 12,
                                        ),
                                      ]
                                    : null,
                              ),
                              child: Center(
                                child: Text(
                                  _opponentFound ? _opponentAvatar : '👤',
                                  style: const TextStyle(fontSize: 28),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              _opponentFound ? _opponentName : 'Waiting...',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: _opponentFound ? Colors.white : const Color(0xFF64748B),
                              ),
                            ),
                            Text(
                              _opponentFound ? _opponentRank : '---',
                              style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
                            ),
                            Text(
                              _opponentFound ? _opponentCoins : '---',
                              style: const TextStyle(fontSize: 11, color: Color(0xFFF3C35C)),
                            ),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 32),

                    // Coin Wager Tag
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E293B).withValues(alpha: 0.7),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFFF3C35C).withValues(alpha: 0.5)),
                      ),
                      child: Text(
                        'COIN WAGER: 🪙 ${widget.wager}',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.0,
                          color: Color(0xFFF3C35C),
                        ),
                      ),
                    ),

                    const SizedBox(height: 36),

                    // Cancel Search (Red 'X' Button)
                    InkWell(
                      onTap: () {
                        _sound.playButtonClick();
                        _supabase.leaveGameRoom();
                        Navigator.of(context).pop();
                      },
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFFDC2626).withValues(alpha: 0.85),
                          border: Border.all(color: Colors.white30, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFDC2626).withValues(alpha: 0.4),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: const Icon(Icons.close_rounded, color: Colors.white, size: 28),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RadarPainter extends CustomPainter {
  final double sweepProgress;

  _RadarPainter(this.sweepProgress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Dark Radar Base
    final basePaint = Paint()
      ..color = const Color(0xFF041B10)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, radius, basePaint);

    // Concentric Green Circles
    final circlePaint = Paint()
      ..color = const Color(0xFF16A34A).withValues(alpha: 0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;

    for (double r = 0.25; r <= 1.0; r += 0.25) {
      canvas.drawCircle(center, radius * r, circlePaint);
    }

    // Crosshairs
    canvas.drawLine(Offset(center.dx - radius, center.dy), Offset(center.dx + radius, center.dy), circlePaint);
    canvas.drawLine(Offset(center.dx, center.dy - radius), Offset(center.dx, center.dy + radius), circlePaint);

    // Rotating Radar Beam
    final angle = sweepProgress * 2 * pi;
    final sweepPaint = Paint()
      ..shader = SweepGradient(
        center: Alignment.center,
        startAngle: angle - pi / 3,
        endAngle: angle,
        colors: [
          Colors.transparent,
          const Color(0xFF22C55E).withValues(alpha: 0.15),
          const Color(0xFF4ADE80).withValues(alpha: 0.75),
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, sweepPaint);

    // Leading Radar Line
    final linePaint = Paint()
      ..color = const Color(0xFF86EFAC)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    final endPoint = Offset(
      center.dx + radius * cos(angle),
      center.dy + radius * sin(angle),
    );
    canvas.drawLine(center, endPoint, linePaint);

    // Outer Glowing Border
    final borderPaint = Paint()
      ..color = const Color(0xFF22C55E)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;
    canvas.drawCircle(center, radius, borderPaint);
  }

  @override
  bool shouldRepaint(covariant _RadarPainter oldDelegate) => true;
}
