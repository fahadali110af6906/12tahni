import 'dart:async';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/points/points_service.dart';
import '../../core/settings/settings_service.dart';
import '../../core/supabase/supabase_service.dart';
import '../../models/difficulty.dart';
import '../../models/game_mode.dart';
import '../../models/game_move.dart';
import '../../models/player_type.dart';
import '../../models/user_profile.dart';
import '../../providers/game_controller.dart';
import '../widgets/difficulty_selector.dart';
import '../widgets/emoji_picker_modal.dart';
import '../widgets/floating_emoji_bubble.dart';
import '../widgets/game_board_view.dart';
import '../widgets/pause_dialog.dart';
import '../widgets/victory_celebration_dialog.dart';

class GameScreen extends StatefulWidget {
  final GameMode mode;
  final Difficulty difficulty;
  final String? roomCode;
  final bool isHost;
  final String opponentName;
  final String opponentAvatar;

  const GameScreen({
    super.key,
    required this.mode,
    required this.difficulty,
    this.roomCode,
    this.isHost = false,
    this.opponentName = 'Opponent',
    this.opponentAvatar = '👤',
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late GameController _controller;
  late ConfettiController _confettiController;
  late AnimationController _pulseController;
  final SoundService _sound = SoundService();
  final SettingsService _settings = SettingsService();
  final PointsService _pointsService = PointsService();
  final UserProfile _user = UserProfile();
  final SupabaseService _supabase = SupabaseService();

  StreamSubscription<GameMove>? _moveSub;
  StreamSubscription<String>? _emojiSub;
  StreamSubscription<void>? _resetSub;
  StreamSubscription<Map<String, dynamic>>? _presenceSub;
  late String _currentOpponentName;
  late String _currentOpponentAvatar;
  bool _dialogShown = false;

  @override
  void initState() {
    super.initState();
    _currentOpponentName = widget.opponentName;
    _currentOpponentAvatar = widget.opponentAvatar;

    final isOnline = (widget.mode == GameMode.onlineMatch || widget.mode == GameMode.playWithFriend) &&
        widget.roomCode != null;
    final myPlayerType = widget.isHost ? PlayerType.player2 : PlayerType.player1;

    _controller = GameController(
      initialMode: widget.mode,
      initialDifficulty: widget.difficulty,
      isRemoteMultiplayer: isOnline,
      localPlayerType: myPlayerType,
    );

    if (isOnline) {
      _controller.onMoveExecuted = (move) {
        _supabase.sendMove(move, isHost: widget.isHost);
      };

      _moveSub = _supabase.onOpponentMove.listen((move) {
        _controller.applyRemoteMove(move);
      });

      _emojiSub = _supabase.onOpponentEmoji.listen((emoji) {
        _controller.receiveRemoteEmoji(emoji);
      });

      _resetSub = _supabase.onGameReset.listen((_) {
        _dialogShown = false;
        _controller.restartGame();
      });

      _presenceSub = _supabase.onOpponentJoined.listen((data) {
        if (!mounted) return;
        final senderIsHost = data['isHost'] as bool? ?? false;
        if (senderIsHost != widget.isHost) {
          final name = data['name'] as String? ?? 'Friend';
          final avatar = data['avatar'] as String? ?? '👥';
          setState(() {
            _currentOpponentName = name;
            _currentOpponentAvatar = avatar;
          });

          if (widget.isHost) {
            _supabase.sendPresence(
              playerName: _user.name,
              playerAvatar: _user.avatar,
              isHost: true,
            );
          }
        }
      });
    }

    _controller.addListener(_onGameStateChanged);
    _settings.addListener(_onSettingsChanged);
    _pointsService.addListener(_onSettingsChanged);
    _user.addListener(_onSettingsChanged);

    _confettiController = ConfettiController(
      duration: const Duration(seconds: 3),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
  }

  void _onSettingsChanged() {
    if (mounted) setState(() {});
  }

  void _onGameStateChanged() {
    if (!mounted) return;

    // Trigger celebration & VictoryCelebrationDialog when game ends
    if (_controller.state.isGameOver && !_dialogShown) {
      _dialogShown = true;
      if (_controller.state.winner != null) {
        _confettiController.play();
        if (_controller.state.winner == PlayerType.player2) {
          _user.recordMatchWin(coinsWon: 200, xpGained: 50);
          _supabase.submitScore(
            playerName: _user.name,
            avatar: _user.avatar,
            wins: _user.wins,
            totalGames: _user.totalGames,
            coins: _user.coins,
          );
        } else {
          _user.recordMatchLoss(xpGained: 15);
        }
      }

      final p1Name = _controller.state.mode == GameMode.vsAi
          ? 'Computer'
          : (_controller.state.mode == GameMode.passAndPlay
              ? _settings.player1Name
              : _currentOpponentName);
      final p2Name = _controller.state.mode == GameMode.passAndPlay
          ? _settings.player2Name
          : _user.name;

      WidgetsBinding.instance.addPostFrameCallback((_) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => VictoryCelebrationDialog(
            winner: _controller.state.winner,
            p1PiecesRemaining: _controller.state.player1Pieces,
            p2PiecesRemaining: _controller.state.player2Pieces,
            p1Name: p1Name,
            p2Name: p2Name,
            onRematch: () {
              _dialogShown = false;
              if (widget.roomCode != null) {
                _supabase.sendGameReset();
              }
              _controller.restartGame();
            },
            onMainMenu: () {
              Navigator.of(context).pop();
            },
          ),
        );
      });
    }

    setState(() {});
  }

  @override
  void dispose() {
    _moveSub?.cancel();
    _emojiSub?.cancel();
    _resetSub?.cancel();
    _presenceSub?.cancel();
    if (widget.roomCode != null) {
      _supabase.leaveGameRoom();
    }
    _controller.removeListener(_onGameStateChanged);
    _settings.removeListener(_onSettingsChanged);
    _pointsService.removeListener(_onSettingsChanged);
    _user.removeListener(_onSettingsChanged);
    _controller.dispose();
    _confettiController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _showPauseDialog() {
    _sound.playButtonClick();
    _controller.pauseGame();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => PauseDialog(
        onResume: () => _controller.resumeGame(),
        onRestart: () {
          if (widget.roomCode != null) {
            _supabase.sendGameReset();
          }
          _controller.restartGame();
        },
        onHome: () => Navigator.of(context).pop(),
      ),
    );
  }

  void _showEmojiPicker() {
    _sound.playButtonClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => EmojiPickerModal(
        onEmojiSelected: (emoji) {
          final sender = (_controller.state.mode == GameMode.passAndPlay &&
                  _controller.state.currentTurn == PlayerType.player1)
              ? PlayerType.player1
              : PlayerType.player2;

          _controller.sendEmoji(sender, emoji);
          if (widget.roomCode != null) {
            _supabase.sendEmoji(emoji.emoji);
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = _controller.state;
    final isP1Turn = state.currentTurn == PlayerType.player1 && !state.isGameOver;
    final isP2Turn = state.currentTurn == PlayerType.player2 && !state.isGameOver;

    return Scaffold(
      backgroundColor: const Color(0xFF090E17),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.2,
            colors: [
              Color(0xFF2A1B12), // Warm ambient wood tone glow
              Color(0xFF140D08),
              Color(0xFF090E17),
            ],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 480),
                  child: Column(
                    children: [
                      // 1. Top HUD Bar (Close Button, Timer Chip, Opponent)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Close Button (X)
                            IconButton(
                              onPressed: _showPauseDialog,
                              icon: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.black45,
                                  border: Border.all(color: Colors.white24),
                                ),
                                child: const Icon(Icons.close_rounded, color: Colors.white70, size: 18),
                              ),
                            ),

                            // Room Code Pill (Middle, for Private / Online Match)
                            if (widget.roomCode != null)
                              InkWell(
                                onTap: () {
                                  _sound.playButtonClick();
                                  Clipboard.setData(ClipboardData(text: widget.roomCode!));
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text('Room Code ${widget.roomCode} copied! 📋'),
                                      backgroundColor: const Color(0xFF8B5CF6),
                                      duration: const Duration(seconds: 2),
                                    ),
                                  );
                                },
                                borderRadius: BorderRadius.circular(16),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF1E1B4B),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(color: const Color(0xFF8B5CF6), width: 1.2),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(Icons.vpn_key_rounded, size: 12, color: Color(0xFFC084FC)),
                                      const SizedBox(width: 4),
                                      Text(
                                        'ROOM ${widget.roomCode}',
                                        style: const TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1.0,
                                          color: Colors.white,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      const Icon(Icons.copy_rounded, size: 11, color: Color(0xFFC084FC)),
                                    ],
                                  ),
                                ),
                              ),

                            // Opponent Card (Top Right in Screen 5)
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                     Text(
                                       state.mode == GameMode.vsAi
                                           ? 'Computer'
                                           : state.mode == GameMode.passAndPlay
                                               ? _settings.player1Name
                                               : _currentOpponentName,
                                       style: const TextStyle(
                                         fontSize: 13,
                                         fontWeight: FontWeight.bold,
                                         color: Colors.white,
                                       ),
                                     ),
                                    Text(
                                      '${state.player1Pieces} beads',
                                      style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
                                    ),
                                  ],
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  width: 38,
                                  height: 38,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: const Color(0xFF1E293B),
                                    border: Border.all(
                                      color: isP1Turn ? const Color(0xFFEF4444) : Colors.white24,
                                      width: 2.0,
                                    ),
                                    boxShadow: isP1Turn
                                        ? [
                                            BoxShadow(
                                              color: const Color(0xFFEF4444).withValues(alpha: 0.5),
                                              blurRadius: 10,
                                            ),
                                          ]
                                        : null,
                                  ),
                                  child: Center(
                                    child: Text(
                                      state.mode == GameMode.vsAi
                                          ? '🤖'
                                          : state.mode == GameMode.passAndPlay
                                              ? '👤'
                                              : _currentOpponentAvatar,
                                      style: const TextStyle(fontSize: 18),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),

                      // Center Turn & Timer Chip
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isP2Turn ? const Color(0xFF22C55E) : const Color(0xFFEF4444),
                            width: 1.2,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.timer_outlined, size: 16, color: Color(0xFFF3C35C)),
                            const SizedBox(width: 6),
                            Text(
                              '${state.turnTimeRemaining}s',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                color: Color(0xFFF3C35C),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              isP2Turn ? 'Your Turn' : 'Waiting...',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: isP2Turn ? const Color(0xFF22C55E) : const Color(0xFFEF4444),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Floating Emoji Bubble (Top)
                      if (_controller.player1Emoji != null)
                        FloatingEmojiBubble(
                          key: ValueKey('p1_${_controller.player1Emoji!.id}_${DateTime.now().millisecondsSinceEpoch}'),
                          emoji: _controller.player1Emoji!,
                          isTopPlayer: true,
                        ),

                      // 2. Main 12 Tani Game Board (Wood Table & Glowing Path)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                          child: GameBoardView(
                            board: state.board,
                            selectedPoint: state.selectedPoint,
                            validMoves: state.validMovesForSelected,
                            lastMove: state.lastMove,
                            onPointTapped: (point) {
                              _controller.onPointTapped(point);
                            },
                          ),
                        ),
                      ),

                      // Floating Emoji Bubble (Bottom)
                      if (_controller.player2Emoji != null)
                        FloatingEmojiBubble(
                          key: ValueKey('p2_${_controller.player2Emoji!.id}_${DateTime.now().millisecondsSinceEpoch}'),
                          emoji: _controller.player2Emoji!,
                          isTopPlayer: false,
                        ),

                      // 3. Bottom HUD Bar (Player Avatar Left, Undo & Emoji Right)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Current Player Avatar Card (Sarah)
                            Row(
                              children: [
                                Container(
                                  width: 42,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: const Color(0xFF1E293B),
                                    border: Border.all(
                                      color: isP2Turn ? const Color(0xFF22C55E) : Colors.white24,
                                      width: 2.2,
                                    ),
                                    boxShadow: isP2Turn
                                        ? [
                                            BoxShadow(
                                              color: const Color(0xFF22C55E).withValues(alpha: 0.5),
                                              blurRadius: 10,
                                            ),
                                          ]
                                        : null,
                                  ),
                                  child: Center(
                                    child: Text(_user.avatar, style: const TextStyle(fontSize: 20)),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                     Text(
                                       state.mode == GameMode.passAndPlay
                                           ? _settings.player2Name
                                           : _user.name,
                                       style: const TextStyle(
                                         fontSize: 14,
                                         fontWeight: FontWeight.bold,
                                         color: Colors.white,
                                       ),
                                     ),
                                    Text(
                                      '${state.player2Pieces} beads left',
                                      style: const TextStyle(fontSize: 11, color: Color(0xFF94A3B8)),
                                    ),
                                  ],
                                ),
                              ],
                            ),

                            // Controls: Undo & Emoji Trigger
                            Row(
                              children: [
                                // Undo Button (-10 Points)
                                if (state.mode != GameMode.onlineMatch &&
                                    state.mode != GameMode.playWithFriend &&
                                    state.moveHistory.isNotEmpty &&
                                    !state.isAiThinking &&
                                    !state.isGameOver)
                                  InkWell(
                                    onTap: () {
                                      _sound.playButtonClick();
                                      _controller.undoMove();
                                    },
                                    borderRadius: BorderRadius.circular(16),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                      margin: const EdgeInsets.only(right: 8),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF1E293B),
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(color: const Color(0xFFF3C35C).withValues(alpha: 0.6)),
                                      ),
                                      child: Row(
                                        children: const [
                                          Icon(Icons.undo_rounded, color: Color(0xFFF3C35C), size: 16),
                                          SizedBox(width: 4),
                                          Text(
                                            '-10 🪙',
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFFF3C35C),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                // Emoji Picker Button (Matching Screen 4 & 5)
                                InkWell(
                                  onTap: _showEmojiPicker,
                                  borderRadius: BorderRadius.circular(22),
                                  child: Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: const LinearGradient(
                                        colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: const Color(0xFFF59E0B).withValues(alpha: 0.4),
                                          blurRadius: 10,
                                        ),
                                      ],
                                    ),
                                    child: const Center(
                                      child: Text('😄', style: TextStyle(fontSize: 22)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Confetti
              Align(
                alignment: Alignment.topCenter,
                child: ConfettiWidget(
                  confettiController: _confettiController,
                  blastDirectionality: BlastDirectionality.explosive,
                  shouldLoop: false,
                  colors: const [
                    Color(0xFF22C55E),
                    Color(0xFFF59E0B),
                    Color(0xFF00E5FF),
                    Colors.white,
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
