import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/points/points_service.dart';
import '../../core/settings/settings_service.dart';
import '../../models/difficulty.dart';
import '../../models/game_mode.dart';
import '../../models/user_profile.dart';
import '../widgets/daily_bonus_dialog.dart';
import '../widgets/difficulty_selector.dart';
import '../widgets/edit_profile_dialog.dart';
import '../widgets/friend_room_dialog.dart';
import '../widgets/lucky_spin_wheel_dialog.dart';
import '../widgets/rules_dialog.dart';
import '../widgets/settings_dialog.dart';
import 'game_screen.dart';
import 'leaderboard_screen.dart';
import 'matchmaking_screen.dart';
import 'shop_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final UserProfile _user = UserProfile();
  final SoundService _sound = SoundService();
  final SettingsService _settings = SettingsService();
  final PointsService _pointsService = PointsService();
  final ScrollController _scrollController = ScrollController();
  Difficulty _selectedDifficulty = Difficulty.medium;
  int _selectedCardIndex = 0; // 0: Online 1v1, 1: Vs Computer, 2: Pass & Play, 3: Tournaments

  @override
  void initState() {
    super.initState();
    _user.addListener(_onStateChanged);
    _settings.addListener(_onStateChanged);
    _pointsService.addListener(_onStateChanged);
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _user.removeListener(_onStateChanged);
    _settings.removeListener(_onStateChanged);
    _pointsService.removeListener(_onStateChanged);
    _scrollController.dispose();
    super.dispose();
  }

  void _onPlayNow() {
    _sound.playButtonClick();
    if (_selectedCardIndex == 0) {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => const MatchmakingScreen(wager: 200)),
      );
    } else if (_selectedCardIndex == 1) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => GameScreen(mode: GameMode.vsAi, difficulty: _selectedDifficulty),
        ),
      );
    } else if (_selectedCardIndex == 2) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => const GameScreen(mode: GameMode.passAndPlay, difficulty: Difficulty.medium),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (ctx) => const FriendRoomDialog(),
      );
    }
  }

  void _showDifficultySelector() {
    _sound.playButtonClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => DifficultySelectorModal(
        currentDifficulty: _selectedDifficulty,
        onDifficultySelected: (diff) {
          setState(() {
            _selectedDifficulty = diff;
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF090E17),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0F172A),
              Color(0xFF090E18),
              Color(0xFF05080E),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                children: [
                  // 1. Top Bar: Profile (Left) & Wallet / Settings (Right)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Profile Pill (Left)
                        InkWell(
                          onTap: () {
                            _sound.playButtonClick();
                            showDialog(
                              context: context,
                              builder: (ctx) => const EditProfileDialog(),
                            );
                          },
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1E293B),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFF334155)),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 28,
                                  height: 28,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFF0F172A),
                                  ),
                                  child: Center(
                                    child: Text(_user.avatar, style: const TextStyle(fontSize: 16)),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _user.name,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                const Icon(Icons.edit_rounded, size: 13, color: Color(0xFF94A3B8)),
                              ],
                            ),
                          ),
                        ),

                        // Wallet & Settings (Right)
                        Row(
                          children: [
                            // Coins Badge
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1E293B),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: const Color(0xFFF3C35C).withValues(alpha: 0.5)),
                              ),
                              child: Row(
                                children: [
                                  const Text('🪙', style: TextStyle(fontSize: 14)),
                                  const SizedBox(width: 4),
                                  Text(
                                    '${_user.coins}',
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFFACC15),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),

                            // Settings Button
                            IconButton(
                              onPressed: () {
                                _sound.playButtonClick();
                                showDialog(
                                  context: context,
                                  builder: (ctx) => const SettingsDialog(),
                                );
                              },
                              icon: Container(
                                padding: const EdgeInsets.all(7),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0xFF1E293B),
                                  border: Border.all(color: const Color(0xFF334155)),
                                ),
                                child: const Icon(Icons.settings_rounded, color: Color(0xFF94A3B8), size: 18),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // 2. Scrollable Middle Content (2x2 Mode Grid + Shortcuts)
                  Expanded(
                    child: Scrollbar(
                      controller: _scrollController,
                      thumbVisibility: true,
                      child: SingleChildScrollView(
                        controller: _scrollController,
                        physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Column(
                          children: [
                            // 2x2 Mode Grid (Matching Reference UI)
                            Row(
                              children: [
                                // Card 1: Online 1v1
                                Expanded(
                                  child: _buildModeGridTile(
                                    index: 0,
                                    title: 'Online 1v1',
                                    subtitle: '2,190 players',
                                    emoji: '🤼',
                                    accentColor: const Color(0xFF22C55E),
                                    onTap: () {
                                      setState(() => _selectedCardIndex = 0);
                                      _sound.playButtonClick();
                                      Navigator.of(context).push(
                                        MaterialPageRoute(builder: (context) => const MatchmakingScreen(wager: 200)),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(width: 14),

                                // Card 2: Vs Computer
                                Expanded(
                                  child: _buildModeGridTile(
                                    index: 1,
                                    title: 'Vs Computer',
                                    subtitle: '${_selectedDifficulty.labelUrdu} (70)',
                                    emoji: '💻',
                                    accentColor: const Color(0xFFE5A642),
                                    onTap: () {
                                      setState(() => _selectedCardIndex = 1);
                                      _showDifficultySelector();
                                    },
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),

                            Row(
                              children: [
                                // Card 3: Pass & Play
                                Expanded(
                                  child: _buildModeGridTile(
                                    index: 2,
                                    title: 'Pass & Play',
                                    subtitle: '40/15 players',
                                    emoji: '🤝',
                                    accentColor: const Color(0xFF00E5FF),
                                    onTap: () {
                                      setState(() => _selectedCardIndex = 2);
                                      _sound.playButtonClick();
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (context) => const GameScreen(
                                            mode: GameMode.passAndPlay,
                                            difficulty: Difficulty.medium,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                const SizedBox(width: 14),

                                // Card 4: Play with Friend (Private Room)
                                Expanded(
                                  child: _buildModeGridTile(
                                    index: 3,
                                    title: AppStrings.playWithFriend,
                                    subtitle: AppStrings.privateRoom,
                                    emoji: '👥',
                                    accentColor: const Color(0xFF8B5CF6),
                                    onTap: () {
                                      setState(() => _selectedCardIndex = 3);
                                      _sound.playButtonClick();
                                      showDialog(
                                        context: context,
                                        builder: (ctx) => const FriendRoomDialog(),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 16),

                            // Quick Dock (Shop, Leaderboard, Lucky Spin, Rules)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFF131D31),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: const Color(0xFF233554)),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  _buildDockIcon(
                                    icon: Icons.storefront_rounded,
                                    label: 'Shop',
                                    onTap: () {
                                      _sound.playButtonClick();
                                      Navigator.of(context).push(
                                        MaterialPageRoute(builder: (context) => const ShopScreen()),
                                      );
                                    },
                                  ),
                                  _buildDockIcon(
                                    icon: Icons.leaderboard_rounded,
                                    label: 'Ranking',
                                    onTap: () {
                                      _sound.playButtonClick();
                                      Navigator.of(context).push(
                                        MaterialPageRoute(builder: (context) => const LeaderboardScreen()),
                                      );
                                    },
                                  ),
                                  _buildDockIcon(
                                    icon: Icons.rotate_right_rounded,
                                    label: 'Spin',
                                    badge: _pointsService.isSpinAvailable() ? 'FREE' : null,
                                    onTap: () {
                                      _sound.playButtonClick();
                                      showDialog(
                                        context: context,
                                        builder: (ctx) => const LuckySpinWheelDialog(),
                                      );
                                    },
                                  ),
                                  _buildDockIcon(
                                    icon: Icons.card_giftcard_rounded,
                                    label: 'Bonus',
                                    badge: _pointsService.isDailyBonusAvailable() ? '!' : null,
                                    onTap: () {
                                      _sound.playButtonClick();
                                      showDialog(
                                        context: context,
                                        builder: (ctx) => const DailyBonusDialog(),
                                      );
                                    },
                                  ),
                                  _buildDockIcon(
                                    icon: Icons.menu_book_rounded,
                                    label: 'Rules',
                                    onTap: () {
                                      _sound.playButtonClick();
                                      showDialog(
                                        context: context,
                                        builder: (ctx) => const RulesDialog(),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 16),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // 3. Big Green PLAY NOW Button (Matching Mockup)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                    child: SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        onPressed: _onPlayNow,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF22C55E),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(27)),
                          elevation: 10,
                          shadowColor: const Color(0xFF22C55E).withValues(alpha: 0.5),
                        ),
                        child: const Text(
                          'PLAY NOW',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2.0,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModeGridTile({
    required int index,
    required String title,
    required String subtitle,
    required String emoji,
    required Color accentColor,
    required VoidCallback onTap,
  }) {
    final isSelected = _selectedCardIndex == index;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        constraints: const BoxConstraints(minHeight: 135),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF2C1E14),
              Color(0xFF1A120C),
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isSelected ? const Color(0xFF22C55E) : const Color(0xFF4A3423),
            width: isSelected ? 2.5 : 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.5),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
            if (isSelected)
              BoxShadow(
                color: const Color(0xFF22C55E).withValues(alpha: 0.3),
                blurRadius: 14,
              ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Center Illustration Sphere
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withValues(alpha: 0.35),
                    Colors.black.withValues(alpha: 0.8),
                  ],
                ),
                border: Border.all(color: accentColor.withValues(alpha: 0.6), width: 1.5),
              ),
              child: Center(
                child: Text(emoji, style: const TextStyle(fontSize: 24)),
              ),
            ),
            const SizedBox(height: 8),

            // Title
            Text(
              title,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: Color(0xFFF3C35C),
              ),
            ),
            const SizedBox(height: 2),

            // Subtitle
            Text(
              subtitle,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                color: Color(0xFF94A3B8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDockIcon({
    required IconData icon,
    required String label,
    String? badge,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(icon, color: const Color(0xFFF3C35C), size: 22),
                if (badge != null)
                  Positioned(
                    top: -6,
                    right: -10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                      decoration: BoxDecoration(
                        color: const Color(0xFF22C55E),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        badge,
                        style: const TextStyle(fontSize: 8, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF94A3B8)),
            ),
          ],
        ),
      ),
    );
  }
}
