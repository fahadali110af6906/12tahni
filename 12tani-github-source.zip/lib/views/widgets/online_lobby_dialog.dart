import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/settings/settings_service.dart';
import '../../models/difficulty.dart';
import '../../models/game_mode.dart';
import '../screens/game_screen.dart';

class OnlineLobbyDialog extends StatefulWidget {
  const OnlineLobbyDialog({super.key});

  @override
  State<OnlineLobbyDialog> createState() => _OnlineLobbyDialogState();
}

class _OnlineLobbyDialogState extends State<OnlineLobbyDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _radarController;
  final SoundService _sound = SoundService();
  final SettingsService _settings = SettingsService();

  bool _opponentFound = false;
  String _opponentName = '';
  String _opponentCountry = '🇵🇰';
  int _opponentRating = 1250;
  Timer? _searchTimer;
  Timer? _launchTimer;

  static const List<Map<String, String>> _sampleOpponents = [
    {'name': 'حمزہ خان', 'flag': '🇵🇰'},
    {'name': 'David Miller', 'flag': '🇬🇧'},
    {'name': 'रोहित शर्मा', 'flag': '🇮🇳'},
    {'name': 'عمر الشمري', 'flag': '🇸🇦'},
    {'name': 'সাকিব হাসান', 'flag': '🇧🇩'},
    {'name': 'بلال احمد', 'flag': '🇵🇰'},
    {'name': 'Alex Johnson', 'flag': '🇺🇸'},
  ];

  @override
  void initState() {
    super.initState();
    _radarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();

    _startMatchmaking();
  }

  void _startMatchmaking() {
    final random = Random();
    final delay = 2200 + random.nextInt(1800); // 2.2 to 4.0 seconds search
    _searchTimer = Timer(Duration(milliseconds: delay), () {
      if (!mounted) return;
      final opp = _sampleOpponents[random.nextInt(_sampleOpponents.length)];
      setState(() {
        _opponentFound = true;
        _opponentName = opp['name']!;
        _opponentCountry = opp['flag']!;
        _opponentRating = 1200 + random.nextInt(350);
      });

      _sound.playVictory();

      // Launch match after 1.4s
      _launchTimer = Timer(const Duration(milliseconds: 1400), () {
        if (!mounted) return;
        Navigator.of(context).pop();
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => const GameScreen(
              mode: GameMode.onlineMatch,
              difficulty: Difficulty.hard,
            ),
          ),
        );
      });
    });
  }

  @override
  void dispose() {
    _searchTimer?.cancel();
    _launchTimer?.cancel();
    _radarController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surfaceWoodDark,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.goldAccent, width: 2),
          boxShadow: [
            BoxShadow(
              color: AppColors.goldAccent.withValues(alpha: 0.25),
              blurRadius: 25,
              spreadRadius: 2,
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.8),
              blurRadius: 16,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(width: 32),
                Row(
                  children: [
                    const Icon(Icons.public_rounded, color: AppColors.goldAccent, size: 24),
                    const SizedBox(width: 8),
                    Text(
                      AppStrings.onlineMatch,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.goldAccent,
                      ),
                    ),
                  ],
                ),
                IconButton(
                  onPressed: () {
                    _sound.playButtonClick();
                    Navigator.of(context).pop();
                  },
                  icon: const Icon(Icons.close_rounded, color: AppColors.textMuted),
                ),
              ],
            ),
            const Divider(color: AppColors.cardBorder, height: 16),
            const SizedBox(height: 12),

            // Radar Animation or Opponent Found Card
            if (!_opponentFound) ...[
              SizedBox(
                width: 160,
                height: 160,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Radar Waves
                    AnimatedBuilder(
                      animation: _radarController,
                      builder: (context, child) {
                        return CustomPaint(
                          size: const Size(150, 150),
                          painter: _RadarPainter(progress: _radarController.value),
                        );
                      },
                    ),

                    // User Profile Center
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.surfaceWoodMedium,
                        border: Border.all(color: AppColors.goldAccent, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.goldAccent.withValues(alpha: 0.4),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          _settings.language.flag,
                          style: const TextStyle(fontSize: 26),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Text(
                AppStrings.searchingOnlineOpponent,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textLight,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.wifi_rounded, color: Colors.greenAccent, size: 16),
                  SizedBox(width: 6),
                  Text(
                    '⚡ Ping: 38ms • Global Server',
                    style: TextStyle(fontSize: 12, color: Colors.greenAccent),
                  ),
                ],
              ),
            ] else ...[
              // Opponent Found Card
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surfaceWoodMedium,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.greenAccent, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.greenAccent.withValues(alpha: 0.25),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 36),
                    const SizedBox(height: 8),
                    Text(
                      AppStrings.opponentFound,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.greenAccent,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(_opponentCountry, style: const TextStyle(fontSize: 24)),
                        const SizedBox(width: 8),
                        Text(
                          _opponentName,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textLight,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Rating: $_opponentRating 🏆',
                      style: const TextStyle(fontSize: 12, color: AppColors.goldAccent),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class _RadarPainter extends CustomPainter {
  final double progress;

  _RadarPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2;

    for (int i = 0; i < 3; i++) {
      final p = (progress + (i * 0.33)) % 1.0;
      final radius = p * maxRadius;
      final opacity = (1.0 - p).clamp(0.0, 1.0);

      final wavePaint = Paint()
        ..color = AppColors.goldAccent.withValues(alpha: opacity * 0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0;

      canvas.drawCircle(center, radius, wavePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RadarPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
