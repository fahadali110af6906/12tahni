import 'dart:async';
import 'dart:math';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/points/points_service.dart';

class LuckySpinWheelDialog extends StatefulWidget {
  const LuckySpinWheelDialog({super.key});

  @override
  State<LuckySpinWheelDialog> createState() => _LuckySpinWheelDialogState();
}

class _LuckySpinWheelDialogState extends State<LuckySpinWheelDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _spinController;
  late Animation<double> _spinAnimation;
  late ConfettiController _confettiController;
  final SoundService _sound = SoundService();
  final PointsService _pointsService = PointsService();
  Timer? _countdownTicker;

  // The 6 exact segments requested: 0, 5, 10, 20, 50, 100
  static const List<int> _segments = [0, 5, 10, 20, 50, 100];
  static const List<Color> _segmentColors = [
    Color(0xFF8B2500), // Crimson Rust (0 pts)
    Color(0xFF1B5E20), // Forest Emerald (5 pts)
    Color(0xFF0D47A1), // Royal Navy (10 pts)
    Color(0xFFE65100), // Amber Orange (20 pts)
    Color(0xFF4A148C), // Imperial Purple (50 pts)
    Color(0xFFFF8F00), // Jackpot Gold (100 pts)
  ];

  bool _isSpinning = false;
  int? _wonPoints;
  double _currentAngle = 0.0;
  double _targetAngle = 0.0;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 3));
    _spinController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    );

    _spinAnimation = CurvedAnimation(
      parent: _spinController,
      curve: Curves.easeOutCubic,
    );

    _spinController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _onSpinComplete();
      }
    });

    // 1-second live countdown ticker for 10-hour cooldown
    _countdownTicker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && !_pointsService.isSpinAvailable()) {
        setState(() {});
      }
    });
  }

  void _spinWheel() {
    if (_isSpinning || !_pointsService.isSpinAvailable()) return;

    _sound.playButtonClick();
    setState(() {
      _isSpinning = true;
      _wonPoints = null;
    });

    final random = Random();
    final winningIndex = random.nextInt(_segments.length);

    // Each segment is 60 degrees (2*pi / 6)
    final segmentAngle = (2 * pi) / _segments.length;

    final fullRotations = 5 + random.nextInt(4); // 5 to 8 full rotations
    final targetSegmentCenter = (winningIndex + 0.5) * segmentAngle;
    
    // Add small random jitter inside segment
    final jitter = (random.nextDouble() - 0.5) * (segmentAngle * 0.55);

    final finalRotation = (fullRotations * 2 * pi) + (3 * pi / 2) - targetSegmentCenter + jitter;

    _currentAngle = _targetAngle % (2 * pi);
    _targetAngle = _currentAngle + finalRotation;

    _spinAnimation = Tween<double>(
      begin: _currentAngle,
      end: _targetAngle,
    ).animate(CurvedAnimation(
      parent: _spinController,
      curve: Curves.easeOutCubic,
    ));

    _spinController.forward(from: 0.0);
  }

  Future<void> _onSpinComplete() async {
    // Calculate which segment landed under the top pointer
    final normalizedAngle = (_targetAngle % (2 * pi) + 2 * pi) % (2 * pi);
    final topAngle = (3 * pi / 2 - normalizedAngle + 2 * pi) % (2 * pi);
    final segmentAngle = (2 * pi) / _segments.length;
    final winningIndex = (topAngle / segmentAngle).floor() % _segments.length;
    final points = _segments[winningIndex];

    setState(() {
      _isSpinning = false;
      _wonPoints = points;
    });

    if (points > 0) {
      _confettiController.play();
      _sound.playVictory();
      await _pointsService.addPoints(points);
    } else {
      _sound.playInvalid();
    }

    // Record spin time to trigger 10-hour cooldown!
    await _pointsService.recordSpin();
  }

  String _formatRemainingTime(Duration duration) {
    final hours = duration.inHours.toString().padLeft(2, '0');
    final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  @override
  void dispose() {
    _countdownTicker?.cancel();
    _spinController.dispose();
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isAvailable = _pointsService.isSpinAvailable();
    final remainingTime = _pointsService.timeUntilNextSpin();

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.surfaceWoodDark,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.goldAccent, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: AppColors.goldAccent.withValues(alpha: 0.35),
              blurRadius: 25,
              spreadRadius: 3,
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.8),
              blurRadius: 16,
            ),
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header: Title & Close Button
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const SizedBox(width: 32),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.stars_rounded, color: AppColors.goldAccent, size: 24),
                        const SizedBox(width: 6),
                        Text(
                          AppStrings.luckySpin,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: AppColors.goldAccent,
                          ),
                        ),
                      ],
                    ),
                    IconButton(
                      onPressed: _isSpinning ? null : () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close_rounded, color: AppColors.textMuted),
                    ),
                  ],
                ),
                const SizedBox(height: 4),

                // Subtitle
                Text(
                  AppStrings.luckySpinDesc,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textLight,
                  ),
                ),
                const SizedBox(height: 14),

                // Spin Wheel Container with Top Pointer
                SizedBox(
                  width: 240,
                  height: 240,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Rotating Wheel
                      AnimatedBuilder(
                        animation: _spinAnimation,
                        builder: (context, child) {
                          return Transform.rotate(
                            angle: _spinAnimation.value,
                            child: CustomPaint(
                              size: const Size(230, 230),
                              painter: _WheelPainter(
                                segments: _segments,
                                colors: _segmentColors,
                              ),
                            ),
                          );
                        },
                      ),

                      // Center Golden Hub / Knob
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const RadialGradient(
                            colors: [Color(0xFFFFDF00), Color(0xFF8B6508)],
                          ),
                          border: Border.all(color: Colors.white, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.5),
                              blurRadius: 6,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.star_rounded,
                          color: Color(0xFF4A2800),
                          size: 26,
                        ),
                      ),

                      // Top Pointer / Ticker Needle
                      Positioned(
                        top: 0,
                        child: CustomPaint(
                          size: const Size(24, 30),
                          painter: _PointerPainter(),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Result announcement (if just spun)
                if (_wonPoints != null) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: _wonPoints! > 0
                          ? AppColors.goldAccent.withValues(alpha: 0.2)
                          : AppColors.surfaceWoodMedium,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _wonPoints! > 0 ? AppColors.goldAccent : Colors.white24,
                        width: 1.5,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _wonPoints! > 0 ? Icons.celebration : Icons.sentiment_neutral,
                          color: _wonPoints! > 0 ? AppColors.goldAccent : AppColors.textMuted,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _wonPoints! > 0
                              ? '${AppStrings.spinWonPoints} $_wonPoints ${AppStrings.points}! 🎉'
                              : AppStrings.spinWonZero,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: _wonPoints! > 0 ? AppColors.goldAccent : AppColors.textLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                ],

                // 10-Hour Cooldown Timer Notice (if unavailable)
                if (!isAvailable && !_isSpinning) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.amber.withValues(alpha: 0.4)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.timer_outlined, color: Colors.amber, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          '${AppStrings.nextSpinIn} ${_formatRemainingTime(remainingTime)}',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.amber,
                            letterSpacing: 1.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                ],

                // Action Button: Spin Wheel or Cooldown status
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: (isAvailable && !_isSpinning) ? _spinWheel : null,
                    icon: Icon(
                      _isSpinning
                          ? Icons.hourglass_top_rounded
                          : (isAvailable ? Icons.rotate_right_rounded : Icons.lock_clock_rounded),
                      size: 20,
                    ),
                    label: Text(
                      _isSpinning
                          ? AppStrings.spinning
                          : (isAvailable
                              ? AppStrings.spinNow
                              : '${AppStrings.nextSpinIn} ${_formatRemainingTime(remainingTime)}'),
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isAvailable ? AppColors.goldAccent : Colors.white12,
                      foregroundColor: isAvailable ? AppColors.textDark : Colors.white54,
                      disabledBackgroundColor: Colors.white10,
                      disabledForegroundColor: Colors.white38,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: isAvailable ? 6 : 0,
                    ),
                  ),
                ),
              ],
            ),

            // Confetti Blast on winning > 0
            Align(
              alignment: Alignment.topCenter,
              child: ConfettiWidget(
                confettiController: _confettiController,
                blastDirectionality: BlastDirectionality.explosive,
                maxBlastForce: 25,
                minBlastForce: 10,
                numberOfParticles: 40,
                gravity: 0.25,
                colors: const [
                  AppColors.goldAccent,
                  Colors.amber,
                  Colors.green,
                  Colors.purple,
                  Colors.white,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// CustomPainter for the 6-segment Luxury Wheel
class _WheelPainter extends CustomPainter {
  final List<int> segments;
  final List<Color> colors;

  _WheelPainter({required this.segments, required this.colors});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    final segmentAngle = (2 * pi) / segments.length;

    // Outer golden ring
    final outerRingPaint = Paint()
      ..color = const Color(0xFFD4AF37)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6;
    canvas.drawCircle(center, radius, outerRingPaint);

    final rect = Rect.fromCircle(center: center, radius: radius - 3);

    for (int i = 0; i < segments.length; i++) {
      final startAngle = i * segmentAngle;

      // Segment wedge
      final segmentPaint = Paint()
        ..color = colors[i % colors.length]
        ..style = PaintingStyle.fill;
      canvas.drawArc(rect, startAngle, segmentAngle, true, segmentPaint);

      // Segment divider line
      final dividerPaint = Paint()
        ..color = const Color(0xFFFFDF00).withValues(alpha: 0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0;
      canvas.drawLine(
        center,
        Offset(
          center.dx + (radius - 3) * cos(startAngle),
          center.dy + (radius - 3) * sin(startAngle),
        ),
        dividerPaint,
      );

      // Segment text
      final midAngle = startAngle + (segmentAngle / 2);
      final textRadius = radius * 0.65;
      final textOffset = Offset(
        center.dx + textRadius * cos(midAngle),
        center.dy + textRadius * sin(midAngle),
      );

      canvas.save();
      canvas.translate(textOffset.dx, textOffset.dy);
      canvas.rotate(midAngle + pi / 2);

      final textSpan = TextSpan(
        text: '${segments[i]}',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          shadows: [
            Shadow(
              color: Colors.black87,
              blurRadius: 4,
              offset: Offset(1, 2),
            ),
          ],
        ),
      );

      final textPainter = TextPainter(
        text: textSpan,
        textAlign: TextAlign.center,
        textDirection: TextDirection.ltr,
      )..layout();

      textPainter.paint(
        canvas,
        Offset(-textPainter.width / 2, -textPainter.height / 2),
      );

      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _WheelPainter oldDelegate) => false;
}

/// Pointer indicator at top of wheel
class _PointerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(size.width / 2, size.height)
      ..lineTo(0, 0)
      ..lineTo(size.width, 0)
      ..close();

    final fillPaint = Paint()
      ..color = const Color(0xFFFFD700)
      ..style = PaintingStyle.fill;

    final borderPaint = Paint()
      ..color = const Color(0xFF4A2800)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawShadow(path, Colors.black, 4, true);
    canvas.drawPath(path, fillPaint);
    canvas.drawPath(path, borderPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
