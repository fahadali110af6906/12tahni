import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/settings/settings_service.dart';
import '../../models/board_point.dart';
import '../../models/board_theme_type.dart';
import '../../models/game_move.dart';

class BoardPainter extends CustomPainter {
  final BoardPoint? selectedPoint;
  final List<GameMove> validMoves;
  final GameMove? lastMove;
  final double pulseValue;
  final BoardThemeType? theme;
  final bool? showHints;

  BoardPainter({
    this.selectedPoint,
    this.validMoves = const [],
    this.lastMove,
    this.pulseValue = 0.0,
    this.theme,
    this.showHints,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final settings = SettingsService();
    final currentTheme = theme ?? settings.boardTheme;
    final enableHints = showHints ?? settings.hintsEnabled;

    // Clean padding matching game board geometry
    final double padding = size.width * 0.075;
    final double playWidth = size.width - (padding * 2);
    final double cellSize = playWidth / 4.0;

    // Helper to calculate exact (x, y) coordinates for any (row, col)
    Offset getPointOffset(int row, int col) {
      return Offset(padding + col * cellSize, padding + row * cellSize);
    }

    // 1. Draw Clean Elegant Board Base
    final boardRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      const Radius.circular(22),
    );

    // Soft subtle shadow
    final shadowPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.4)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    canvas.drawRRect(boardRect.shift(const Offset(0, 4)), shadowPaint);

    // Smooth gradient base
    final boardPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: currentTheme.boardGradient,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRRect(boardRect, boardPaint);

    // Clean outer border inlay
    final borderPaint = Paint()
      ..color = currentTheme.lineColor.withValues(alpha: 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(padding * 0.3, padding * 0.3, size.width - padding * 0.6, size.height - padding * 0.6),
        const Radius.circular(16),
      ),
      borderPaint,
    );

    // 2. Simple, Crisp & Clean Grid Lines (5x5 Canonical 12 Tani / Baro Guti)
    final linePaint = Paint()
      ..color = currentTheme.lineColor.withValues(alpha: 0.85)
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    void drawLine(Offset p1, Offset p2) {
      canvas.drawLine(p1, p2, linePaint);
    }

    // 5 Horizontal Lines (rows 0, 1, 2, 3, 4)
    for (int r = 0; r < 5; r++) {
      drawLine(getPointOffset(r, 0), getPointOffset(r, 4));
    }

    // 5 Vertical Lines (cols 0, 1, 2, 3, 4)
    for (int c = 0; c < 5; c++) {
      drawLine(getPointOffset(0, c), getPointOffset(4, c));
    }

    // 2 Main Corner Diagonals
    drawLine(getPointOffset(0, 0), getPointOffset(4, 4));
    drawLine(getPointOffset(0, 4), getPointOffset(4, 0));

    // Midpoint Diamond Diagonals: (0,2) -> (2,0) -> (4,2) -> (2,4) -> (0,2)
    drawLine(getPointOffset(0, 2), getPointOffset(2, 0));
    drawLine(getPointOffset(2, 0), getPointOffset(4, 2));
    drawLine(getPointOffset(4, 2), getPointOffset(2, 4));
    drawLine(getPointOffset(2, 4), getPointOffset(0, 2));

    // 3. Draw Clean Point Intersection Sockets (25 points)
    final socketDotPaint = Paint()..color = Colors.black.withValues(alpha: 0.7);
    final socketRimPaint = Paint()
      ..color = currentTheme.lineColor.withValues(alpha: 0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3;

    for (int r = 0; r < 5; r++) {
      for (int c = 0; c < 5; c++) {
        final pos = getPointOffset(r, c);
        canvas.drawCircle(pos, 4.5, socketDotPaint);
        canvas.drawCircle(pos, 4.5, socketRimPaint);
      }
    }

    // 4. Highlight Last Move
    if (lastMove != null) {
      final fromPos = getPointOffset(lastMove!.from.row, lastMove!.from.col);
      final toPos = getPointOffset(lastMove!.to.row, lastMove!.to.col);

      final lastMoveLinePaint = Paint()
        ..color = currentTheme.lineColor.withValues(alpha: 0.45)
        ..strokeWidth = 3.0
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(fromPos, toPos, lastMoveLinePaint);

      final originPaint = Paint()
        ..color = currentTheme.lineColor.withValues(alpha: 0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;
      canvas.drawCircle(fromPos, 8.0, originPaint);
    }

    // 5. Selected Point Glow & Path Highlights (Matching Screen 4)
    if (selectedPoint != null) {
      final selPos = getPointOffset(selectedPoint!.row, selectedPoint!.col);

      // Glowing Path Line from selected bead to valid targets
      if (enableHints) {
        for (final move in validMoves) {
          final toPos = getPointOffset(move.to.row, move.to.col);
          final pathGlowPaint = Paint()
            ..color = const Color(0xFFF59E0B).withValues(alpha: 0.45 + 0.2 * sin(pulseValue * 2 * pi))
            ..strokeWidth = 5.5
            ..strokeCap = StrokeCap.round
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
          canvas.drawLine(selPos, toPos, pathGlowPaint);

          final pathCorePaint = Paint()
            ..color = const Color(0xFFFFE082)
            ..strokeWidth = 2.4
            ..strokeCap = StrokeCap.round;
          canvas.drawLine(selPos, toPos, pathCorePaint);
        }
      }

      final glowRadius = 13.0 + (sin(pulseValue * 2 * pi) * 1.6);

      final glowPaint = Paint()
        ..color = AppColors.selectedGlow.withValues(alpha: 0.35 + 0.15 * sin(pulseValue * 2 * pi))
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
      canvas.drawCircle(selPos, glowRadius, glowPaint);

      final ringPaint = Paint()
        ..color = AppColors.selectedGlow
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8;
      canvas.drawCircle(selPos, 12.0, ringPaint);
    }

    // 6. Valid Move Target Hints
    if (enableHints) {
      for (final move in validMoves) {
        final targetPos = getPointOffset(move.to.row, move.to.col);
        final targetColor = move.isJump ? AppColors.validJumpTarget : AppColors.validMoveTarget;

        final pulseRadius = 9.0 + (sin(pulseValue * 2 * pi) * 1.5);
        final haloPaint = Paint()
          ..color = targetColor.withValues(alpha: 0.3 + 0.15 * sin(pulseValue * 2 * pi))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);
        canvas.drawCircle(targetPos, pulseRadius, haloPaint);

        final targetRingPaint = Paint()
          ..color = targetColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5;
        canvas.drawCircle(targetPos, 7.0, targetRingPaint);

        final corePaint = Paint()..color = targetColor;
        canvas.drawCircle(targetPos, 3.0, corePaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant BoardPainter oldDelegate) {
    return oldDelegate.selectedPoint != selectedPoint ||
        oldDelegate.validMoves != validMoves ||
        oldDelegate.lastMove != lastMove ||
        oldDelegate.pulseValue != pulseValue ||
        oldDelegate.theme != theme ||
        oldDelegate.showHints != showHints;
  }
}
