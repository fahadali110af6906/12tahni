import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/supabase/supabase_service.dart';
import '../../models/difficulty.dart';
import '../../models/game_mode.dart';
import '../../models/user_profile.dart';
import '../screens/game_screen.dart';

class FriendRoomDialog extends StatefulWidget {
  const FriendRoomDialog({super.key});

  @override
  State<FriendRoomDialog> createState() => _FriendRoomDialogState();
}

class _FriendRoomDialogState extends State<FriendRoomDialog>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final SoundService _sound = SoundService();
  final UserProfile _user = UserProfile();
  final SupabaseService _supabase = SupabaseService();

  late String _generatedRoomCode;
  final TextEditingController _joinCodeController = TextEditingController();

  StreamSubscription<Map<String, dynamic>>? _opponentSub;
  String? _joinedFriendName;
  String? _joinedFriendAvatar;
  bool _isNavigating = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _generatedRoomCode = '${1000 + Random().nextInt(9000)}';
    _initHostRoom();
  }

  void _initHostRoom() {
    _opponentSub?.cancel();
    _supabase.joinGameRoom(
      roomCode: _generatedRoomCode,
      playerName: _user.name,
      playerAvatar: _user.avatar,
      isHost: true,
    );

    _opponentSub = _supabase.onOpponentJoined.listen((data) {
      if (!mounted || _isNavigating) return;
      final isGuest = (data['isHost'] as bool?) == false;
      if (isGuest) {
        _sound.playVictory();
        final name = data['name'] as String? ?? 'Friend';
        final avatar = data['avatar'] as String? ?? '👥';

        setState(() {
          _joinedFriendName = name;
          _joinedFriendAvatar = avatar;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🎉 $name joined the room! Starting match...'),
            backgroundColor: const Color(0xFF22C55E),
            duration: const Duration(seconds: 2),
          ),
        );

        _isNavigating = true;
        Future.delayed(const Duration(milliseconds: 900), () {
          if (!mounted) return;
          Navigator.of(context).pop();
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => GameScreen(
                mode: GameMode.playWithFriend,
                difficulty: Difficulty.hard,
                roomCode: _generatedRoomCode,
                isHost: true,
                opponentName: name,
                opponentAvatar: avatar,
              ),
            ),
          );
        });
      }
    });
  }

  @override
  void dispose() {
    _opponentSub?.cancel();
    _tabController.dispose();
    _joinCodeController.dispose();
    super.dispose();
  }

  void _regenerateCode() {
    _sound.playButtonClick();
    setState(() {
      _generatedRoomCode = '${1000 + Random().nextInt(9000)}';
      _joinedFriendName = null;
      _joinedFriendAvatar = null;
    });
    _initHostRoom();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Generated new Room Code: $_generatedRoomCode'),
        backgroundColor: const Color(0xFF1E293B),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _copyRoomCode() {
    _sound.playButtonClick();
    Clipboard.setData(ClipboardData(text: _generatedRoomCode));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(AppStrings.codeCopied),
        backgroundColor: const Color(0xFF22C55E),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _shareInvitation() {
    _sound.playButtonClick();
    final invitation =
        'Join my 12 Tani (12 ٹہنی) private match! 🎯\nRoom Code: $_generatedRoomCode\nOpen the game, select "Play with Friend" and enter code: $_generatedRoomCode';
    Clipboard.setData(ClipboardData(text: invitation));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Invitation copied! Send it to your friend on WhatsApp or SMS. 📤'),
        backgroundColor: Color(0xFF8B5CF6),
        duration: Duration(seconds: 3),
      ),
    );
  }

  Future<void> _pasteFromClipboard() async {
    _sound.playButtonClick();
    final data = await Clipboard.getData('text/plain');
    if (data != null && data.text != null) {
      final text = data.text!.trim();
      final digits = RegExp(r'\d{4}').firstMatch(text)?.group(0);
      if (digits != null) {
        _joinCodeController.text = digits;
      } else if (text.length == 4) {
        _joinCodeController.text = text;
      }
    }
  }

  void _startHostMatch() {
    if (_isNavigating) return;
    _isNavigating = true;
    _sound.playButtonClick();

    Navigator.of(context).pop();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => GameScreen(
          mode: GameMode.playWithFriend,
          difficulty: Difficulty.hard,
          roomCode: _generatedRoomCode,
          isHost: true,
          opponentName: _joinedFriendName ?? 'Waiting for friend...',
          opponentAvatar: _joinedFriendAvatar ?? '⏳',
        ),
      ),
    );
  }

  void _joinFriendMatch() {
    final code = _joinCodeController.text.trim();
    if (code.length < 4) {
      _sound.playInvalid();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.enterRoomCode),
          backgroundColor: AppColors.errorRed,
        ),
      );
      return;
    }

    _sound.playButtonClick();
    _opponentSub?.cancel();

    _supabase.joinGameRoom(
      roomCode: code,
      playerName: _user.name,
      playerAvatar: _user.avatar,
      isHost: false,
    );

    Navigator.of(context).pop();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => GameScreen(
          mode: GameMode.playWithFriend,
          difficulty: Difficulty.hard,
          roomCode: code,
          isHost: false,
          opponentName: 'Room Host',
          opponentAvatar: '👑',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1E1B4B),
                  Color(0xFF0F172A),
                  Color(0xFF090E17),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: const Color(0xFF8B5CF6), width: 2),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF8B5CF6).withValues(alpha: 0.3),
                  blurRadius: 28,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.8),
                  blurRadius: 18,
                ),
              ],
            ),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF8B5CF6).withValues(alpha: 0.2),
                                border: Border.all(color: const Color(0xFF8B5CF6)),
                              ),
                              child: const Text('👥', style: TextStyle(fontSize: 18)),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    AppStrings.playWithFriend,
                                    style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    AppStrings.privateRoom,
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: Color(0xFFC084FC),
                                      fontWeight: FontWeight.w600,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          _sound.playButtonClick();
                          Navigator.of(context).pop();
                        },
                        icon: const Icon(Icons.close_rounded, color: Colors.white70, size: 20),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Tab Selector
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F172A),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF334155)),
                    ),
                    child: TabBar(
                      controller: _tabController,
                      indicator: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF8B5CF6), Color(0xFF7C3AED)],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF8B5CF6).withValues(alpha: 0.4),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      indicatorSize: TabBarIndicatorSize.tab,
                      labelColor: Colors.white,
                      unselectedLabelColor: const Color(0xFF94A3B8),
                      labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                      tabs: [
                        Tab(
                          icon: const Icon(Icons.add_circle_outline_rounded, size: 16),
                          text: AppStrings.createRoom,
                        ),
                        Tab(
                          icon: const Icon(Icons.login_rounded, size: 16),
                          text: AppStrings.joinRoom,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Tab Views Container
                  SizedBox(
                    height: 250,
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        // Tab 1: Create Room
                        _buildCreateRoomTab(),

                        // Tab 2: Join Room
                        _buildJoinRoomTab(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCreateRoomTab() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          AppStrings.roomCode.toUpperCase(),
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            color: Color(0xFFC084FC),
          ),
        ),
        const SizedBox(height: 8),

        // Glowing Room Code Box
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFF3C35C), width: 2),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFF3C35C).withValues(alpha: 0.3),
                blurRadius: 18,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _generatedRoomCode,
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 8,
                  color: Color(0xFFF3C35C),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                onPressed: _regenerateCode,
                icon: const Icon(Icons.refresh_rounded, color: Colors.white70, size: 20),
                tooltip: 'New PIN',
                constraints: const BoxConstraints(),
                padding: const EdgeInsets.all(4),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),

        // Copy & Share Actions Row
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            OutlinedButton.icon(
              onPressed: _copyRoomCode,
              icon: const Icon(Icons.copy_rounded, size: 14, color: AppColors.goldAccent),
              label: Text(
                AppStrings.copyCode,
                style: const TextStyle(fontSize: 12, color: AppColors.goldAccent, fontWeight: FontWeight.bold),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.goldAccent),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: _shareInvitation,
              icon: const Icon(Icons.share_rounded, size: 14, color: Colors.white),
              label: Text(
                AppStrings.share,
                style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF8B5CF6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),

        // Live Radar / Waiting Status
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              width: 14,
              height: 14,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFC084FC)),
              ),
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                _joinedFriendName != null
                    ? '🎉 $_joinedFriendName connected!'
                    : AppStrings.waitingForFriend,
                style: TextStyle(
                  fontSize: 12,
                  color: _joinedFriendName != null ? const Color(0xFF22C55E) : const Color(0xFF94A3B8),
                  fontWeight: FontWeight.w600,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Enter Match / Play Now Button
        SizedBox(
          width: double.infinity,
          height: 44,
          child: ElevatedButton.icon(
            onPressed: _startHostMatch,
            icon: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
            label: Text(
              _joinedFriendName != null ? 'START MATCH NOW' : 'ENTER ROOM (LOBBY)',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
                color: Colors.white,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _joinedFriendName != null ? const Color(0xFF22C55E) : const Color(0xFF8B5CF6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              elevation: 4,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildJoinRoomTab() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          AppStrings.enterRoomCode,
          style: const TextStyle(fontSize: 13, color: Color(0xFF94A3B8), fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),

        // PIN Input with Paste Button
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 180,
              child: TextField(
                controller: _joinCodeController,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 4,
                onSubmitted: (_) => _joinFriendMatch(),
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 8,
                  color: Colors.white,
                ),
                decoration: InputDecoration(
                  counterText: '',
                  hintText: '----',
                  hintStyle: const TextStyle(color: Colors.white24, letterSpacing: 8),
                  filled: true,
                  fillColor: Colors.black.withValues(alpha: 0.5),
                  contentPadding: const EdgeInsets.symmetric(vertical: 8),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: Color(0xFF334155)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: Color(0xFF00E5FF), width: 2),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: _pasteFromClipboard,
              icon: const Icon(Icons.paste_rounded, color: Color(0xFF00E5FF)),
              tooltip: AppStrings.paste,
              style: IconButton.styleFrom(
                backgroundColor: const Color(0xFF0F172A),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Color(0xFF334155)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // Join Button
        SizedBox(
          width: double.infinity,
          height: 46,
          child: ElevatedButton.icon(
            onPressed: _joinFriendMatch,
            icon: const Icon(Icons.login_rounded, color: Colors.black, size: 20),
            label: Text(
              AppStrings.joinRoom.toUpperCase(),
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
                color: Colors.black,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF00E5FF),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              elevation: 4,
              shadowColor: const Color(0xFF00E5FF).withValues(alpha: 0.4),
            ),
          ),
        ),
      ],
    );
  }
}
