import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/settings/settings_service.dart';

class PauseDialog extends StatefulWidget {
  final VoidCallback onResume;
  final VoidCallback onRestart;
  final VoidCallback onHome;

  const PauseDialog({
    super.key,
    required this.onResume,
    required this.onRestart,
    required this.onHome,
  });

  @override
  State<PauseDialog> createState() => _PauseDialogState();
}

class _PauseDialogState extends State<PauseDialog> {
  final SoundService _sound = SoundService();
  final SettingsService _settings = SettingsService();
  double _musicVolume = 0.8;
  double _sfxVolume = 1.0;

  @override
  void initState() {
    super.initState();
    _sfxVolume = _sound.soundEnabled ? 1.0 : 0.0;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF131D31),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: const Color(0xFF2A3D63), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.8),
                  blurRadius: 25,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Title: GAME PAUSED
                  Text(
                    AppStrings.gamePaused.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.0,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Resume Game Button (Brown/Gold Rounded Capsule)
                  InkWell(
                    onTap: () {
                      _sound.playButtonClick();
                      Navigator.of(context).pop();
                      widget.onResume();
                    },
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: double.infinity,
                      height: 46,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFFB8782E),
                            Color(0xFF7E4A16),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFF3C35C), width: 1.5),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        AppStrings.resume.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 18),

                  // "How to Play" Section with 3 Visual Diagrams
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      AppStrings.rules,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFE2E8F0),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0C1424),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF1E2E4E)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildRuleDiagram(
                          title: 'Clear',
                          icon: Icons.all_inclusive_rounded,
                          painter: _ClearDiagramPainter(),
                        ),
                        Container(width: 1, height: 50, color: const Color(0xFF1E2E4E)),
                        _buildRuleDiagram(
                          title: 'Move',
                          icon: Icons.arrow_forward_rounded,
                          painter: _MoveDiagramPainter(),
                        ),
                        Container(width: 1, height: 50, color: const Color(0xFF1E2E4E)),
                        _buildRuleDiagram(
                          title: 'Jump',
                          icon: Icons.u_turn_right_rounded,
                          painter: _JumpDiagramPainter(),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  // "Audio Settings" Section
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Audio Settings',
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFE2E8F0),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0C1424),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFF1E2E4E)),
                    ),
                    child: Column(
                      children: [
                        // Music Slider
                        Row(
                          children: [
                            const Text(
                              'Music',
                              style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                            ),
                            const SizedBox(width: 8),
                            const Icon(Icons.volume_mute_rounded, size: 16, color: Color(0xFF94A3B8)),
                            Expanded(
                              child: SliderTheme(
                                data: SliderTheme.of(context).copyWith(
                                  trackHeight: 4,
                                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                                  activeTrackColor: const Color(0xFFE5A642),
                                  inactiveTrackColor: const Color(0xFF1E2E4E),
                                  thumbColor: const Color(0xFFF3C35C),
                                ),
                                child: Slider(
                                  value: _musicVolume,
                                  onChanged: (val) {
                                    setState(() {
                                      _musicVolume = val;
                                    });
                                  },
                                ),
                              ),
                            ),
                            const Icon(Icons.volume_up_rounded, size: 16, color: Color(0xFF94A3B8)),
                          ],
                        ),

                        // SFX Slider
                        Row(
                          children: [
                            const Text(
                              'SFX   ',
                              style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                            ),
                            const SizedBox(width: 8),
                            const Icon(Icons.volume_mute_rounded, size: 16, color: Color(0xFF94A3B8)),
                            Expanded(
                              child: SliderTheme(
                                data: SliderTheme.of(context).copyWith(
                                  trackHeight: 4,
                                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                                  activeTrackColor: const Color(0xFFE5A642),
                                  inactiveTrackColor: const Color(0xFF1E2E4E),
                                  thumbColor: const Color(0xFFF3C35C),
                                ),
                                child: Slider(
                                  value: _sfxVolume,
                                  onChanged: (val) {
                                    setState(() {
                                      _sfxVolume = val;
                                      _sound.toggleSound();
                                      _settings.setSoundEnabled(_sfxVolume > 0);
                                    });
                                  },
                                ),
                              ),
                            ),
                            const Icon(Icons.volume_up_rounded, size: 16, color: Color(0xFF94A3B8)),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  // Quit Match Button (Red-Brown Capsule)
                  InkWell(
                    onTap: () {
                      _sound.playButtonClick();
                      Navigator.of(context).pop();
                      widget.onHome();
                    },
                    borderRadius: BorderRadius.circular(24),
                    child: Container(
                      width: double.infinity,
                      height: 46,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF991B1B),
                            Color(0xFF5F1010),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: const Color(0xFFEF4444).withValues(alpha: 0.7), width: 1.5),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        AppStrings.quit.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRuleDiagram({
    required String title,
    required IconData icon,
    required CustomPainter painter,
  }) {
    return Column(
      children: [
        SizedBox(
          width: 60,
          height: 46,
          child: CustomPaint(painter: painter),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.bold,
            color: Color(0xFF94A3B8),
          ),
        ),
      ],
    );
  }
}

// 1. Clear Line Diagram
class _ClearDiagramPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF94A3B8)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final dotPaint = Paint()
      ..color = const Color(0xFFF3C35C)
      ..style = PaintingStyle.fill;

    final emptyDotPaint = Paint()
      ..color = const Color(0xFF334155)
      ..style = PaintingStyle.fill;

    final cy = size.height / 2;
    canvas.drawLine(Offset(10, cy), Offset(size.width - 10, cy), paint);
    canvas.drawLine(Offset(size.width / 2, 5), Offset(size.width / 2, size.height - 5), paint);

    canvas.drawCircle(Offset(12, cy), 4.5, dotPaint);
    canvas.drawCircle(Offset(size.width / 2, cy), 4.5, emptyDotPaint);
    canvas.drawCircle(Offset(size.width - 12, cy), 4.5, dotPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// 2. Move Diagram
class _MoveDiagramPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF94A3B8)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final arrowPaint = Paint()
      ..color = const Color(0xFF22C55E)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    final dotPaint = Paint()
      ..color = const Color(0xFFEF4444)
      ..style = PaintingStyle.fill;

    final targetPaint = Paint()
      ..color = const Color(0xFF22C55E)
      ..style = PaintingStyle.fill;

    final cy = size.height / 2;
    canvas.drawLine(Offset(10, cy), Offset(size.width - 10, cy), paint);
    canvas.drawLine(Offset(size.width / 2, 5), Offset(size.width / 2, size.height - 5), paint);

    canvas.drawCircle(Offset(12, cy), 4.5, dotPaint);
    canvas.drawCircle(Offset(size.width / 2, cy), 5.5, targetPaint);

    // Arrow to center
    canvas.drawLine(Offset(18, cy), Offset(size.width / 2 - 7, cy), arrowPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// 3. Jump Diagram
class _JumpDiagramPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF94A3B8)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final arcPaint = Paint()
      ..color = const Color(0xFFF3C35C)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    final playerDot = Paint()..color = const Color(0xFF22C55E);
    final opponentDot = Paint()..color = const Color(0xFFEF4444);
    final landingDot = Paint()..color = const Color(0xFFF3C35C);

    final cy = size.height / 2;
    canvas.drawLine(Offset(8, cy), Offset(size.width - 8, cy), paint);

    canvas.drawCircle(Offset(10, cy), 4, playerDot);
    canvas.drawCircle(Offset(size.width / 2, cy), 4, opponentDot);
    canvas.drawCircle(Offset(size.width - 10, cy), 5, landingDot);

    // Jump Arc
    final arcPath = Path();
    arcPath.moveTo(10, cy - 4);
    arcPath.quadraticBezierTo(size.width / 2, cy - 22, size.width - 10, cy - 4);
    canvas.drawPath(arcPath, arcPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
