import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/settings/settings_service.dart';
import '../../models/game_mode.dart';
import '../../models/player_type.dart';

class GameOverDialog extends StatelessWidget {
  final PlayerType? winner;
  final GameMode mode;
  final int totalMoves;
  final int p1Remaining;
  final int p2Remaining;
  final bool isTimeoutVictory;
  final VoidCallback onRematch;
  final VoidCallback onHome;

  const GameOverDialog({
    super.key,
    required this.winner,
    required this.mode,
    required this.totalMoves,
    required this.p1Remaining,
    required this.p2Remaining,
    this.isTimeoutVictory = false,
    required this.onRematch,
    required this.onHome,
  });

  @override
  Widget build(BuildContext context) {
    final settings = SettingsService();
    final isPlayer2Winner = winner == PlayerType.player2;
    final isVsAi = mode == GameMode.vsAi;

    final p1Name = isVsAi ? AppStrings.computer : settings.player1Name;
    final p2Name = settings.player2Name;

    String title;
    String message;
    Color themeColor;
    IconData icon;

    if (winner == null) {
      title = AppStrings.drawTitle;
      message = 'دونوں کھلاڑیوں کا کھیل زبردست رہا!';
      themeColor = AppColors.goldAccent;
      icon = Icons.handshake_rounded;
    } else if (isTimeoutVictory) {
      if (isVsAi) {
        if (isPlayer2Winner) {
          title = AppStrings.timeoutVictoryTitle;
          message = 'مبارک ہو! کمپیوٹر کے ۵ بار وقت ختم ہونے پر $p2Name جیت گئے! 🏆';
          themeColor = settings.player2Color.glowColor;
          icon = Icons.timer_off_rounded;
        } else {
          title = AppStrings.timeoutDefeatTitle;
          message = 'آپ کا وقت ۵ بار ختم ہو گیا، کمپیوٹر جیت گیا۔ 😔';
          themeColor = settings.player1Color.primaryColor;
          icon = Icons.timer_off_rounded;
        }
      } else {
        title = AppStrings.timeoutVictoryTitle;
        final loserName = isPlayer2Winner ? p1Name : p2Name;
        final winnerName = isPlayer2Winner ? p2Name : p1Name;
        message = '$loserName کے ۵ بار وقت ختم ہونے پر $winnerName فاتح قرار پائے! 🏆';
        themeColor = isPlayer2Winner
            ? settings.player2Color.glowColor
            : settings.player1Color.glowColor;
        icon = Icons.timer_off_rounded;
      }
    } else if (isVsAi) {
      if (isPlayer2Winner) {
        title = AppStrings.victoryTitle;
        message = 'مبارک ہو! $p2Name جیت گئے!';
        themeColor = settings.player2Color.glowColor;
        icon = Icons.emoji_events_rounded;
      } else {
        title = AppStrings.defeatTitle;
        message = AppStrings.computerWon;
        themeColor = settings.player1Color.primaryColor;
        icon = Icons.sentiment_dissatisfied_rounded;
      }
    } else {
      title = AppStrings.victoryTitle;
      final winnerName = isPlayer2Winner ? p2Name : p1Name;
      message = '$winnerName شاندار انداز میں جیت گیا!';
      themeColor = isPlayer2Winner
          ? settings.player2Color.glowColor
          : settings.player1Color.glowColor;
      icon = Icons.military_tech_rounded;
    }

    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surfaceWoodDark,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: themeColor, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: themeColor.withValues(alpha: 0.3),
              blurRadius: 24,
              spreadRadius: 4,
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.8),
              blurRadius: 16,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Big Trophy / Icon
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: themeColor.withValues(alpha: 0.15),
                border: Border.all(color: themeColor, width: 2),
              ),
              child: Icon(icon, size: 56, color: themeColor),
            ),
            const SizedBox(height: 16),

            // Title
            Text(
              title,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: themeColor,
              ),
            ),
            const SizedBox(height: 8),

            // Message
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16,
                color: AppColors.textLight,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 18),

            // Stats Summary
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.cardBorder, width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStatItem('کل چالیں', '$totalMoves'),
                  Container(width: 1, height: 28, color: AppColors.cardBorder),
                  _buildStatItem(
                    '$p1Name کے مہرے',
                    '$p1Remaining',
                    color: settings.player1Color.lightColor,
                  ),
                  Container(width: 1, height: 28, color: AppColors.cardBorder),
                  _buildStatItem(
                    '$p2Name کے مہرے',
                    '$p2Remaining',
                    color: settings.player2Color.lightColor,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),

            // Action Buttons
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  SoundService().playButtonClick();
                  Navigator.of(context).pop();
                  onRematch();
                },
                icon: const Icon(Icons.refresh_rounded),
                label: Text(AppStrings.rematch),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.goldAccent,
                  foregroundColor: AppColors.textDark,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  SoundService().playButtonClick();
                  Navigator.of(context).pop();
                  onHome();
                },
                icon: const Icon(Icons.home_rounded),
                label: Text(AppStrings.home),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.textLight,
                  side: const BorderSide(color: AppColors.cardBorder, width: 1.5),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, {Color? color}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: color ?? AppColors.goldAccent,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 11,
            color: AppColors.textMuted,
          ),
        ),
      ],
    );
  }
}
