import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/points/points_service.dart';

class DailyBonusDialog extends StatefulWidget {
  const DailyBonusDialog({super.key});

  @override
  State<DailyBonusDialog> createState() => _DailyBonusDialogState();
}

class _DailyBonusDialogState extends State<DailyBonusDialog> {
  late ConfettiController _confettiController;
  final SoundService _sound = SoundService();
  final PointsService _pointsService = PointsService();
  bool _claimed = false;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 3));
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  Future<void> _claimReward() async {
    _sound.playVictory();
    _confettiController.play();
    await _pointsService.claimDailyBonus();
    setState(() {
      _claimed = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final canClaim = _pointsService.isDailyBonusAvailable() && !_claimed;

    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surfaceWoodDark,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.goldAccent, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: AppColors.goldAccent.withValues(alpha: 0.35),
              blurRadius: 24,
              spreadRadius: 3,
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.8),
              blurRadius: 16,
            ),
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Gift Box Icon
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [Color(0xFFFFDF00), Color(0xFF8B6508)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.amber.withValues(alpha: 0.5),
                        blurRadius: 15,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.card_giftcard_rounded,
                    size: 56,
                    color: Color(0xFF3E1C00),
                  ),
                ),
                const SizedBox(height: 18),

                // Title
                Text(
                  AppStrings.dailyBonusTitle,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: AppColors.goldAccent,
                  ),
                ),
                const SizedBox(height: 8),

                // Description
                Text(
                  canClaim
                      ? AppStrings.dailyBonusDesc
                      : (_claimed ? AppStrings.dailyBonusClaimed : AppStrings.dailyBonusAlreadyClaimed),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    color: AppColors.textLight,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 20),

                // Reward Card
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.goldAccent.withValues(alpha: 0.6)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.monetization_on, color: Colors.amber, size: 28),
                      const SizedBox(width: 10),
                      Text(
                        '+100 ${AppStrings.points}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppColors.goldAccent,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Action Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: canClaim ? _claimReward : () => Navigator.of(context).pop(),
                    icon: Icon(canClaim ? Icons.check_circle_rounded : Icons.thumb_up_rounded),
                    label: Text(
                      canClaim
                          ? AppStrings.claimDailyBonus
                          : (_claimed ? AppStrings.confirm : AppStrings.confirm),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.goldAccent,
                      foregroundColor: AppColors.textDark,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Confetti
            Align(
              alignment: Alignment.topCenter,
              child: ConfettiWidget(
                confettiController: _confettiController,
                blastDirectionality: BlastDirectionality.explosive,
                maxBlastForce: 25,
                minBlastForce: 10,
                numberOfParticles: 40,
                gravity: 0.25,
                colors: const [
                  AppColors.goldAccent,
                  Colors.amber,
                  Colors.green,
                  Colors.white,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
