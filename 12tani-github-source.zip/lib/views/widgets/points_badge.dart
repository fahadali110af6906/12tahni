import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/points/points_service.dart';

class PointsBadge extends StatelessWidget {
  final VoidCallback? onTap;
  final bool showAddButton;

  const PointsBadge({
    super.key,
    this.onTap,
    this.showAddButton = false,
  });

  @override
  Widget build(BuildContext context) {
    final pointsService = PointsService();

    return AnimatedBuilder(
      animation: pointsService,
      builder: (context, _) {
        return InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF2A1C10), Color(0xFF1E140C)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.goldAccent.withValues(alpha: 0.7),
                width: 1.4,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppColors.goldAccent.withValues(alpha: 0.25),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Glowing Gold Coin Icon
                Container(
                  padding: const EdgeInsets.all(3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [Color(0xFFFFDF00), Color(0xFFB8860B)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.amber.withValues(alpha: 0.6),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.monetization_on,
                    size: 15,
                    color: Color(0xFF4A2800),
                  ),
                ),
                const SizedBox(width: 6),

                // Animated Points Number
                Text(
                  '${pointsService.points}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: AppColors.goldAccent,
                    letterSpacing: 0.5,
                  ),
                ),

                if (showAddButton) ...[
                  const SizedBox(width: 5),
                  const Icon(
                    Icons.add_circle,
                    size: 15,
                    color: AppColors.goldAccent,
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
