import 'dart:math';
import 'package:flutter/material.dart';
import '../../models/board_point.dart';
import '../../models/game_move.dart';
import '../../models/player_type.dart';
import 'board_painter.dart';
import 'piece_widget.dart';

class GameBoardView extends StatefulWidget {
  final List<PlayerType?> board;
  final BoardPoint? selectedPoint;
  final List<GameMove> validMoves;
  final GameMove? lastMove;
  final ValueChanged<BoardPoint> onPointTapped;

  const GameBoardView({
    super.key,
    required this.board,
    this.selectedPoint,
    this.validMoves = const [],
    this.lastMove,
    required this.onPointTapped,
  });

  @override
  State<GameBoardView> createState() => _GameBoardViewState();
}

class _GameBoardViewState extends State<GameBoardView>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Slightly reduced, elegant and comfortable board & piece size
        final availableSize = min(constraints.maxWidth, constraints.maxHeight);
        final boardSize = availableSize * 0.86;

        final double padding = boardSize * 0.075;
        final double playWidth = boardSize - (padding * 2);
        final double cellSize = playWidth / 4.0;
        final double pieceSize = cellSize * 0.52; // Refined, slightly smaller goti size

        return AnimatedBuilder(
          animation: _pulseController,
          builder: (context, child) {
            return Center(
              child: SizedBox(
                width: boardSize,
                height: boardSize,
                child: Stack(
                  children: [
                    // Clean, simplified board lines
                    Positioned.fill(
                      child: CustomPaint(
                        painter: BoardPainter(
                          selectedPoint: widget.selectedPoint,
                          validMoves: widget.validMoves,
                          lastMove: widget.lastMove,
                          pulseValue: _pulseController.value,
                        ),
                      ),
                    ),

                    // Interactive touch areas & larger 3D Piece Widgets (25 points)
                    for (int r = 0; r < 5; r++)
                      for (int c = 0; c < 5; c++) ...[
                        _buildPointWidget(
                          row: r,
                          col: c,
                          padding: padding,
                          cellSize: cellSize,
                          pieceSize: pieceSize,
                        ),
                      ],
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildPointWidget({
    required int row,
    required int col,
    required double padding,
    required double cellSize,
    required double pieceSize,
  }) {
    final point = BoardPoint(row, col);
    final piece = widget.board[point.index];
    final isSelected = widget.selectedPoint == point;
    final isTarget = widget.validMoves.any((m) => m.to == point);

    final centerX = padding + col * cellSize;
    final centerY = padding + row * cellSize;

    return Positioned(
      left: centerX - cellSize * 0.49,
      top: centerY - cellSize * 0.49,
      width: cellSize * 0.98,
      height: cellSize * 0.98,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => widget.onPointTapped(point),
        child: Center(
          child: piece != null
              ? PieceWidget(
                  player: piece,
                  size: pieceSize,
                  isSelected: isSelected,
                  isTarget: isTarget,
                  pulseValue: _pulseController.value,
                )
              : const SizedBox.shrink(),
        ),
      ),
    );
  }
}
