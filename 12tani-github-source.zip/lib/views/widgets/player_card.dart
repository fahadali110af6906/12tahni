import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/constants/game_constants.dart';
import '../../core/settings/settings_service.dart';
import '../../models/game_mode.dart';
import '../../models/player_type.dart';
import '../../models/user_profile.dart';
import 'piece_widget.dart';

class PlayerCard extends StatelessWidget {
  final PlayerType player;
  final GameMode mode;
  final int piecesRemaining;
  final bool isCurrentTurn;
  final bool isAiThinking;
  final double pulseValue;
  final int turnTimeRemaining;
  final int timeoutStrikes;

  const PlayerCard({
    super.key,
    required this.player,
    required this.mode,
    required this.piecesRemaining,
    required this.isCurrentTurn,
    this.isAiThinking = false,
    this.pulseValue = 0.0,
    this.turnTimeRemaining = 10,
    this.timeoutStrikes = 0,
  });

  @override
  Widget build(BuildContext context) {
    final settings = SettingsService();
    final user = UserProfile();
    final isPlayer1 = player == PlayerType.player1;
    final isAi = isPlayer1 && mode == GameMode.vsAi;

    final name = isAi
        ? AppStrings.computer
        : (isPlayer1 && mode == GameMode.onlineMatch)
            ? 'حمزہ خان'
            : (isPlayer1 && mode == GameMode.playWithFriend)
                ? 'دوست (Friend)'
                : isPlayer1
                    ? settings.player1Name
                    : (mode == GameMode.passAndPlay ? settings.player2Name : user.name);

    final colorOption = isPlayer1 ? settings.player1Color : settings.player2Color;
    final glowColor = colorOption.glowColor;

    final isUrgent = isCurrentTurn && turnTimeRemaining <= 3;
    final timerColor = isUrgent
        ? AppColors.errorRed
        : (isCurrentTurn ? const Color(0xFFFF9100) : AppColors.textMuted);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: isCurrentTurn
            ? AppColors.surfaceWoodLight.withValues(alpha: 0.92)
            : AppColors.surfaceWoodDark.withValues(alpha: 0.7),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isUrgent
              ? AppColors.errorRed
              : (isCurrentTurn ? glowColor : AppColors.cardBorder.withValues(alpha: 0.5)),
          width: isCurrentTurn ? 1.8 : 1.0,
        ),
        boxShadow: isCurrentTurn
            ? [
                BoxShadow(
                  color: (isUrgent ? AppColors.errorRed : glowColor)
                      .withValues(alpha: 0.3 + 0.15 * sin(pulseValue * 2 * pi)),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ]
            : [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.25),
                  blurRadius: 4,
                ),
              ],
      ),
      child: Row(
        children: [
          // Player Avatar / Bead Representation
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: isCurrentTurn ? glowColor : AppColors.goldAccent.withValues(alpha: 0.4),
                width: 1.2,
              ),
              color: Colors.black.withValues(alpha: 0.3),
            ),
            child: PieceWidget(
              player: player,
              size: 26,
              isSelected: isCurrentTurn,
              pulseValue: pulseValue,
            ),
          ),
          const SizedBox(width: 10),

          // Player Name & Turn Status + 5 Timeout Strike Indicators
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: isCurrentTurn ? AppColors.goldAccent : AppColors.textLight,
                        ),
                      ),
                    ),
                    if (isAi && isAiThinking) ...[
                      const SizedBox(width: 8),
                      const SizedBox(
                        width: 11,
                        height: 11,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(AppColors.goldAccent),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(
                      isCurrentTurn
                          ? (isAiThinking ? AppStrings.computerTurn : AppStrings.yourTurn)
                          : '${AppStrings.beadsLeft}: $piecesRemaining / 12',
                      style: TextStyle(
                        fontSize: 11,
                        color: isCurrentTurn ? glowColor : AppColors.textMuted,
                        fontWeight: isCurrentTurn ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                    const SizedBox(width: 8),

                    // 5 Timeout Strike Dots
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(GameConstants.maxTimeoutStrikes, (index) {
                        final isStrikeUsed = index < timeoutStrikes;
                        return Container(
                          margin: const EdgeInsets.only(left: 2),
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isStrikeUsed
                                ? AppColors.errorRed
                                : Colors.white.withValues(alpha: 0.2),
                            border: Border.all(
                              color: isStrikeUsed
                                  ? AppColors.errorRed
                                  : Colors.white.withValues(alpha: 0.35),
                              width: 0.8,
                            ),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Circular Countdown Timer Ring (Screen 4 reference UI style)
          if (isCurrentTurn) ...[
            Container(
              width: 38,
              height: 38,
              margin: const EdgeInsets.only(right: 4),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: turnTimeRemaining / GameConstants.turnTimerSeconds,
                    strokeWidth: 3.0,
                    backgroundColor: Colors.white12,
                    valueColor: AlwaysStoppedAnimation<Color>(timerColor),
                  ),
                  Text(
                    '${turnTimeRemaining}s',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: timerColor,
                    ),
                  ),
                ],
              ),
            ),
          ],

          // Captured mini-beads badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  '$piecesRemaining',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: glowColor,
                  ),
                ),
                const SizedBox(width: 3),
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: glowColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
