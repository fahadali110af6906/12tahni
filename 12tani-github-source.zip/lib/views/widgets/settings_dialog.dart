import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../core/settings/settings_service.dart';
import '../../models/app_language.dart';
import '../../models/board_theme_type.dart';
import '../../models/piece_color_theme.dart';
import '../../models/piece_style.dart';
import '../../models/player_type.dart';
import '../../models/user_profile.dart';
import 'piece_widget.dart';

class SettingsDialog extends StatefulWidget {
  const SettingsDialog({super.key});

  @override
  State<SettingsDialog> createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  final SettingsService _settings = SettingsService();
  final SoundService _sound = SoundService();
  final UserProfile _user = UserProfile();

  late TextEditingController _p1Controller;
  late TextEditingController _p2Controller;

  @override
  void initState() {
    super.initState();
    _p1Controller = TextEditingController(text: _settings.player1Name);
    _p2Controller = TextEditingController(
      text: _settings.player2Name.isNotEmpty ? _settings.player2Name : _user.name,
    );
  }

  @override
  void dispose() {
    _saveNames();
    _p1Controller.dispose();
    _p2Controller.dispose();
    super.dispose();
  }

  void _saveNames() {
    final p1 = _p1Controller.text.trim();
    final p2 = _p2Controller.text.trim();
    if (p1.isNotEmpty) {
      _settings.setPlayer1Name(p1);
    }
    if (p2.isNotEmpty) {
      _settings.setPlayer2Name(p2);
      _user.setName(p2);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.surfaceWoodDark,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.goldAccent, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.8),
              blurRadius: 20,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(width: 32),
                Row(
                  children: [
                    const Icon(Icons.settings_rounded, color: AppColors.goldAccent, size: 24),
                    const SizedBox(width: 8),
                    Text(
                      AppStrings.settingsTitle,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.goldAccent,
                      ),
                    ),
                  ],
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close, color: AppColors.textMuted),
                ),
              ],
            ),
            const Divider(color: AppColors.cardBorder, height: 16),

            // Scrollable Settings Content
            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 0. Language Selection Section
                    _buildSectionHeader(AppStrings.languageTitle, Icons.language_rounded),
                    const SizedBox(height: 8),
                    _buildLanguageSelector(),
                    const SizedBox(height: 18),

                    // 1. Player Names Section
                    _buildSectionHeader(AppStrings.playerNamesSection, Icons.badge_rounded),
                    const SizedBox(height: 8),
                    _buildNameField(
                      label: AppStrings.player1NameLabel,
                      controller: _p1Controller,
                      hint: AppStrings.player1NameHint,
                      onChanged: (val) => _settings.setPlayer1Name(val),
                    ),
                    const SizedBox(height: 10),
                    _buildNameField(
                      label: AppStrings.player2NameLabel,
                      controller: _p2Controller,
                      hint: AppStrings.player2NameHint,
                      onChanged: (val) {
                        _settings.setPlayer2Name(val);
                        _user.setName(val);
                      },
                    ),
                    const SizedBox(height: 18),

                    // 2. Piece Colors Section
                    _buildSectionHeader(AppStrings.beadColorsSection, Icons.palette_rounded),
                    const SizedBox(height: 10),
                    _buildColorPickerSection(
                      title: AppStrings.player1ColorTitle,
                      selectedColor: _settings.player1Color,
                      player: PlayerType.player1,
                      onColorSelected: (c) {
                        _sound.playButtonClick();
                        setState(() => _settings.setPlayer1Color(c));
                      },
                    ),
                    const SizedBox(height: 12),
                    _buildColorPickerSection(
                      title: AppStrings.player2ColorTitle,
                      selectedColor: _settings.player2Color,
                      player: PlayerType.player2,
                      onColorSelected: (c) {
                        _sound.playButtonClick();
                        setState(() => _settings.setPlayer2Color(c));
                      },
                    ),
                    const SizedBox(height: 18),

                    // 3. Piece Designs / Styles Section
                    _buildSectionHeader(AppStrings.pieceStylesSection, Icons.auto_awesome_rounded),
                    const SizedBox(height: 10),
                    _buildStylePickerSection(
                      title: AppStrings.player1StyleTitle,
                      selectedStyle: _settings.player1Style,
                      player: PlayerType.player1,
                      onStyleSelected: (s) {
                        _sound.playButtonClick();
                        setState(() => _settings.setPlayer1Style(s));
                      },
                    ),
                    const SizedBox(height: 12),
                    _buildStylePickerSection(
                      title: AppStrings.player2StyleTitle,
                      selectedStyle: _settings.player2Style,
                      player: PlayerType.player2,
                      onStyleSelected: (s) {
                        _sound.playButtonClick();
                        setState(() => _settings.setPlayer2Style(s));
                      },
                    ),
                    const SizedBox(height: 18),

                    // 4. Board Themes Section
                    _buildSectionHeader(AppStrings.boardThemeSection, Icons.dashboard_customize_rounded),
                    const SizedBox(height: 10),
                    _buildBoardThemeSelector(),
                    const SizedBox(height: 18),

                    // 5. Audio, Haptics & Gameplay
                    _buildSectionHeader(AppStrings.audioGameplaySection, Icons.tune_rounded),
                    const SizedBox(height: 8),
                    _buildSwitchTile(
                      title: AppStrings.soundEffects,
                      subtitle: AppStrings.soundEffectsDesc,
                      value: _settings.soundEnabled,
                      icon: Icons.volume_up_rounded,
                      onChanged: (val) {
                        setState(() {
                          _settings.setSoundEnabled(val);
                          _sound.soundEnabled = val;
                        });
                      },
                    ),
                    _buildSwitchTile(
                      title: AppStrings.vibration,
                      subtitle: AppStrings.vibrationDesc,
                      value: _settings.hapticsEnabled,
                      icon: Icons.vibration_rounded,
                      onChanged: (val) {
                        setState(() => _settings.setHapticsEnabled(val));
                      },
                    ),
                    _buildSwitchTile(
                      title: AppStrings.moveHints,
                      subtitle: AppStrings.moveHintsDesc,
                      value: _settings.hintsEnabled,
                      icon: Icons.lightbulb_outline_rounded,
                      onChanged: (val) {
                        setState(() => _settings.setHintsEnabled(val));
                      },
                    ),
                    _buildSwitchTile(
                      title: AppStrings.fastAi,
                      subtitle: AppStrings.fastAiDesc,
                      value: _settings.fastAiEnabled,
                      icon: Icons.speed_rounded,
                      onChanged: (val) {
                        setState(() => _settings.setFastAiEnabled(val));
                      },
                    ),
                    const SizedBox(height: 14),

                    const SizedBox(height: 18),

                    // Save & Apply Settings Button
                    SizedBox(
                      width: double.infinity,
                      height: 46,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          _sound.playButtonClick();
                          _saveNames();
                          Navigator.of(context).pop();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Settings & Player names saved! ✨'),
                              backgroundColor: Color(0xFF22C55E),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF22C55E),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 6,
                          shadowColor: const Color(0xFF22C55E).withValues(alpha: 0.4),
                        ),
                        icon: const Icon(Icons.check_circle_rounded, color: Colors.white, size: 18),
                        label: Text(
                          AppStrings.save.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Reset Defaults Button
                    Center(
                      child: TextButton.icon(
                        onPressed: () {
                          _sound.playButtonClick();
                          _settings.resetToDefaults();
                          _p1Controller.text = _settings.player1Name;
                          _p2Controller.text = _settings.player2Name;
                          setState(() {});
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(AppStrings.resetSuccessNotice),
                              backgroundColor: AppColors.surfaceWoodDark,
                              duration: const Duration(seconds: 2),
                            ),
                          );
                        },
                        icon: const Icon(Icons.restore_rounded, color: AppColors.errorRed, size: 18),
                        label: Text(
                          AppStrings.resetSettings,
                          style: const TextStyle(color: AppColors.errorRed, fontSize: 13),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: AppColors.goldAccent, size: 18),
        const SizedBox(width: 6),
        Text(
          title,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: AppColors.goldAccent,
          ),
        ),
      ],
    );
  }

  Widget _buildLanguageSelector() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: AppLanguage.values.map((lang) {
        final isSelected = _settings.language == lang;
        return InkWell(
          onTap: () {
            _sound.playButtonClick();
            setState(() {
              _settings.setLanguage(lang);
              _p1Controller.text = _settings.player1Name;
              _p2Controller.text = _settings.player2Name;
            });
          },
          borderRadius: BorderRadius.circular(12),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: isSelected
                  ? AppColors.goldAccent.withValues(alpha: 0.25)
                  : AppColors.surfaceWoodMedium,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? AppColors.goldAccent : AppColors.cardBorder,
                width: isSelected ? 1.8 : 1.0,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(lang.flag, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 6),
                Text(
                  lang.nativeName,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: isSelected ? AppColors.goldAccent : AppColors.textLight,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildNameField({
    required String label,
    required TextEditingController controller,
    required String hint,
    required ValueChanged<String> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.goldAccent),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          onChanged: onChanged,
          onSubmitted: onChanged,
          style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
            filled: true,
            fillColor: Colors.black.withValues(alpha: 0.4),
            prefixIcon: const Icon(Icons.person_outline_rounded, color: AppColors.goldAccent, size: 18),
            suffixIcon: IconButton(
              icon: const Icon(Icons.clear_rounded, color: Colors.white38, size: 16),
              onPressed: () {
                controller.clear();
                onChanged('');
              },
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppColors.cardBorder),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppColors.goldAccent, width: 1.5),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildColorPickerSection({
    required String title,
    required PieceColorOption selectedColor,
    required PlayerType player,
    required ValueChanged<PieceColorOption> onColorSelected,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 12, color: AppColors.textLight),
        ),
        const SizedBox(height: 6),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: PieceColorOption.values.map((opt) {
              final isSelected = opt == selectedColor;
              return Padding(
                padding: const EdgeInsets.only(left: 8),
                child: InkWell(
                  onTap: () => onColorSelected(opt),
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? opt.glowColor.withValues(alpha: 0.25)
                          : Colors.black.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? opt.glowColor : Colors.white12,
                        width: isSelected ? 2.0 : 1.0,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 22,
                          height: 22,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [opt.lightColor, opt.primaryColor],
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          opt.label,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: isSelected ? opt.lightColor : AppColors.textMuted,
                          ),
                        ),
                        const SizedBox(width: 4),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildStylePickerSection({
    required String title,
    required PieceStyle selectedStyle,
    required PlayerType player,
    required ValueChanged<PieceStyle> onStyleSelected,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 12, color: AppColors.textLight),
        ),
        const SizedBox(height: 6),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: PieceStyle.values.map((style) {
              final isSelected = style == selectedStyle;
              return Padding(
                padding: const EdgeInsets.only(left: 8),
                child: InkWell(
                  onTap: () => onStyleSelected(style),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    width: 82,
                    padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.goldAccent.withValues(alpha: 0.2)
                          : Colors.black.withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected ? AppColors.goldAccent : Colors.white12,
                        width: isSelected ? 2.0 : 1.0,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        PieceWidget(
                          player: player,
                          size: 30,
                          isSelected: isSelected,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          style.label,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: isSelected ? AppColors.goldAccent : AppColors.textLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildBoardThemeSelector() {
    return Row(
      children: BoardThemeType.values.map((theme) {
        final isSelected = theme == _settings.boardTheme;
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: InkWell(
              onTap: () {
                _sound.playButtonClick();
                setState(() => _settings.setBoardTheme(theme));
              },
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: theme.boardGradient,
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? AppColors.goldAccent : Colors.white24,
                    width: isSelected ? 2.2 : 1.0,
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isSelected ? Icons.check_circle : Icons.circle_outlined,
                      color: isSelected ? AppColors.goldAccent : Colors.white54,
                      size: 16,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      theme.label,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        color: isSelected ? AppColors.goldAccent : Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSwitchTile({
    required String title,
    required String subtitle,
    required bool value,
    required IconData icon,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: AppColors.goldAccent, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textLight),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            activeThumbColor: AppColors.goldAccent,
            onChanged: (val) {
              _sound.playButtonClick();
              onChanged(val);
            },
          ),
        ],
      ),
    );
  }
}
