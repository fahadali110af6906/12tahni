import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';

class RulesDialog extends StatelessWidget {
  const RulesDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: AppColors.surfaceWoodDark,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.goldAccent, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              blurRadius: 20,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(width: 32),
                Text(
                  AppStrings.rulesTitle,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.goldAccent,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close, color: AppColors.textMuted),
                ),
              ],
            ),
            const Divider(color: AppColors.cardBorder, height: 16),

            // Scrollable Content
            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    _buildRuleCard(
                      icon: Icons.grid_view_rounded,
                      title: AppStrings.rule1Title,
                      desc: AppStrings.rule1Desc,
                      accentColor: AppColors.goldAccent,
                    ),
                    const SizedBox(height: 10),

                    _buildRuleCard(
                      icon: Icons.alt_route_rounded,
                      title: AppStrings.rule2Title,
                      desc: AppStrings.rule2Desc,
                      accentColor: AppColors.player2Glow,
                    ),
                    const SizedBox(height: 10),

                    _buildRuleCard(
                      icon: Icons.pan_tool_alt_rounded,
                      title: AppStrings.rule3Title,
                      desc: AppStrings.rule3Desc,
                      accentColor: AppColors.player1Glow,
                    ),
                    const SizedBox(height: 10),

                    _buildRuleCard(
                      icon: Icons.bolt_rounded,
                      title: AppStrings.rule4Title,
                      desc: AppStrings.rule4Desc,
                      accentColor: AppColors.validJumpTarget,
                    ),
                    const SizedBox(height: 10),

                    _buildRuleCard(
                      icon: Icons.emoji_events_rounded,
                      title: AppStrings.rule5Title,
                      desc: AppStrings.rule5Desc,
                      accentColor: AppColors.goldAccent,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Got it button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.goldAccent,
                  foregroundColor: AppColors.textDark,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  AppStrings.confirm,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRuleCard({
    required IconData icon,
    required String title,
    required String desc,
    required Color accentColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accentColor.withOpacity(0.4), width: 1.2),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, size: 22, color: accentColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  desc,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textLight,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
