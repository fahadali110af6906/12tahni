import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_colors.dart';
import '../../core/constants/app_strings.dart';
import '../../models/difficulty.dart';

class DifficultySelectorModal extends StatelessWidget {
  final Difficulty currentDifficulty;
  final ValueChanged<Difficulty> onDifficultySelected;

  const DifficultySelectorModal({
    super.key,
    required this.currentDifficulty,
    required this.onDifficultySelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: const BoxDecoration(
        color: AppColors.surfaceWoodDark,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(color: AppColors.goldAccent, width: 2),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.cardBorder,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),

          Text(
            AppStrings.difficulty,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.goldAccent,
            ),
          ),
          const SizedBox(height: 16),

          _buildOption(
            context: context,
            difficulty: Difficulty.easy,
            color: AppColors.player2Glow,
            icon: Icons.sentiment_satisfied_rounded,
          ),
          const SizedBox(height: 10),

          _buildOption(
            context: context,
            difficulty: Difficulty.medium,
            color: AppColors.amberAccent,
            icon: Icons.psychology_rounded,
          ),
          const SizedBox(height: 10),

          _buildOption(
            context: context,
            difficulty: Difficulty.hard,
            color: AppColors.player1Glow,
            icon: Icons.local_fire_department_rounded,
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  Widget _buildOption({
    required BuildContext context,
    required Difficulty difficulty,
    required Color color,
    required IconData icon,
  }) {
    final isSelected = currentDifficulty == difficulty;

    return InkWell(
      onTap: () {
        SoundService().playButtonClick();
        onDifficultySelected(difficulty);
        Navigator.of(context).pop();
      },
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: isSelected
              ? color.withOpacity(0.18)
              : AppColors.cardBackground,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? color : AppColors.cardBorder,
            width: isSelected ? 2.0 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.2),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    difficulty.labelUrdu,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: isSelected ? color : AppColors.textLight,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    difficulty.descriptionUrdu,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(Icons.check_circle_rounded, color: color, size: 24),
          ],
        ),
      ),
    );
  }
}
