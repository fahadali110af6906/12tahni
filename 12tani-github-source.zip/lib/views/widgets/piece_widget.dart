import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/settings/settings_service.dart';
import '../../models/piece_color_theme.dart';
import '../../models/piece_style.dart';
import '../../models/player_type.dart';

class PieceWidget extends StatelessWidget {
  final PlayerType player;
  final double size;
  final bool isSelected;
  final bool isTarget;
  final double pulseValue;
  final PieceColorOption? customColor;
  final PieceStyle? customStyle;

  const PieceWidget({
    super.key,
    required this.player,
    this.size = 38.0,
    this.isSelected = false,
    this.isTarget = false,
    this.pulseValue = 0.0,
    this.customColor,
    this.customStyle,
  });

  @override
  Widget build(BuildContext context) {
    final settings = SettingsService();
    final isPlayer1 = player == PlayerType.player1;

    final colorOption = customColor ??
        (isPlayer1 ? settings.player1Color : settings.player2Color);
    final style = customStyle ??
        (isPlayer1 ? settings.player1Style : settings.player2Style);

    final primaryColor = colorOption.primaryColor;
    final lightColor = colorOption.lightColor;
    final darkColor = colorOption.darkColor;
    final glowColor = colorOption.glowColor;

    final scale = isSelected ? 1.12 + 0.04 * sin(pulseValue * 2 * pi) : 1.0;

    return Transform.scale(
      scale: scale,
      child: SizedBox(
        width: size,
        height: size,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Glow if Selected
            if (isSelected)
              Container(
                width: size * 1.25,
                height: size * 1.25,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: glowColor.withValues(alpha: 0.65),
                      blurRadius: 16,
                      spreadRadius: 3,
                    ),
                  ],
                ),
              ),

            // Drop Shadow
            Container(
              width: size * 0.9,
              height: size * 0.9,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.6),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
            ),

            // Main Piece Design Body
            _buildPieceBody(
              style: style,
              size: size,
              primaryColor: primaryColor,
              lightColor: lightColor,
              darkColor: darkColor,
              glowColor: glowColor,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPieceBody({
    required PieceStyle style,
    required double size,
    required Color primaryColor,
    required Color lightColor,
    required Color darkColor,
    required Color glowColor,
  }) {
    switch (style) {
      case PieceStyle.crystalMarble:
        return _buildCrystalMarble(size, primaryColor, lightColor, darkColor);
      case PieceStyle.royalCoin:
        return _buildRoyalCoin(size, primaryColor, lightColor, darkColor);
      case PieceStyle.facetedGem:
        return _buildFacetedGem(size, primaryColor, lightColor, darkColor);
      case PieceStyle.royalCrown:
        return _buildRoyalCrown(size, primaryColor, lightColor, darkColor);
      case PieceStyle.warriorShield:
        return _buildWarriorShield(size, primaryColor, lightColor, darkColor);
      case PieceStyle.mughalFloral:
        return _buildMughalFloral(size, primaryColor, lightColor, darkColor);
    }
  }

  // 1. Classic Glossy Crystal Marble
  Widget _buildCrystalMarble(double size, Color primary, Color light, Color dark) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              center: const Alignment(-0.35, -0.4),
              radius: 0.85,
              colors: [
                light,
                primary,
                dark,
                Colors.black87,
              ],
              stops: const [0.0, 0.45, 0.85, 1.0],
            ),
            border: Border.all(
              color: isSelected ? AppColors.selectedGlow : Colors.white.withValues(alpha: 0.45),
              width: isSelected ? 2.2 : 1.2,
            ),
          ),
        ),
        // Glint
        Positioned(
          top: size * 0.16,
          left: size * 0.22,
          child: Container(
            width: size * 0.28,
            height: size * 0.16,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.85),
              borderRadius: BorderRadius.all(
                Radius.elliptical(size * 0.28, size * 0.16),
              ),
            ),
          ),
        ),
        // Inner Ring
        Container(
          width: size * 0.35,
          height: size * 0.35,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.25),
              width: 1.0,
            ),
          ),
        ),
      ],
    );
  }

  // 2. Royal Stamped Coin / Medallion
  Widget _buildRoyalCoin(double size, Color primary, Color light, Color dark) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            light,
            primary,
            dark,
            primary,
          ],
        ),
        border: Border.all(
          color: const Color(0xFFFFD700),
          width: 2.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.4),
            blurRadius: 4,
          ),
        ],
      ),
      child: Center(
        child: Container(
          width: size * 0.65,
          height: size * 0.65,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: const Color(0xFFFFE082).withValues(alpha: 0.8),
              width: 1.2,
            ),
            color: dark.withValues(alpha: 0.5),
          ),
          child: Center(
            child: Icon(
              Icons.stars_rounded,
              size: size * 0.45,
              color: const Color(0xFFFFD700),
            ),
          ),
        ),
      ),
    );
  }

  // 3. Faceted Gemstone / Diamond
  Widget _buildFacetedGem(double size, Color primary, Color light, Color dark) {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Octagon Gem Base
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(size * 0.28),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                light,
                primary,
                dark,
              ],
            ),
            border: Border.all(
              color: Colors.white.withValues(alpha: 0.7),
              width: 1.8,
            ),
          ),
          child: Center(
            child: Container(
              width: size * 0.55,
              height: size * 0.55,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(size * 0.15),
                color: Colors.white.withValues(alpha: 0.25),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.9),
                  width: 1.2,
                ),
              ),
              child: Center(
                child: Icon(
                  Icons.diamond_outlined,
                  size: size * 0.35,
                  color: Colors.white.withValues(alpha: 0.9),
                ),
              ),
            ),
          ),
        ),
        // Gem Specular Sparkle
        Positioned(
          top: size * 0.12,
          right: size * 0.15,
          child: Icon(
            Icons.auto_awesome,
            size: size * 0.25,
            color: Colors.white.withValues(alpha: 0.9),
          ),
        ),
      ],
    );
  }

  // 4. Imperial Crown Signet
  Widget _buildRoyalCrown(double size, Color primary, Color light, Color dark) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.2, -0.3),
          radius: 0.9,
          colors: [
            light,
            primary,
            dark,
          ],
        ),
        border: Border.all(
          color: const Color(0xFFFFD700),
          width: 2.0,
        ),
      ),
      child: Center(
        child: Container(
          width: size * 0.68,
          height: size * 0.68,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black.withValues(alpha: 0.35),
            border: Border.all(
              color: const Color(0xFFFFD700).withValues(alpha: 0.5),
              width: 1.0,
            ),
          ),
          child: Center(
            child: Icon(
              Icons.workspace_premium_rounded,
              size: size * 0.48,
              color: const Color(0xFFFFD700),
            ),
          ),
        ),
      ),
    );
  }

  // 5. Warrior Shield Emblem
  Widget _buildWarriorShield(double size, Color primary, Color light, Color dark) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.3),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            light,
            primary,
            dark,
          ],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.6),
          width: 2.0,
        ),
      ),
      child: Center(
        child: Icon(
          Icons.shield_rounded,
          size: size * 0.55,
          color: Colors.white.withValues(alpha: 0.9),
        ),
      ),
    );
  }

  // 6. Traditional Mughal / Desi Floral Crest
  Widget _buildMughalFloral(double size, Color primary, Color light, Color dark) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            light,
            primary,
            dark,
          ],
        ),
        border: Border.all(
          color: const Color(0xFFFFD700),
          width: 1.8,
        ),
      ),
      child: Center(
        child: Container(
          width: size * 0.72,
          height: size * 0.72,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black.withValues(alpha: 0.3),
          ),
          child: Center(
            child: Icon(
              Icons.filter_vintage_rounded,
              size: size * 0.55,
              color: const Color(0xFFFFD700),
            ),
          ),
        ),
      ),
    );
  }
}
