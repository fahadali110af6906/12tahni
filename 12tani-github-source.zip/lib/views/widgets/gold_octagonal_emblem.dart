import 'dart:math';
import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class GoldOctagonalEmblem extends StatelessWidget {
  final double size;

  const GoldOctagonalEmblem({super.key, this.size = 140});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _EmblemPainter(),
      ),
    );
  }
}

class _EmblemPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.44;

    // 0. Outer ambient glow
    final glowPaint = Paint()
      ..color = const Color(0xFFFFD700).withValues(alpha: 0.28)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);
    canvas.drawCircle(center, radius, glowPaint);

    // 1. Draw Outer Octagon / Layered Diamond Square
    final outerPath = Path();
    for (int i = 0; i < 8; i++) {
      final angle = (i * pi / 4) - (pi / 8);
      final x = center.dx + radius * cos(angle);
      final y = center.dy + radius * sin(angle);
      if (i == 0) {
        outerPath.moveTo(x, y);
      } else {
        outerPath.lineTo(x, y);
      }
    }
    outerPath.close();

    final goldLinePaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFEA9F), Color(0xFFFFD700), Color(0xFFF5A623)],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.024;

    canvas.drawPath(outerPath, goldLinePaint);

    // 2. Draw Inner Octagon
    final innerPath = Path();
    final innerRadius = radius * 0.82;
    for (int i = 0; i < 8; i++) {
      final angle = (i * pi / 4) - (pi / 8);
      final x = center.dx + innerRadius * cos(angle);
      final y = center.dy + innerRadius * sin(angle);
      if (i == 0) {
        innerPath.moveTo(x, y);
      } else {
        innerPath.lineTo(x, y);
      }
    }
    innerPath.close();

    final thinGoldPaint = Paint()
      ..color = AppColors.goldAccent.withValues(alpha: 0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.012;

    canvas.drawPath(innerPath, thinGoldPaint);

    // 3. Draw Traditional 12 Goti Grid & Diagonal Cross inside
    final gridPaint = Paint()
      ..color = AppColors.goldAccent
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.018;

    final boxSize = radius * 0.52;
    final rect = Rect.fromCenter(center: center, width: boxSize * 2, height: boxSize * 2);
    canvas.drawRect(rect, gridPaint);

    // Cross lines
    canvas.drawLine(Offset(center.dx - boxSize, center.dy), Offset(center.dx + boxSize, center.dy), gridPaint);
    canvas.drawLine(Offset(center.dx, center.dy - boxSize), Offset(center.dx, center.dy + boxSize), gridPaint);

    // Diagonals
    canvas.drawLine(Offset(center.dx - boxSize, center.dy - boxSize), Offset(center.dx + boxSize, center.dy + boxSize), gridPaint);
    canvas.drawLine(Offset(center.dx - boxSize, center.dy + boxSize), Offset(center.dx + boxSize, center.dy - boxSize), gridPaint);

    // Corner decorative circular beads
    final beadPaint = Paint()
      ..color = AppColors.goldAccent
      ..style = PaintingStyle.fill;

    final cornerOffsets = [
      Offset(center.dx - boxSize, center.dy - boxSize),
      Offset(center.dx + boxSize, center.dy - boxSize),
      Offset(center.dx - boxSize, center.dy + boxSize),
      Offset(center.dx + boxSize, center.dy + boxSize),
      Offset(center.dx, center.dy),
    ];

    for (final pt in cornerOffsets) {
      canvas.drawCircle(pt, size.width * 0.024, beadPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
