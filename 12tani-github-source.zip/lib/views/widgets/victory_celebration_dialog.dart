import 'package:flutter/material.dart';
import '../../core/audio/sound_service.dart';
import '../../core/constants/app_strings.dart';
import '../../models/player_type.dart';
import '../../models/user_profile.dart';

class VictoryCelebrationDialog extends StatelessWidget {
  final PlayerType? winner;
  final int p1PiecesRemaining;
  final int p2PiecesRemaining;
  final String? p1Name;
  final String? p2Name;
  final VoidCallback onRematch;
  final VoidCallback onMainMenu;

  const VictoryCelebrationDialog({
    super.key,
    required this.winner,
    required this.p1PiecesRemaining,
    required this.p2PiecesRemaining,
    this.p1Name,
    this.p2Name,
    required this.onRematch,
    required this.onMainMenu,
  });

  @override
  Widget build(BuildContext context) {
    final user = UserProfile();
    final sound = SoundService();
    final isPlayer2Winner = winner == PlayerType.player2;
    final capturedCount = isPlayer2Winner ? (12 - p1PiecesRemaining) : (12 - p2PiecesRemaining);

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF162544),
                  Color(0xFF0D1629),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: const Color(0xFF38558A), width: 1.8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.85),
                  blurRadius: 30,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // "VICTORY!" Glowing Header
                Text(
                  winner == null ? 'DRAW MATCH' : 'VICTORY!',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3.0,
                    foreground: Paint()
                      ..shader = const LinearGradient(
                        colors: [Color(0xFF67E8F9), Color(0xFFFACC15), Color(0xFFF59E0B)],
                      ).createShader(const Rect.fromLTWH(0, 0, 200, 50)),
                    shadows: [
                      Shadow(
                        color: const Color(0xFFF59E0B).withValues(alpha: 0.6),
                        blurRadius: 16,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // 3D Golden Trophy
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const RadialGradient(
                      colors: [Color(0xFFFFD54F), Color(0xFFD97706), Color(0xFF78350F)],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFF59E0B).withValues(alpha: 0.5),
                        blurRadius: 24,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text('🏆', style: TextStyle(fontSize: 48)),
                  ),
                ),
                const SizedBox(height: 12),

                // WINNER: Name
                Text(
                  winner == null
                      ? 'Both players played well!'
                      : 'WINNER: ${isPlayer2Winner ? (p2Name ?? user.name) : (p1Name ?? "Computer")}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFF3C35C),
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 14),

                // +50 XP Progress Bar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0C1424),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF1E2E4E)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Level ${user.level}', style: const TextStyle(fontSize: 12, color: Colors.white70)),
                          const Text('+50 XP', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFFFACC15))),
                        ],
                      ),
                      const SizedBox(height: 6),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: (user.xp % 500) / 500.0,
                          minHeight: 8,
                          backgroundColor: const Color(0xFF1E293B),
                          valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFEAB308)),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Stats: Captured Beads & Total Coins
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0C1424),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF1E2E4E)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Captured Beads:',
                            style: TextStyle(fontSize: 13, color: Color(0xFF94A3B8)),
                          ),
                          Text(
                            '$capturedCount',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      const Divider(color: Color(0xFF1E2E4E), height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'TOTAL COINS:',
                            style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFFF3C35C)),
                          ),
                          Text(
                            '🪙 ${user.coins}',
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFFFACC15),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Green REMATCH Button
                InkWell(
                  onTap: () {
                    sound.playButtonClick();
                    Navigator.of(context).pop();
                    onRematch();
                  },
                  borderRadius: BorderRadius.circular(24),
                  child: Container(
                    width: double.infinity,
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF22C55E), Color(0xFF15803D)],
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF22C55E).withValues(alpha: 0.4),
                          blurRadius: 14,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      AppStrings.rematch.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // Brown BACK TO LOBBY Button
                InkWell(
                  onTap: () {
                    sound.playButtonClick();
                    Navigator.of(context).pop();
                    onMainMenu();
                  },
                  borderRadius: BorderRadius.circular(24),
                  child: Container(
                    width: double.infinity,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2D1B11),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: const Color(0xFF8B5314), width: 1.2),
                    ),
                    alignment: Alignment.center,
                    child: const Text(
                      'BACK TO LOBBY',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                        color: Color(0xFFF3C35C),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
