import 'dart:math';
import '../models/board_point.dart';
import '../models/difficulty.dart';
import '../models/game_move.dart';
import '../models/player_type.dart';
import 'rule_engine.dart';

class AiEngine {
  static final Random _random = Random();

  /// Central positions matrix with positional weights
  static const List<int> _positionWeights = [
    5,  5, 10,  5,  5,
    5, 15, 12, 15,  5,
   10, 12, 30, 12, 10,
    5, 15, 12, 15,  5,
    5,  5, 10,  5,  5,
  ];

  /// Chooses best move for the AI player according to [difficulty]
  static Future<GameMove?> chooseMove({
    required List<PlayerType?> board,
    required PlayerType aiPlayer,
    required Difficulty difficulty,
    BoardPoint? chainJumpFrom,
  }) async {
    final legalMoves = RuleEngine.getAllLegalMoves(
      board,
      aiPlayer,
      chainJumpFrom: chainJumpFrom,
    );

    if (legalMoves.isEmpty) return null;
    if (legalMoves.length == 1) return legalMoves.first;

    switch (difficulty) {
      case Difficulty.easy:
        return _chooseEasyMove(board, legalMoves, aiPlayer);
      case Difficulty.medium:
        return _chooseMinimaxMove(board, legalMoves, aiPlayer, depth: 2);
      case Difficulty.hard:
        final totalPieces = RuleEngine.countPieces(board, PlayerType.player1) +
            RuleEngine.countPieces(board, PlayerType.player2);
        // Deeper search when fewer pieces on board
        final depth = totalPieces <= 10 ? 5 : 4;
        return _chooseMinimaxMove(board, legalMoves, aiPlayer, depth: depth);
    }
  }

  /// Easy AI: Picks captures with some noise, otherwise random move
  static GameMove _chooseEasyMove(
    List<PlayerType?> board,
    List<GameMove> legalMoves,
    PlayerType aiPlayer,
  ) {
    final jumps = legalMoves.where((m) => m.isJump).toList();
    if (jumps.isNotEmpty && _random.nextDouble() < 0.65) {
      return jumps[_random.nextInt(jumps.length)];
    }
    return legalMoves[_random.nextInt(legalMoves.length)];
  }

  /// Minimax with Alpha-Beta pruning
  static GameMove _chooseMinimaxMove(
    List<PlayerType?> board,
    List<GameMove> legalMoves,
    PlayerType aiPlayer, {
    required int depth,
  }) {
    // Sort moves so jump captures are evaluated first (enhances Alpha-Beta cutoffs)
    final sortedMoves = List<GameMove>.from(legalMoves);
    sortedMoves.sort((a, b) {
      if (a.isJump && !b.isJump) return -1;
      if (!a.isJump && b.isJump) return 1;
      return _positionWeights[b.to.index].compareTo(_positionWeights[a.to.index]);
    });

    GameMove bestMove = sortedMoves.first;
    int bestScore = -1000000;
    int alpha = -1000000;
    const int beta = 1000000;

    for (final move in sortedMoves) {
      final nextBoard = RuleEngine.applyMove(board, move, aiPlayer);
      
      // If jump, check if chain jump is available
      int score;
      if (move.isJump) {
        final chainJumps = RuleEngine.getSubsequentJumps(nextBoard, move.to, aiPlayer);
        if (chainJumps.isNotEmpty) {
          // If chain jump exists, AI can continue in the same turn
          score = _minimax(
            nextBoard,
            depth - 1,
            alpha,
            beta,
            true,
            aiPlayer,
            chainJumpPoint: move.to,
          );
        } else {
          score = _minimax(
            nextBoard,
            depth - 1,
            alpha,
            beta,
            false,
            aiPlayer,
          );
        }
      } else {
        score = _minimax(
          nextBoard,
          depth - 1,
          alpha,
          beta,
          false,
          aiPlayer,
        );
      }

      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
      alpha = max(alpha, bestScore);
    }

    return bestMove;
  }

  static int _minimax(
    List<PlayerType?> board,
    int depth,
    int alpha,
    int beta,
    bool isMaximizing,
    PlayerType aiPlayer, {
    BoardPoint? chainJumpPoint,
  }) {
    final opponent = aiPlayer.opponent;
    final currentTurn = isMaximizing ? aiPlayer : opponent;

    final gameStatus = RuleEngine.checkGameStatus(
      board,
      currentTurn,
      activeChainPoint: chainJumpPoint,
    );

    if (gameStatus.isGameOver) {
      if (gameStatus.winner == aiPlayer) return 100000 + depth * 1000;
      if (gameStatus.winner == opponent) return -100000 - depth * 1000;
      return 0; // Draw
    }

    if (depth <= 0) {
      return _evaluateBoard(board, aiPlayer);
    }

    final legalMoves = RuleEngine.getAllLegalMoves(
      board,
      currentTurn,
      chainJumpFrom: chainJumpPoint,
    );

    if (legalMoves.isEmpty) {
      return isMaximizing ? -100000 : 100000;
    }

    // Sort moves for pruning
    legalMoves.sort((a, b) {
      if (a.isJump && !b.isJump) return -1;
      if (!a.isJump && b.isJump) return 1;
      return _positionWeights[b.to.index].compareTo(_positionWeights[a.to.index]);
    });

    if (isMaximizing) {
      int maxEval = -1000000;
      for (final move in legalMoves) {
        final nextBoard = RuleEngine.applyMove(board, move, aiPlayer);
        int eval;
        if (move.isJump) {
          final chains = RuleEngine.getSubsequentJumps(nextBoard, move.to, aiPlayer);
          if (chains.isNotEmpty) {
            eval = _minimax(nextBoard, depth - 1, alpha, beta, true, aiPlayer, chainJumpPoint: move.to);
          } else {
            eval = _minimax(nextBoard, depth - 1, alpha, beta, false, aiPlayer);
          }
        } else {
          eval = _minimax(nextBoard, depth - 1, alpha, beta, false, aiPlayer);
        }

        maxEval = max(maxEval, eval);
        alpha = max(alpha, eval);
        if (beta <= alpha) break;
      }
      return maxEval;
    } else {
      int minEval = 1000000;
      for (final move in legalMoves) {
        final nextBoard = RuleEngine.applyMove(board, move, opponent);
        int eval;
        if (move.isJump) {
          final chains = RuleEngine.getSubsequentJumps(nextBoard, move.to, opponent);
          if (chains.isNotEmpty) {
            eval = _minimax(nextBoard, depth - 1, alpha, beta, false, aiPlayer, chainJumpPoint: move.to);
          } else {
            eval = _minimax(nextBoard, depth - 1, alpha, beta, true, aiPlayer);
          }
        } else {
          eval = _minimax(nextBoard, depth - 1, alpha, beta, true, aiPlayer);
        }

        minEval = min(minEval, eval);
        beta = min(beta, eval);
        if (beta <= alpha) break;
      }
      return minEval;
    }
  }

  /// Detailed heuristic evaluation of the board
  static int _evaluateBoard(List<PlayerType?> board, PlayerType aiPlayer) {
    final opponent = aiPlayer.opponent;
    int score = 0;

    int aiPieces = 0;
    int oppPieces = 0;
    int aiPositional = 0;
    int oppPositional = 0;

    for (int i = 0; i < 25; i++) {
      final piece = board[i];
      if (piece == aiPlayer) {
        aiPieces++;
        aiPositional += _positionWeights[i];
      } else if (piece == opponent) {
        oppPieces++;
        oppPositional += _positionWeights[i];
      }
    }

    // 1. Material score (150 per piece)
    score += (aiPieces - oppPieces) * 150;

    // 2. Positional control
    score += (aiPositional - oppPositional);

    // 3. Vulnerability penalty (pieces that opponent can jump on their next turn)
    final oppJumps = RuleEngine.getAllLegalMoves(board, opponent)
        .where((m) => m.isJump)
        .toList();
    score -= (oppJumps.length * 60);

    // 4. AI Jump opportunities bonus
    final aiJumps = RuleEngine.getAllLegalMoves(board, aiPlayer)
        .where((m) => m.isJump)
        .toList();
    score += (aiJumps.length * 50);

    return score;
  }
}
