import '../core/constants/game_constants.dart';
import '../models/board_point.dart';
import '../models/game_move.dart';
import '../models/player_type.dart';
import 'board_topology.dart';

class RuleEngine {
  /// Returns standard initial board layout (25 points)
  static List<PlayerType?> createInitialBoard() {
    final board = List<PlayerType?>.filled(GameConstants.totalPoints, null);

    for (final idx in GameConstants.initialPlayer1Indices) {
      board[idx] = PlayerType.player1;
    }

    for (final idx in GameConstants.initialPlayer2Indices) {
      board[idx] = PlayerType.player2;
    }

    // Center point (index 12) remains null
    return board;
  }

  /// Get all legal moves for a specific piece at [from]
  static List<GameMove> getLegalMovesForPoint(
    List<PlayerType?> board,
    BoardPoint from,
    PlayerType player, {
    bool jumpsOnly = false,
  }) {
    if (!from.isValid) return const [];
    if (board[from.index] != player) return const [];

    final List<GameMove> moves = [];
    final opponent = player.opponent;

    // 1. Check all jump captures
    final jumpPaths = BoardTopology.getJumpPaths(from);
    for (final path in jumpPaths) {
      if (board[path.mid.index] == opponent && board[path.to.index] == null) {
        moves.add(GameMove(
          from: from,
          to: path.to,
          capturedPoint: path.mid,
          isJump: true,
        ));
      }
    }

    // 2. If jumpsOnly is true, return jumps immediately
    if (jumpsOnly) {
      return moves;
    }

    // 3. Normal adjacent step moves
    final neighbors = BoardTopology.getNeighbors(from);
    for (final neighbor in neighbors) {
      if (board[neighbor.index] == null) {
        moves.add(GameMove(
          from: from,
          to: neighbor,
          isJump: false,
        ));
      }
    }

    return moves;
  }

  /// Get all legal moves for [player] across the entire board
  static List<GameMove> getAllLegalMoves(
    List<PlayerType?> board,
    PlayerType player, {
    BoardPoint? chainJumpFrom,
  }) {
    if (chainJumpFrom != null) {
      return getLegalMovesForPoint(board, chainJumpFrom, player, jumpsOnly: true);
    }

    final List<GameMove> moves = [];
    for (int i = 0; i < GameConstants.totalPoints; i++) {
      if (board[i] == player) {
        final point = BoardPoint.fromIndex(i);
        moves.addAll(getLegalMovesForPoint(board, point, player));
      }
    }
    return moves;
  }

  /// Apply a move and return a new board state
  static List<PlayerType?> applyMove(
    List<PlayerType?> board,
    GameMove move,
    PlayerType player,
  ) {
    final newBoard = List<PlayerType?>.from(board);
    newBoard[move.from.index] = null;
    newBoard[move.to.index] = player;

    if (move.isJump && move.capturedPoint != null) {
      newBoard[move.capturedPoint!.index] = null;
    }

    return newBoard;
  }

  /// Check if piece has subsequent jump captures after landing at [landingPoint]
  static List<GameMove> getSubsequentJumps(
    List<PlayerType?> board,
    BoardPoint landingPoint,
    PlayerType player,
  ) {
    return getLegalMovesForPoint(board, landingPoint, player, jumpsOnly: true);
  }

  /// Count pieces of a given player
  static int countPieces(List<PlayerType?> board, PlayerType player) {
    int count = 0;
    for (int i = 0; i < GameConstants.totalPoints; i++) {
      if (board[i] == player) count++;
    }
    return count;
  }

  /// Evaluate if game has ended
  static ({bool isGameOver, PlayerType? winner, String reason}) checkGameStatus(
    List<PlayerType?> board,
    PlayerType nextTurnPlayer, {
    BoardPoint? activeChainPoint,
  }) {
    final p1Count = countPieces(board, PlayerType.player1);
    final p2Count = countPieces(board, PlayerType.player2);

    if (p1Count == 0) {
      return (
        isGameOver: true,
        winner: PlayerType.player2,
        reason: 'پلیئر ۲ نے تمام مہرے ختم کر دیے!'
      );
    }

    if (p2Count == 0) {
      return (
        isGameOver: true,
        winner: PlayerType.player1,
        reason: 'پلیئر ۱ نے تمام مہرے ختم کر دیے!'
      );
    }

    // Check mobility for next turn player
    final legalMoves = getAllLegalMoves(
      board,
      nextTurnPlayer,
      chainJumpFrom: activeChainPoint,
    );

    if (legalMoves.isEmpty) {
      return (
        isGameOver: true,
        winner: nextTurnPlayer.opponent,
        reason: 'مخالف کے پاس کوئی قانونی چال باقی نہیں بچی!'
      );
    }

    return (isGameOver: false, winner: null, reason: '');
  }
}
