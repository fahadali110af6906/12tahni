import '../models/board_point.dart';

class JumpPath {
  final BoardPoint from;
  final BoardPoint mid; // Jumped opponent piece
  final BoardPoint to;  // Landing empty spot

  const JumpPath({
    required this.from,
    required this.mid,
    required this.to,
  });
}

class BoardTopology {
  // Precomputed adjacent neighbors for each index (0..24)
  static final List<List<BoardPoint>> _adjacentNeighbors = List.generate(
    25,
    (index) => _computeNeighbors(BoardPoint.fromIndex(index)),
  );

  // Precomputed jump paths from each index (0..24)
  static final List<List<JumpPath>> _jumpPaths = List.generate(
    25,
    (index) => _computeJumpPaths(BoardPoint.fromIndex(index)),
  );

  static List<BoardPoint> getNeighbors(BoardPoint point) {
    if (!point.isValid) return const [];
    return _adjacentNeighbors[point.index];
  }

  static List<JumpPath> getJumpPaths(BoardPoint point) {
    if (!point.isValid) return const [];
    return _jumpPaths[point.index];
  }

  static bool areAdjacent(BoardPoint a, BoardPoint b) {
    return getNeighbors(a).contains(b);
  }

  static List<BoardPoint> _computeNeighbors(BoardPoint p) {
    final List<BoardPoint> neighbors = [];

    // Orthogonal directions (Up, Down, Left, Right)
    const orthogonalDirs = [
      [-1, 0], // Up
      [1, 0],  // Down
      [0, -1], // Left
      [0, 1],  // Right
    ];

    for (final dir in orthogonalDirs) {
      final nr = p.row + dir[0];
      final nc = p.col + dir[1];
      if (nr >= 0 && nr < 5 && nc >= 0 && nc < 5) {
        neighbors.add(BoardPoint(nr, nc));
      }
    }

    // Diagonals if point has diagonal connections ((r + c) % 2 == 0)
    if (p.hasDiagonals) {
      const diagonalDirs = [
        [-1, -1], // Up-Left
        [-1, 1],  // Up-Right
        [1, -1],  // Down-Left
        [1, 1],   // Down-Right
      ];

      for (final dir in diagonalDirs) {
        final nr = p.row + dir[0];
        final nc = p.col + dir[1];
        if (nr >= 0 && nr < 5 && nc >= 0 && nc < 5) {
          neighbors.add(BoardPoint(nr, nc));
        }
      }
    }

    return neighbors;
  }

  static List<JumpPath> _computeJumpPaths(BoardPoint p) {
    final List<JumpPath> paths = [];

    // Orthogonal 2-step jumps
    const orthogonalDirs = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1],
    ];

    for (final dir in orthogonalDirs) {
      final midR = p.row + dir[0];
      final midC = p.col + dir[1];
      final toR = p.row + 2 * dir[0];
      final toC = p.col + 2 * dir[1];

      if (toR >= 0 && toR < 5 && toC >= 0 && toC < 5) {
        paths.add(JumpPath(
          from: p,
          mid: BoardPoint(midR, midC),
          to: BoardPoint(toR, toC),
        ));
      }
    }

    // Diagonal 2-step jumps (only from points with diagonals)
    if (p.hasDiagonals) {
      const diagonalDirs = [
        [-1, -1],
        [-1, 1],
        [1, -1],
        [1, 1],
      ];

      for (final dir in diagonalDirs) {
        final midR = p.row + dir[0];
        final midC = p.col + dir[1];
        final toR = p.row + 2 * dir[0];
        final toC = p.col + 2 * dir[1];

        if (toR >= 0 && toR < 5 && toC >= 0 && toC < 5) {
          paths.add(JumpPath(
            from: p,
            mid: BoardPoint(midR, midC),
            to: BoardPoint(toR, toC),
          ));
        }
      }
    }

    return paths;
  }
}
